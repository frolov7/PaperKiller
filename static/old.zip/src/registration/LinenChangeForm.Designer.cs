﻿namespace registration
{
    partial class LinenChangeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.getTowelBtn = new System.Windows.Forms.Button();
            this.getBedspreadBtn = new System.Windows.Forms.Button();
            this.getDuvetBtn = new System.Windows.Forms.Button();
            this.getPillowcaseBtn = new System.Windows.Forms.Button();
            this.getBedsheetBtn = new System.Windows.Forms.Button();
            this.changeTowelBtn = new System.Windows.Forms.Button();
            this.changeBedspreadBtn = new System.Windows.Forms.Button();
            this.changeDuvetBtn = new System.Windows.Forms.Button();
            this.changePillowcaseBtn = new System.Windows.Forms.Button();
            this.changeBedsheetBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.towelSNlabel = new System.Windows.Forms.Label();
            this.bedspreadSNlabel = new System.Windows.Forms.Label();
            this.duvetSNlabel = new System.Windows.Forms.Label();
            this.pillowcaseSNLabel = new System.Windows.Forms.Label();
            this.bedsheetSNlabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.TowelPassBtn = new System.Windows.Forms.Button();
            this.BedspreadPassBtn = new System.Windows.Forms.Button();
            this.DuvetPassBtn = new System.Windows.Forms.Button();
            this.PillowcasePassBtn = new System.Windows.Forms.Button();
            this.BedsheetPassBtn = new System.Windows.Forms.Button();
            this.bedsheetTmpLabel = new System.Windows.Forms.Label();
            this.pillowcaseTmpLabel = new System.Windows.Forms.Label();
            this.duvetTmpLabel = new System.Windows.Forms.Label();
            this.bedspreadTmpLabel = new System.Windows.Forms.Label();
            this.towelTmpLabel = new System.Windows.Forms.Label();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.logoLabel = new System.Windows.Forms.Label();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // getTowelBtn
            // 
            this.getTowelBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getTowelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getTowelBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getTowelBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getTowelBtn.Location = new System.Drawing.Point(962, 442);
            this.getTowelBtn.Name = "getTowelBtn";
            this.getTowelBtn.Size = new System.Drawing.Size(109, 36);
            this.getTowelBtn.TabIndex = 147;
            this.getTowelBtn.Text = "Получить";
            this.getTowelBtn.UseVisualStyleBackColor = false;
            this.getTowelBtn.Click += new System.EventHandler(this.getTowelBtn_Click);
            // 
            // getBedspreadBtn
            // 
            this.getBedspreadBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getBedspreadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getBedspreadBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getBedspreadBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getBedspreadBtn.Location = new System.Drawing.Point(962, 385);
            this.getBedspreadBtn.Name = "getBedspreadBtn";
            this.getBedspreadBtn.Size = new System.Drawing.Size(109, 36);
            this.getBedspreadBtn.TabIndex = 146;
            this.getBedspreadBtn.Text = "Получить";
            this.getBedspreadBtn.UseVisualStyleBackColor = false;
            this.getBedspreadBtn.Click += new System.EventHandler(this.getBedspreadBtn_Click);
            // 
            // getDuvetBtn
            // 
            this.getDuvetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getDuvetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getDuvetBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getDuvetBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getDuvetBtn.Location = new System.Drawing.Point(962, 330);
            this.getDuvetBtn.Name = "getDuvetBtn";
            this.getDuvetBtn.Size = new System.Drawing.Size(109, 36);
            this.getDuvetBtn.TabIndex = 145;
            this.getDuvetBtn.Text = "Получить";
            this.getDuvetBtn.UseVisualStyleBackColor = false;
            this.getDuvetBtn.Click += new System.EventHandler(this.getDuvetBtn_Click);
            // 
            // getPillowcaseBtn
            // 
            this.getPillowcaseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getPillowcaseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getPillowcaseBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getPillowcaseBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getPillowcaseBtn.Location = new System.Drawing.Point(962, 275);
            this.getPillowcaseBtn.Name = "getPillowcaseBtn";
            this.getPillowcaseBtn.Size = new System.Drawing.Size(109, 36);
            this.getPillowcaseBtn.TabIndex = 144;
            this.getPillowcaseBtn.Text = "Получить";
            this.getPillowcaseBtn.UseVisualStyleBackColor = false;
            this.getPillowcaseBtn.Click += new System.EventHandler(this.getPillowcaseBtn_Click);
            // 
            // getBedsheetBtn
            // 
            this.getBedsheetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getBedsheetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getBedsheetBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getBedsheetBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getBedsheetBtn.Location = new System.Drawing.Point(962, 220);
            this.getBedsheetBtn.Name = "getBedsheetBtn";
            this.getBedsheetBtn.Size = new System.Drawing.Size(109, 36);
            this.getBedsheetBtn.TabIndex = 143;
            this.getBedsheetBtn.Text = "Получить";
            this.getBedsheetBtn.UseVisualStyleBackColor = false;
            this.getBedsheetBtn.Click += new System.EventHandler(this.getBedsheetBtn_Click);
            // 
            // changeTowelBtn
            // 
            this.changeTowelBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeTowelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeTowelBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeTowelBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeTowelBtn.Location = new System.Drawing.Point(815, 440);
            this.changeTowelBtn.Name = "changeTowelBtn";
            this.changeTowelBtn.Size = new System.Drawing.Size(116, 36);
            this.changeTowelBtn.TabIndex = 142;
            this.changeTowelBtn.Text = "Обменять";
            this.changeTowelBtn.UseVisualStyleBackColor = false;
            this.changeTowelBtn.Click += new System.EventHandler(this.changeTowelBtn_Click);
            // 
            // changeBedspreadBtn
            // 
            this.changeBedspreadBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeBedspreadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeBedspreadBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeBedspreadBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeBedspreadBtn.Location = new System.Drawing.Point(815, 385);
            this.changeBedspreadBtn.Name = "changeBedspreadBtn";
            this.changeBedspreadBtn.Size = new System.Drawing.Size(116, 36);
            this.changeBedspreadBtn.TabIndex = 141;
            this.changeBedspreadBtn.Text = "Обменять";
            this.changeBedspreadBtn.UseVisualStyleBackColor = false;
            this.changeBedspreadBtn.Click += new System.EventHandler(this.changeBedspreadBtn_Click);
            // 
            // changeDuvetBtn
            // 
            this.changeDuvetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeDuvetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeDuvetBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeDuvetBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeDuvetBtn.Location = new System.Drawing.Point(815, 330);
            this.changeDuvetBtn.Name = "changeDuvetBtn";
            this.changeDuvetBtn.Size = new System.Drawing.Size(116, 36);
            this.changeDuvetBtn.TabIndex = 140;
            this.changeDuvetBtn.Text = "Обменять";
            this.changeDuvetBtn.UseVisualStyleBackColor = false;
            this.changeDuvetBtn.Click += new System.EventHandler(this.changeDuvetBtn_Click);
            // 
            // changePillowcaseBtn
            // 
            this.changePillowcaseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changePillowcaseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changePillowcaseBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changePillowcaseBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changePillowcaseBtn.Location = new System.Drawing.Point(815, 275);
            this.changePillowcaseBtn.Name = "changePillowcaseBtn";
            this.changePillowcaseBtn.Size = new System.Drawing.Size(116, 36);
            this.changePillowcaseBtn.TabIndex = 139;
            this.changePillowcaseBtn.Text = "Обменять";
            this.changePillowcaseBtn.UseVisualStyleBackColor = false;
            this.changePillowcaseBtn.Click += new System.EventHandler(this.changePillowcaseBtn_Click);
            // 
            // changeBedsheetBtn
            // 
            this.changeBedsheetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeBedsheetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeBedsheetBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeBedsheetBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeBedsheetBtn.Location = new System.Drawing.Point(815, 220);
            this.changeBedsheetBtn.Name = "changeBedsheetBtn";
            this.changeBedsheetBtn.Size = new System.Drawing.Size(116, 36);
            this.changeBedsheetBtn.TabIndex = 138;
            this.changeBedsheetBtn.Text = "Обменять";
            this.changeBedsheetBtn.UseVisualStyleBackColor = false;
            this.changeBedsheetBtn.Click += new System.EventHandler(this.changeBedsheetBtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(461, 184);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 26);
            this.label7.TabIndex = 137;
            this.label7.Text = "Статус предмета";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(229, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 26);
            this.label6.TabIndex = 136;
            this.label6.Text = "Серийный номер";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NameLabel.Location = new System.Drawing.Point(69, 184);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(96, 26);
            this.NameLabel.TabIndex = 135;
            this.NameLabel.Text = "Название";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(21, 216);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(640, 1);
            this.panel3.TabIndex = 129;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(421, 223);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 250);
            this.panel2.TabIndex = 128;
            // 
            // towelSNlabel
            // 
            this.towelSNlabel.AutoSize = true;
            this.towelSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.towelSNlabel.Location = new System.Drawing.Point(231, 440);
            this.towelSNlabel.Name = "towelSNlabel";
            this.towelSNlabel.Size = new System.Drawing.Size(176, 36);
            this.towelSNlabel.TabIndex = 134;
            this.towelSNlabel.Text = "serialNumber";
            // 
            // bedspreadSNlabel
            // 
            this.bedspreadSNlabel.AutoSize = true;
            this.bedspreadSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedspreadSNlabel.Location = new System.Drawing.Point(231, 385);
            this.bedspreadSNlabel.Name = "bedspreadSNlabel";
            this.bedspreadSNlabel.Size = new System.Drawing.Size(176, 36);
            this.bedspreadSNlabel.TabIndex = 133;
            this.bedspreadSNlabel.Text = "serialNumber";
            // 
            // duvetSNlabel
            // 
            this.duvetSNlabel.AutoSize = true;
            this.duvetSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duvetSNlabel.Location = new System.Drawing.Point(231, 330);
            this.duvetSNlabel.Name = "duvetSNlabel";
            this.duvetSNlabel.Size = new System.Drawing.Size(176, 36);
            this.duvetSNlabel.TabIndex = 132;
            this.duvetSNlabel.Text = "serialNumber";
            // 
            // pillowcaseSNLabel
            // 
            this.pillowcaseSNLabel.AutoSize = true;
            this.pillowcaseSNLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseSNLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pillowcaseSNLabel.Location = new System.Drawing.Point(231, 275);
            this.pillowcaseSNLabel.Name = "pillowcaseSNLabel";
            this.pillowcaseSNLabel.Size = new System.Drawing.Size(176, 36);
            this.pillowcaseSNLabel.TabIndex = 131;
            this.pillowcaseSNLabel.Text = "serialNumber";
            // 
            // bedsheetSNlabel
            // 
            this.bedsheetSNlabel.AutoSize = true;
            this.bedsheetSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedsheetSNlabel.Location = new System.Drawing.Point(231, 220);
            this.bedsheetSNlabel.Name = "bedsheetSNlabel";
            this.bedsheetSNlabel.Size = new System.Drawing.Size(176, 36);
            this.bedsheetSNlabel.TabIndex = 130;
            this.bedsheetSNlabel.Text = "serialNumber";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(646, 233);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 250);
            this.panel1.TabIndex = 127;
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(209, 226);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(1, 250);
            this.panelPassword.TabIndex = 126;
            // 
            // TowelPassBtn
            // 
            this.TowelPassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TowelPassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TowelPassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TowelPassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.TowelPassBtn.Location = new System.Drawing.Point(680, 440);
            this.TowelPassBtn.Name = "TowelPassBtn";
            this.TowelPassBtn.Size = new System.Drawing.Size(109, 36);
            this.TowelPassBtn.TabIndex = 125;
            this.TowelPassBtn.Text = "Сдать";
            this.TowelPassBtn.UseVisualStyleBackColor = false;
            this.TowelPassBtn.Click += new System.EventHandler(this.TowelPassBtn_Click);
            // 
            // BedspreadPassBtn
            // 
            this.BedspreadPassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BedspreadPassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BedspreadPassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BedspreadPassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.BedspreadPassBtn.Location = new System.Drawing.Point(680, 385);
            this.BedspreadPassBtn.Name = "BedspreadPassBtn";
            this.BedspreadPassBtn.Size = new System.Drawing.Size(109, 36);
            this.BedspreadPassBtn.TabIndex = 124;
            this.BedspreadPassBtn.Text = "Сдать";
            this.BedspreadPassBtn.UseVisualStyleBackColor = false;
            this.BedspreadPassBtn.Click += new System.EventHandler(this.BedspreadPassBtn_Click);
            // 
            // DuvetPassBtn
            // 
            this.DuvetPassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DuvetPassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DuvetPassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DuvetPassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.DuvetPassBtn.Location = new System.Drawing.Point(680, 330);
            this.DuvetPassBtn.Name = "DuvetPassBtn";
            this.DuvetPassBtn.Size = new System.Drawing.Size(109, 36);
            this.DuvetPassBtn.TabIndex = 123;
            this.DuvetPassBtn.Text = "Сдать";
            this.DuvetPassBtn.UseVisualStyleBackColor = false;
            this.DuvetPassBtn.Click += new System.EventHandler(this.DuvetPassBtn_Click);
            // 
            // PillowcasePassBtn
            // 
            this.PillowcasePassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PillowcasePassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PillowcasePassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PillowcasePassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.PillowcasePassBtn.Location = new System.Drawing.Point(680, 275);
            this.PillowcasePassBtn.Name = "PillowcasePassBtn";
            this.PillowcasePassBtn.Size = new System.Drawing.Size(109, 36);
            this.PillowcasePassBtn.TabIndex = 122;
            this.PillowcasePassBtn.Text = "Сдать";
            this.PillowcasePassBtn.UseVisualStyleBackColor = false;
            this.PillowcasePassBtn.Click += new System.EventHandler(this.PillowcasePassBtn_Click);
            // 
            // BedsheetPassBtn
            // 
            this.BedsheetPassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BedsheetPassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BedsheetPassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BedsheetPassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.BedsheetPassBtn.Location = new System.Drawing.Point(680, 220);
            this.BedsheetPassBtn.Name = "BedsheetPassBtn";
            this.BedsheetPassBtn.Size = new System.Drawing.Size(109, 36);
            this.BedsheetPassBtn.TabIndex = 121;
            this.BedsheetPassBtn.Text = "Сдать";
            this.BedsheetPassBtn.UseVisualStyleBackColor = false;
            this.BedsheetPassBtn.Click += new System.EventHandler(this.BedsheetPassBtn_Click);
            // 
            // bedsheetTmpLabel
            // 
            this.bedsheetTmpLabel.AutoSize = true;
            this.bedsheetTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedsheetTmpLabel.Location = new System.Drawing.Point(480, 220);
            this.bedsheetTmpLabel.Name = "bedsheetTmpLabel";
            this.bedsheetTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.bedsheetTmpLabel.TabIndex = 120;
            this.bedsheetTmpLabel.Text = "status";
            // 
            // pillowcaseTmpLabel
            // 
            this.pillowcaseTmpLabel.AutoSize = true;
            this.pillowcaseTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pillowcaseTmpLabel.Location = new System.Drawing.Point(480, 275);
            this.pillowcaseTmpLabel.Name = "pillowcaseTmpLabel";
            this.pillowcaseTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.pillowcaseTmpLabel.TabIndex = 119;
            this.pillowcaseTmpLabel.Text = "status";
            // 
            // duvetTmpLabel
            // 
            this.duvetTmpLabel.AutoSize = true;
            this.duvetTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duvetTmpLabel.Location = new System.Drawing.Point(480, 330);
            this.duvetTmpLabel.Name = "duvetTmpLabel";
            this.duvetTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.duvetTmpLabel.TabIndex = 118;
            this.duvetTmpLabel.Text = "status";
            // 
            // bedspreadTmpLabel
            // 
            this.bedspreadTmpLabel.AutoSize = true;
            this.bedspreadTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedspreadTmpLabel.Location = new System.Drawing.Point(480, 385);
            this.bedspreadTmpLabel.Name = "bedspreadTmpLabel";
            this.bedspreadTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.bedspreadTmpLabel.TabIndex = 117;
            this.bedspreadTmpLabel.Text = "status";
            // 
            // towelTmpLabel
            // 
            this.towelTmpLabel.AutoSize = true;
            this.towelTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.towelTmpLabel.Location = new System.Drawing.Point(480, 440);
            this.towelTmpLabel.Name = "towelTmpLabel";
            this.towelTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.towelTmpLabel.TabIndex = 116;
            this.towelTmpLabel.Text = "status";
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(45, 8);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(569, 74);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Обменять белье";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label5.Location = new System.Drawing.Point(12, 440);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(149, 36);
            this.Label5.TabIndex = 115;
            this.Label5.Text = "Полотенце";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label4.Location = new System.Drawing.Point(12, 385);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(155, 36);
            this.Label4.TabIndex = 114;
            this.Label4.Text = "Покрывало";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label3.Location = new System.Drawing.Point(12, 330);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(197, 36);
            this.Label3.TabIndex = 113;
            this.Label3.Text = "Пододеяльник";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label1.Location = new System.Drawing.Point(12, 220);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(141, 36);
            this.Label1.TabIndex = 112;
            this.Label1.Text = "Простыня";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label2.Location = new System.Drawing.Point(12, 275);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(147, 36);
            this.Label2.TabIndex = 111;
            this.Label2.Text = "Наволочка";
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(427, 522);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 40);
            this.goBackBtn.TabIndex = 110;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(1070, 3);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 109;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(427, 59);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(670, 84);
            this.mainPanel.TabIndex = 108;
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(28, 66);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 107;
            this.logoLabel.Text = "PaperKiller";
            // 
            // LinenChangeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1100, 571);
            this.Controls.Add(this.getTowelBtn);
            this.Controls.Add(this.getBedspreadBtn);
            this.Controls.Add(this.getDuvetBtn);
            this.Controls.Add(this.getPillowcaseBtn);
            this.Controls.Add(this.getBedsheetBtn);
            this.Controls.Add(this.changeTowelBtn);
            this.Controls.Add(this.changeBedspreadBtn);
            this.Controls.Add(this.changeDuvetBtn);
            this.Controls.Add(this.changePillowcaseBtn);
            this.Controls.Add(this.changeBedsheetBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.towelSNlabel);
            this.Controls.Add(this.bedspreadSNlabel);
            this.Controls.Add(this.duvetSNlabel);
            this.Controls.Add(this.pillowcaseSNLabel);
            this.Controls.Add(this.bedsheetSNlabel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelPassword);
            this.Controls.Add(this.TowelPassBtn);
            this.Controls.Add(this.BedspreadPassBtn);
            this.Controls.Add(this.DuvetPassBtn);
            this.Controls.Add(this.PillowcasePassBtn);
            this.Controls.Add(this.BedsheetPassBtn);
            this.Controls.Add(this.bedsheetTmpLabel);
            this.Controls.Add(this.pillowcaseTmpLabel);
            this.Controls.Add(this.duvetTmpLabel);
            this.Controls.Add(this.bedspreadTmpLabel);
            this.Controls.Add(this.towelTmpLabel);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LinenChangeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "LinenChangeForm";
            this.Load += new System.EventHandler(this.LinenChangeForm_Load);
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button getTowelBtn;
        private System.Windows.Forms.Button getBedspreadBtn;
        private System.Windows.Forms.Button getDuvetBtn;
        private System.Windows.Forms.Button getPillowcaseBtn;
        private System.Windows.Forms.Button getBedsheetBtn;
        private System.Windows.Forms.Button changeTowelBtn;
        private System.Windows.Forms.Button changeBedspreadBtn;
        private System.Windows.Forms.Button changeDuvetBtn;
        private System.Windows.Forms.Button changePillowcaseBtn;
        private System.Windows.Forms.Button changeBedsheetBtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label towelSNlabel;
        private System.Windows.Forms.Label bedspreadSNlabel;
        private System.Windows.Forms.Label duvetSNlabel;
        private System.Windows.Forms.Label pillowcaseSNLabel;
        private System.Windows.Forms.Label bedsheetSNlabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.Button TowelPassBtn;
        private System.Windows.Forms.Button BedspreadPassBtn;
        private System.Windows.Forms.Button DuvetPassBtn;
        private System.Windows.Forms.Button PillowcasePassBtn;
        private System.Windows.Forms.Button BedsheetPassBtn;
        private System.Windows.Forms.Label bedsheetTmpLabel;
        private System.Windows.Forms.Label pillowcaseTmpLabel;
        private System.Windows.Forms.Label duvetTmpLabel;
        private System.Windows.Forms.Label bedspreadTmpLabel;
        private System.Windows.Forms.Label towelTmpLabel;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label Label5;
        private System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Label Label3;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label logoLabel;
    }
}