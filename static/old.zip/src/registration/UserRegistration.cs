﻿using AccessToDB;
using DataStructures;
using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace registration
{
    public class UserRegistration
    {
        private string gender = "Пол не выбран";
        private Connector connectDB = new Connector();

        public string InitializeField(TextBox textBox, string placeholder)
        {
            textBox.Text = placeholder;
            textBox.ForeColor = System.Drawing.Color.Gray;
            return placeholder;
        }

        public void UpdateGender(string newGender, PictureBox activeBtn, PictureBox inactiveBtn, PictureBox nameImg, PictureBox surnameImg)
        {
            gender = newGender;
            activeBtn.Image = Properties.Resources.man_icon2; // Изображение активной кнопки мальчика
            inactiveBtn.Image = Properties.Resources.girl_icon; // Изображение неактивной кнопки девочки
            nameImg.Image = (newGender == "M") ? Properties.Resources.user_icon : Properties.Resources.user_icon_female;
            surnameImg.Image = (newGender == "M") ? Properties.Resources.user_icon2 : Properties.Resources.user_icon_female2;
        }

        public bool ValidateForm(params TextBox[] fields)
        {
            foreach (TextBox field in fields)
            {
                if (field.Text == field.Tag.ToString() || string.IsNullOrWhiteSpace(field.Text))
                {
                    return false;
                }
            }
            return true;
        }

        public bool ValidateGender()
        {
            return gender != "Пол не выбран";
        }

        public bool IsLoginExists(string login)
        {
            return CheckInfo.isLoginExists(connectDB, login);
        }

        public bool IsStudentIDExists(string studentID)
        {
            return CheckInfo.isStudentIDExists(connectDB, studentID);
        }

        public bool ArePasswordsEqual(string password, string passwordRepeat)
        {
            return password == passwordRepeat;
        }

        public bool IsPhoneNumberValid(string phoneNumber)
        {
            return Regex.IsMatch(phoneNumber, @"\+7\d{3}\d{3}\d{4}$");
        }

        public void CreateUser(string login, string password, string name, string surname, string phone, string studak)
        {
            string sex = gender;

            InsertInfo.InsertUser(connectDB, login, password);
            InsertInfo.InsertUserData(connectDB, name, surname, phone, studak, sex);
            UpdateInfo.UpLinenID(connectDB);
            UpdateInfo.UpItemID(connectDB);
            Student currentUser = GetInfo.GetStudentByLogin(connectDB, login, password);
        }

        public void HandleFieldEnter(TextBox textBox)
        {
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = Color.Black; // Меняем цвет текста на черный
            }
        }

        public void HandleFieldLeave(TextBox textBox, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.ForeColor = Color.Gray;
            }
        }

        public void HandleFieldClick(TextBox textBox, Panel panel)
        {
            textBox.Clear();
            panel.BackColor = Color.FromArgb(255, 153, 0); // Цвет активной панели
            textBox.ForeColor = Color.FromArgb(255, 153, 0); // Цвет текста при активации
            ResetOtherPanels(panel);
        }

        public void HandleFieldClickLeave(TextBox textBox, Panel panel, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.ForeColor = Color.Gray;
                panel.BackColor = Color.WhiteSmoke; // Цвет неактивной панели
            }
        }

        private void ResetOtherPanels(Panel currentPanel)
        {
            // Сброс цвета других панелей к исходному
            foreach (Control control in currentPanel.Parent.Controls)
            {
                if (control is Panel panel && panel != currentPanel)
                {
                    panel.BackColor = Color.WhiteSmoke; // Цвет неактивной панели
                }
            }
        }
    }
}
