﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using AccessToDB;
using DataStructures;

namespace registration
{
    public partial class RegisterForm : Form
    {
        Connector connectDB = new Connector();
        public string gender = "Пол не выбран";
        public RegisterForm()
        {
            InitializeComponent();

            nameField.Text = "Введите имя";
            nameField.ForeColor = Color.Gray;

            surnameField.Text = "Введите фамилию";
            surnameField.ForeColor = Color.Gray;

            studentIDField.Text = "Введите студенческий";
            studentIDField.ForeColor = Color.Gray;

            phoneField.Text = "Введите телефон";
            phoneField.ForeColor = Color.Gray;

            loginField.Text = "Введите логин";
            loginField.ForeColor = Color.Gray;

            passwordField.Text = "Введите пароль";
            passwordField.ForeColor = Color.Gray;

            passwordRepeatField.Text = "Повторите пароль";
            passwordRepeatField.ForeColor = Color.Gray;
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Смена картинок при выборе пола
        private void maleBtn_Click(object sender, EventArgs e)
        {
            gender = "M";
            maleBtn.Image = Properties.Resources.man_icon2; // меняем на активную кнопку мальчика
            femaleBtn.Image = Properties.Resources.girl_icon; // убираем активную кнопку девочки
            nameImg.Image = Properties.Resources.user_icon; // меняем на активную картинку мальчика имени
            surnameImg.Image = Properties.Resources.user_icon2; // фамилии
        }

        private void femaleBtn_Click(object sender, EventArgs e)
        {
            gender = "F";
            femaleBtn.Image = Properties.Resources.girl_icon2; // меняем на активную кнопку девочки
            maleBtn.Image = Properties.Resources.man_icon; // убираем активную кнопку мальчика
            nameImg.Image = Properties.Resources.user_icon_female; // меняем на активную картинку девочки имени
            surnameImg.Image = Properties.Resources.user_icon_female2; // фамилии
        }
        // /*/
        // Кнопка возврата назад в окно авторизации
        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            AuthorizationForm authorizationForm = new AuthorizationForm();
            authorizationForm.ShowDialog(); // открыть окно
        }
        // /*/
        // Настройка полей, чтобы удалялся текст "подсказка"
        private void nameField_Enter(object sender, EventArgs e)
        {
            if (nameField.Text == "Введите имя")
            {
                nameField.Text = "";
                nameField.ForeColor = Color.Gray;
            }
        }

        private void nameField_Leave(object sender, EventArgs e)
        {
            if (nameField.Text == "")
            {
                nameField.Text = "Введите имя";
                nameField.ForeColor = Color.Gray;
            }
        }

        private void loginField_Enter(object sender, EventArgs e)
        {
            if (loginField.Text == "Введите логин")
            {
                loginField.Text = "";
                loginField.ForeColor = Color.Gray;
            }
        }

        private void loginField_Leave(object sender, EventArgs e)
        {
            if (loginField.Text == "")
            {
                loginField.Text = "Введите логин";
                loginField.ForeColor = Color.Gray;
            }
        }

        private void surnameField_Enter(object sender, EventArgs e)
        {
            if (surnameField.Text == "Введите фамилию")
            {
                surnameField.Text = "";
                surnameField.ForeColor = Color.Gray;
            }
        }

        private void surnameField_Leave(object sender, EventArgs e)
        {
            if (surnameField.Text == "")
            {
                surnameField.Text = "Введите фамилию";
                surnameField.ForeColor = Color.Gray;
            }
        }

        private void emailField_Enter(object sender, EventArgs e)
        {
            if (studentIDField.Text == "Введите студенческий")
            {
                studentIDField.Text = "";
                studentIDField.ForeColor = Color.Gray;
            }
        }

        private void emailField_Leave(object sender, EventArgs e)
        {
            if (studentIDField.Text == "")
            {
                studentIDField.Text = "Введите студенческий";
                studentIDField.ForeColor = Color.Gray;
            }
        }

        private void phoneField_Enter(object sender, EventArgs e)
        {
            if (phoneField.Text == "Введите телефон")
            {
                phoneField.Text = "";
                phoneField.ForeColor = Color.Gray;
            }
        }

        private void phoneField_Leave(object sender, EventArgs e)
        {
            if (phoneField.Text == "")
            {
                phoneField.Text = "Введите телефон";
                phoneField.ForeColor = Color.Gray;
            }
        }

        private void passwordField_Enter(object sender, EventArgs e)
        {
            if (passwordField.Text == "Введите пароль")
            {
                passwordField.Text = "";
                passwordField.ForeColor = Color.Gray;
            }
        }

        private void passwordField_Leave(object sender, EventArgs e)
        {
            if (passwordField.Text == "")
            {
                passwordField.Text = "Введите пароль";
                passwordField.ForeColor = Color.Gray;
            }
        }

        private void passwordRepeatField_Enter(object sender, EventArgs e)
        {
            if (passwordRepeatField.Text == "Повторите пароль")
            {
                passwordRepeatField.Text = "";
                passwordRepeatField.ForeColor = Color.Gray;
            }
        }

        private void passwordRepeatField_Leave(object sender, EventArgs e)
        {
            if (passwordRepeatField.Text == "")
            {
                passwordRepeatField.Text = "Повторите пароль";
                passwordRepeatField.ForeColor = Color.Gray;
            }
            if (isEqualPass())
                checkPassImg.Image = Properties.Resources.sign_icon; // пояаляется галочка о совпадении пароля
        }
        // /*/
        // Настройка панелей во время ввода данных
        private void nameField_Click(object sender, EventArgs e)
        {
            nameField.Clear();
            panelName.BackColor = Color.FromArgb(255, 153, 0);
            nameField.ForeColor = Color.FromArgb(255, 153, 0);

            panelSurname.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void surnameField_Click(object sender, EventArgs e)
        {
            surnameField.Clear();
            panelSurname.BackColor = Color.FromArgb(255, 153, 0);
            surnameField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void loginField_Click(object sender, EventArgs e)
        {
            loginField.Clear();
            panelLogin.BackColor = Color.FromArgb(255, 153, 0);
            loginField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelSurname.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void emailField_Click(object sender, EventArgs e)
        {
            studentIDField.Clear();
            panelEmail.BackColor = Color.FromArgb(255, 153, 0);
            studentIDField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelSurname.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void phoneField_Click(object sender, EventArgs e)
        {
            phoneField.Clear();
            panelPhone.BackColor = Color.FromArgb(255, 153, 0);
            phoneField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelSurname.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void passwordField_Click(object sender, EventArgs e)
        {
            passwordField.Clear();
            panelPassword.BackColor = Color.FromArgb(255, 153, 0);
            passwordField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelSurname.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void passwordRepeatField_Click(object sender, EventArgs e)
        {
            passwordRepeatField.Clear();
            panelPasswordRepeat.BackColor = Color.FromArgb(255, 153, 0);
            passwordRepeatField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelSurname.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
        }

        // Проверка на заполнение всех полей
        public Boolean isFilled()
        {
            Boolean filled = false;

            if (nameField.Text != "Введите имя" || surnameField.Text != "Введите фамилию" || studentIDField.Text != "Ввелите студенческий" ||
                phoneField.Text != "Введите телефон" || loginField.Text != "Введите логин" || passwordField.Text != "" || passwordRepeatField.Text != "")
                filled = true;
            return filled;
        }
        // Проверка на совадение паролей
        public Boolean isEqualPass()
        {
            Boolean isEqual = false;

            if (passwordField.Text == passwordRepeatField.Text)
                isEqual = true;
            return isEqual;
        }
        // Проверка на корректность телефона
        public Boolean isRightPhone()
        {
            Boolean isRightPhone = false;

            if (Regex.IsMatch(phoneField.Text, @"\+7\d{3}\d{3}\d{4}$"))
                isRightPhone = true;

            return isRightPhone;
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            // Проверка на заполнение всех полей
            if (!isFilled())
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на не выбор пола
            else if (gender == "Пол не выбран")
            {
                MessageBox.Show("Выберите пол", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на существующий логин
            else if (CheckInfo.isLoginExists(connectDB, loginField.Text))
            {
                MessageBox.Show("Такой логин уже существует. Введите другой", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на существующий студак
            else if (CheckInfo.isStudentIDExists(connectDB, studentIDField.Text))
            {
                MessageBox.Show("Пользователь с таким студенческим уже существует. Введите другой", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на совадение паролей
            else if (!isEqualPass())
            {
                MessageBox.Show("Пароли не совпадают", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на корректность телефона
            else if (!isRightPhone())
            {
                MessageBox.Show("Задайте правильно номер телефона", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            { 
                string login = loginField.Text;
                string password = passwordField.Text;

                string name = nameField.Text;
                string surname = surnameField.Text;
                string phone = phoneField.Text;
                string studak = studentIDField.Text;
                string sex = gender;

                InsertInfo.InsertUser(connectDB, login, password);
                InsertInfo.InsertUserData(connectDB, name, surname, phone, studak, sex);
                UpdateInfo.UpLinenID(connectDB);
                UpdateInfo.UpItemID(connectDB);
                Student currentUser = GetInfo.GetStudentByLogin(connectDB, login, password);

                MessageBox.Show("Аккаунт был создан", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide(); // закрыть активное окно
                AuthorizationForm authorizatioForm = new AuthorizationForm();
                authorizatioForm.ShowDialog(); // открыть окно
            }
        }

        private void RegisterForm_Click(object sender, EventArgs e)
        {
            panelName.BackColor = Color.WhiteSmoke;
            panelSurname.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelPhone.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }
    }
}