﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccessToDB;
using DataStructures;


using System.Data.SqlClient;
using registration.masterDataSetTableAdapters;

namespace registration
{
    public partial class AddItemsForm : Form
    {
        Connector connectDB = new Connector();

        public AddItemsForm()
        {
            InitializeComponent();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
        }

        private void closeLabel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowChairBtn_Click(object sender, EventArgs e)
        {
            chairField.Clear();
            chairField.Visible = true;
            AddChairBtn.Visible = true;
            chairField.BringToFront();
            AddChairBtn.BringToFront();

            linenBox.Text = "Постель";

            ShowChairBtn.BackColor = Color.FloralWhite;

            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);

            dataGridChair.Visible = true;
            this.chairTableAdapter.Fill(this.masterDataSetChair.chair);
            dataGridChair.BringToFront();
            chairField.BringToFront();
            AddChairBtn.BringToFront();
        }

        private void ShowTablesBtn_Click(object sender, EventArgs e)
        {
            tableField.Clear();
            tableField.Visible = true;
            AddTableBtn.Visible = true;
            tableField.BringToFront();
            AddTableBtn.BringToFront();

            linenBox.Text = "Постель";

            ShowTablesBtn.BackColor = Color.FloralWhite;

            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);

            dataGridTables.Visible = true;
            this.tablesTableAdapter1.Fill(this.masterDataSetTables.tables);
            dataGridTables.BringToFront();
            tableField.BringToFront();
            AddTableBtn.BringToFront();
        }

        private void ShowWardrobeBtn_Click(object sender, EventArgs e)
        {
            wardrobeField.Clear();
            wardrobeField.Visible = true;
            AddWardrobeBtn.Visible = true;
            wardrobeField.BringToFront();
            AddWardrobeBtn.BringToFront();

            linenBox.Text = "Постель";

            ShowWardrobeBtn.BackColor = Color.FloralWhite;

            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);

            dataGridWardrobe.Visible = true;
            this.wardrobeTableAdapter.Fill(this.masterDataSetWardrobe.wardrobe);
            dataGridWardrobe.BringToFront();
            wardrobeField.BringToFront();
            AddWardrobeBtn.BringToFront();
        }

        private void ShowShelfBtn_Click(object sender, EventArgs e)
        {
            shelfField.Clear();
            shelfField.Visible = true;
            AddShelfBtn.Visible = true;
            shelfField.BringToFront();
            AddShelfBtn.BringToFront();

            linenBox.Text = "Постель";

            ShowShelfBtn.BackColor = Color.FloralWhite;

            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);

            dataGridShelf.Visible = true;
            this.shelfTableAdapter.Fill(this.masterDataSetShelf.shelf);
            dataGridShelf.BringToFront();
            shelfField.BringToFront();
            AddShelfBtn.BringToFront();
        }

        private void AddItemsForm_Load(object sender, EventArgs e)
        {
            dataGridShelf.Visible = false;
            dataGridWardrobe.Visible = false;
            dataGridTables.Visible = false;
            dataGridChair.Visible = false;

            dataGridBedsheet.Visible = false;
            dataGridBedspread.Visible = false;
            dataGridDuvet.Visible = false;
            dataGridPillowcase.Visible = false;
            dataGridTowel.Visible = false;

            chairField.Visible = false;
            tableField.Visible = false;
            shelfField.Visible = false;
            wardrobeField.Visible = false;
            bedsheetField.Visible = false;
            duvetField.Visible = false;
            pillowcaseField.Visible = false;
            towelField.Visible = false;
            bedspreadField.Visible = false;

            AddBedsheetBtn.Visible = false;
            AddBedspreadBtn.Visible = false;
            AddChairBtn.Visible = false;
            AddDuvetBtn.Visible = false;
            AddPillowcaseBtn.Visible = false;
            AddShelfBtn.Visible = false;
            AddTableBtn.Visible = false;
            AddWardrobeBtn.Visible = false;
            AddTowelBtn.Visible = false;
        }

        private void AddChairBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = chairField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "chair", serialNumber);
            this.chairTableAdapter.Fill(this.masterDataSetChair.chair);
            MessageBox.Show("Стул добавлен на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddTableBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = tableField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "tables", serialNumber);
            this.tablesTableAdapter1.Fill(this.masterDataSetTables.tables);
            MessageBox.Show("Стол добавлен на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddWardrobeBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = wardrobeField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "wardrobe", serialNumber);
            this.wardrobeTableAdapter.Fill(this.masterDataSetWardrobe.wardrobe);
            MessageBox.Show("Шкаф добавлен на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddShelfBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = shelfField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "shelf", serialNumber);
            this.shelfTableAdapter.Fill(this.masterDataSetShelf.shelf);
            MessageBox.Show("Полка добавлена на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddTowelBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = towelField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "towel", serialNumber);
            this.towelTableAdapter.Fill(this.masterDataSetTowel.towel);
            MessageBox.Show("Полотенце добавлено на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddBedspreadBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = bedspreadField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "bedspread", serialNumber);
            this.bedspreadTableAdapter.Fill(this.masterDataSetBedspread.bedspread);
            MessageBox.Show("Покрывало добавлено на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddBedsheetBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = bedsheetField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "bedsheet", serialNumber);
            this.bedsheetTableAdapter.Fill(this.masterDataSetBedsheet.bedsheet);
            MessageBox.Show("Простыня добавлена на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddDuvetBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = duvetField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "duvet", serialNumber);
            this.duvetTableAdapter.Fill(this.masterDataSetDuvet.duvet);
            MessageBox.Show("Пододеяльник добавлен на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddPillowcaseBtn_Click(object sender, EventArgs e)
        {
            string serialNumber = pillowcaseField.Text;
            if (serialNumber.Length != 6)
            {
                MessageBox.Show("Неверная длина номера (<6)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            InsertInfo.InsertItemStorage(connectDB, "pillowcase", serialNumber);
            this.pillowcaseTableAdapter1.Fill(this.masterDataSetPillowcase1.pillowcase);
            MessageBox.Show("Наволочка добавлено на склад", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void linenBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            linenBox.BackColor = Color.FloralWhite;

            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);

            if (linenBox.SelectedItem.ToString() == "Простыня")
            {
                bedsheetField.Clear();
                bedsheetField.Visible = true;
                AddBedsheetBtn.Visible = true;
                bedsheetField.BringToFront();
                AddBedsheetBtn.BringToFront();

                dataGridBedsheet.Visible = true;
                this.bedsheetTableAdapter.Fill(this.masterDataSetBedsheet.bedsheet);

                dataGridBedsheet.BringToFront();
                bedsheetField.BringToFront();
                AddBedsheetBtn.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Наволочка")
            {
                pillowcaseField.Clear();
                pillowcaseField.Visible = true;
                AddPillowcaseBtn.Visible = true;
                pillowcaseField.BringToFront();
                AddPillowcaseBtn.BringToFront();

                dataGridPillowcase.Visible = true;
                this.pillowcaseTableAdapter1.Fill(this.masterDataSetPillowcase1.pillowcase);

                dataGridPillowcase.BringToFront();
                pillowcaseField.BringToFront();
                AddPillowcaseBtn.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Пододеяльник")
            {
                duvetField.Clear();
                duvetField.Visible = true;
                AddDuvetBtn.Visible = true;
                duvetField.BringToFront();
                AddDuvetBtn.BringToFront();

                dataGridDuvet.Visible = true;
                this.duvetTableAdapter.Fill(this.masterDataSetDuvet.duvet);

                dataGridDuvet.BringToFront();
                duvetField.BringToFront();
                AddDuvetBtn.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Покрывало")
            {
                bedspreadField.Clear();
                bedspreadField.Visible = true;
                AddBedspreadBtn.Visible = true;
                bedspreadField.BringToFront();
                AddBedspreadBtn.BringToFront();

                dataGridBedspread.Visible = true;
                this.bedspreadTableAdapter.Fill(this.masterDataSetBedspread.bedspread);

                dataGridBedspread.BringToFront();
                bedspreadField.BringToFront();
                AddBedspreadBtn.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Полотенце")
            {
                towelField.Clear();
                towelField.Visible = true;
                AddTowelBtn.Visible = true;
                towelField.BringToFront();
                AddTowelBtn.BringToFront();

                dataGridTowel.Visible = true;
                this.towelTableAdapter.Fill(this.masterDataSetTowel.towel);

                dataGridTowel.BringToFront();
                towelField.BringToFront();
                AddTowelBtn.BringToFront();
            }
        }
    }
}
