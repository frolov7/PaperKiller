﻿using AccessToDB;
using DataStructures;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace registration
{
    public partial class TakeItemForm : Form
    {
        Student currentStudent;

        Linen currentLinen = null;
        Items currentItems = null;

        Chair currentChair = null;
        Table currentTable = null;
        Shelf currentShelf = null;
        Wardrobe currentWardrobe = null;

        Bedsheet currentBedsheet = null;
        Pillowcase currentPillowcase = null;
        Duvet currentDuvet = null;
        Bedspread currentBedspread = null;
        Towel currentTowel = null;

        Connector connectDB = new Connector();

        public TakeItemForm()
        {
            InitializeComponent();
            /*
            nameField.Text = "Имя студента";
            nameField.ForeColor = Color.Gray;

            surnameField.Text = "Фамилия студента";
            surnameField.ForeColor = Color.Gray;

            roomField.Text = "Номер комнаты";
            roomField.ForeColor = Color.Gray;
            */
        }

        private void TakeItemForm_Load(object sender, EventArgs e)
        {
            LinenBox.Visible = false;
            ItemBox.Visible = false;

            ChairGiveBtn.Visible = false;
            TableGiveBtn.Visible = false;
            ShelfGiveBtn.Visible = false;
            WardrobeGiveBtn.Visible = false;

            BedsheetGiveBtn.Visible = false;
            PillowcaseGiveBtn.Visible = false;
            DuvetGiveBtn.Visible = false;
            BedspreadGiveBtn.Visible = false;
            TowelGiveBtn.Visible = false;
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
        }

        private void ShowItemBtn_Click(object sender, EventArgs e)
        {
            if (currentStudent == null)
            {
                //MessageBox.Show("Студент не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resultLabel.Text = "Не найден";
                checkStudentImg.Image = Properties.Resources.error_icon;
                return;
            }

            LinenBox.Visible = false;
            ItemBox.Visible = true;

            ChairGiveBtn.Visible = true;
            TableGiveBtn.Visible = true;
            ShelfGiveBtn.Visible = true;
            WardrobeGiveBtn.Visible = true;

            BedsheetGiveBtn.Visible = false;
            PillowcaseGiveBtn.Visible = false;
            DuvetGiveBtn.Visible = false;
            BedspreadGiveBtn.Visible = false;
            TowelGiveBtn.Visible = false;

            if (currentItems.chairID != 0)
            {
                ChairTmpLabel.Text = "У студента";
                ChairSNlabel.Text = currentChair.serialNumber.ToString();
            }
            else
            {
                ChairTmpLabel.Text = "Пусто";
                ChairSNlabel.Text = "Пусто";
            }

            if (currentItems.tableID != 0)
            {
                TableTmpLabel.Text = "У студента";
                TableSNLabel.Text = currentTable.serialNumber.ToString();
            }
            else
            {
                TableTmpLabel.Text = "Пусто";
                TableSNLabel.Text = "Пусто";
            }

            if (currentItems.shelfID != 0)
            {
                ShelfTmpLabel.Text = "У студента";
                ShelfSNlabel.Text = currentShelf.serialNumber.ToString();
            }
            else
            {
                ShelfTmpLabel.Text = "Пусто";
                ShelfSNlabel.Text = "Пусто";
            }

            if (currentItems.wardrobeID != 0)
            {
                WardrobeTmpLabel.Text = "У студента";
                WardrobeSNlabel.Text = currentWardrobe.serialNumber.ToString();
            }
            else
            {
                WardrobeTmpLabel.Text = "Пусто";
                WardrobeSNlabel.Text = "Пусто";
            }
        }

        private void ShowLinenBtn_Click(object sender, EventArgs e)
        {
            if (currentStudent == null)
            {
                //MessageBox.Show("Студент не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resultLabel.Text = "Не найден";
                checkStudentImg.Image = Properties.Resources.error_icon;
                return;
            }

            LinenBox.Visible = true;
            ItemBox.Visible = false;

            ChairGiveBtn.Visible = false;
            TableGiveBtn.Visible = false;
            ShelfGiveBtn.Visible = false;
            WardrobeGiveBtn.Visible = false;

            BedsheetGiveBtn.Visible = true;
            PillowcaseGiveBtn.Visible = true;
            DuvetGiveBtn.Visible = true;
            BedspreadGiveBtn.Visible = true;
            TowelGiveBtn.Visible = true;

            if (currentLinen.bedsheetID != 0)
            {
                bedsheetTmpLabel.Text = "У студента";
                bedsheetSNlabel.Text = currentBedsheet.serialNumber.ToString();
            }
            else
            {
                bedsheetTmpLabel.Text = "Пусто";
                bedsheetSNlabel.Text = "Пусто";
            }

            if (currentLinen.pillowcaseID != 0)
            {
                pillowcaseTmpLabel.Text = "У студента";
                pillowcaseSNLabel.Text = currentPillowcase.serialNumber.ToString();
            }
            else
            {
                pillowcaseTmpLabel.Text = "Пусто";
                pillowcaseSNLabel.Text = "Пусто";
            }

            if (currentLinen.duvetID != 0)
            {
                duvetTmpLabel.Text = "У студента";
                duvetSNlabel.Text = currentDuvet.serialNumber.ToString();
            }
            else
            {
                duvetTmpLabel.Text = "Пусто";
                duvetSNlabel.Text = "Пусто";
            }

            if (currentLinen.bedspreadID != 0)
            {
                bedspreadTmpLabel.Text = "У студента";
                bedspreadSNlabel.Text = currentBedspread.serialNumber.ToString();
            }
            else
            {
                bedspreadTmpLabel.Text = "Пусто";
                bedspreadSNlabel.Text = "Пусто";
            }

            if (currentLinen.towelID != 0)
            {
                towelTmpLabel.Text = "У студента";
                towelSNlabel.Text = currentTowel.serialNumber.ToString();
            }
            else
            {
                towelTmpLabel.Text = "Пусто";
                towelSNlabel.Text = "Пусто";
            }
        }

        private void nameField_Click(object sender, EventArgs e)
        {
            nameField.Clear();
            panelName.BackColor = Color.FromArgb(255, 153, 0);
            nameField.ForeColor = Color.FromArgb(255, 153, 0);

            panelSurname.BackColor = Color.WhiteSmoke;
            panelRoom.BackColor = Color.WhiteSmoke;
        }

        private void surnameField_Click(object sender, EventArgs e)
        {
            surnameField.Clear();
            panelSurname.BackColor = Color.FromArgb(255, 153, 0);
            surnameField.ForeColor = Color.FromArgb(255, 153, 0);

            panelName.BackColor = Color.WhiteSmoke;
            panelRoom.BackColor = Color.WhiteSmoke;
        }

        private void roomField_Click(object sender, EventArgs e)
        {
            roomField.Clear();
            panelRoom.BackColor = Color.FromArgb(255, 153, 0);
            roomField.ForeColor = Color.FromArgb(255, 153, 0);

            panelSurname.BackColor = Color.WhiteSmoke;
            panelName.BackColor = Color.WhiteSmoke;
        }

        private void nameField_Enter(object sender, EventArgs e)
        {
            if (nameField.Text == "Имя студента")
            {
                nameField.Text = "";
                nameField.ForeColor = Color.Gray;
            }
        }

        private void nameField_Leave(object sender, EventArgs e)
        {
            if (nameField.Text == "")
            {
                nameField.Text = "Имя студента";
                nameField.ForeColor = Color.Gray;
            }
        }

        private void surnameField_Enter(object sender, EventArgs e)
        {
            if (surnameField.Text == "Фамилия студента")
            {
                surnameField.Text = "";
                surnameField.ForeColor = Color.Gray;
            }
        }

        private void surnameField_Leave(object sender, EventArgs e)
        {
            if (surnameField.Text == "")
            {
                surnameField.Text = "Фамилия студента";
                surnameField.ForeColor = Color.Gray;
            }
        }

        private void roomField_Enter(object sender, EventArgs e)
        {
            if (roomField.Text == "Номер комнаты")
            {
                roomField.Text = "";
                roomField.ForeColor = Color.Gray;
            }
        }

        private void roomField_Leave(object sender, EventArgs e)
        {
            if (roomField.Text == "")
            {
                roomField.Text = "Номер комнаты";
                roomField.ForeColor = Color.Gray;
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            currentStudent = GetInfo.GetStudentByRoom(connectDB, nameField.Text, surnameField.Text, roomField.Text);
            if (currentStudent == null)
            {
                //MessageBox.Show("Студент не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resultLabel.Text = "Не найден";
                checkStudentImg.Image = Properties.Resources.error_icon;
                return;
            }
            else
            {
                resultLabel.Text = "Найден";
                checkStudentImg.Image = Properties.Resources.sign_icon;
                currentLinen = GetInfo.GetLinenByID(connectDB, currentStudent.userID);
                currentItems = GetInfo.GetItemsByID(connectDB, currentStudent.userID);

                currentChair = GetInfo.GetChairByID(connectDB, currentStudent.userID);
                currentTable = GetInfo.GetTableByID(connectDB, currentStudent.userID);
                currentShelf = GetInfo.GetShelfByID(connectDB, currentStudent.userID);
                currentWardrobe = GetInfo.GetWardrobeByID(connectDB, currentStudent.userID);

                currentBedsheet = GetInfo.GetBedsheetByID(connectDB, currentLinen.linenID);
                currentPillowcase = GetInfo.GetPillowcaseByID(connectDB, currentLinen.linenID);
                currentDuvet = GetInfo.GetDuvetByID(connectDB, currentLinen.linenID);
                currentBedspread = GetInfo.GetBedspreadByID(connectDB, currentLinen.linenID);
                currentTowel = GetInfo.GetTowelByID(connectDB, currentLinen.linenID);
            }
        }

        private void BedsheetGiveBtn_Click(object sender, EventArgs e)
        {
            if (bedsheetSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "bedsheet_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "bedsheet", "На складе", currentBedsheet.bedsheetID);
            bedsheetTmpLabel.Text = "Пусто";
            bedsheetSNlabel.Text = "Пусто";
        }

        private void PillowcaseGiveBtn_Click(object sender, EventArgs e)
        {
            if (pillowcaseSNLabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "pillowcase_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "pillowcase", "На складе", currentPillowcase.pillowcaseID);
            pillowcaseTmpLabel.Text = "Пусто";
            pillowcaseSNLabel.Text = "Пусто";
        }

        private void DuvetGiveBtn_Click(object sender, EventArgs e)
        {
            if (duvetSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "duvet_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "duvet", "На складе", currentDuvet.duvetID);
            duvetTmpLabel.Text = "Пусто";
            duvetSNlabel.Text = "Пусто";
        }

        private void BedspreadGiveBtn_Click(object sender, EventArgs e)
        {
            if (bedspreadSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "bedspread_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "bedspread", "На складе", currentBedspread.bedspreadID);
            bedspreadTmpLabel.Text = "Пусто";
            bedspreadSNlabel.Text = "Пусто";
        }

        private void TowelGiveBtn_Click(object sender, EventArgs e)
        {
            if (towelSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "towel_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "towel", "На складе", currentTowel.towelID);
            towelTmpLabel.Text = "Пусто";
            towelSNlabel.Text = "Пусто";
        }

        private void ChairGiveBtn_Click(object sender, EventArgs e)
        {
            if (ChairSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "chair_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "chair", "На складе", currentItems.chairID.ToString());
            ChairTmpLabel.Text = "Пусто";
            ChairSNlabel.Text = "Пусто";
        }

        private void TableGiveBtn_Click(object sender, EventArgs e)
        {
            if (TableSNLabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "tables_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "tables", "На складе", currentItems.tableID.ToString());
            TableTmpLabel.Text = "Пусто";
            TableSNLabel.Text = "Пусто";
        }

        private void ShelfGiveBtn_Click(object sender, EventArgs e)
        {
            if (ShelfSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "shelf_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "shelf", "На складе", currentItems.shelfID.ToString());
            ShelfTmpLabel.Text = "Пусто";
            ShelfSNlabel.Text = "Пусто";
        }

        private void WardrobeGiveBtn_Click(object sender, EventArgs e)
        {
            if (WardrobeSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "wardrobe_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "wardrobe", "На складе", currentItems.wardrobeID.ToString());
            WardrobeTmpLabel.Text = "Пусто";
            WardrobeSNlabel.Text = "Пусто";
        }
    }
}
