﻿using AccessToDB;
using DataStructures;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registration
{
    public partial class ForgetPassForm : Form
    {
        Connector connectDB = new Connector();
        public ForgetPassForm()
        {
            InitializeComponent();

            loginField.Text = "Введите логин";
            loginField.ForeColor = Color.Gray;

            studentIDField.Text = "Введите студенческий";
            studentIDField.ForeColor = Color.Gray;

            passwordField.Text = "Введите пароль";
            passwordField.ForeColor = Color.Gray;

            passwordRepeatField.Text = "Повторите пароль";
            passwordRepeatField.ForeColor = Color.Gray;
        }

        private void closeLabel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            AuthorizationForm authorizationForm = new AuthorizationForm();
            authorizationForm.ShowDialog(); // открыть окно
        }

        private void loginField_Enter(object sender, EventArgs e)
        {
            if (loginField.Text == "Введите логин")
            {
                loginField.Text = "";
                loginField.ForeColor = Color.Gray;
            }
        }

        private void loginField_Leave(object sender, EventArgs e)
        {
            if (loginField.Text == "")
            {
                loginField.Text = "Введите логин";
                loginField.ForeColor = Color.Gray;
            }
        }

        private void studentIDField_Enter(object sender, EventArgs e)
        {
            if (studentIDField.Text == "Введите студенческий")
            {
                studentIDField.Text = "";
                studentIDField.ForeColor = Color.Gray;
            }
        }

        private void studentIDField_Leave(object sender, EventArgs e)
        {
            if (studentIDField.Text == "")
            {
                studentIDField.Text = "Введите студенческий";
                studentIDField.ForeColor = Color.Gray;
            }
        }

        private void passwordField_Enter(object sender, EventArgs e)
        {
            if (passwordField.Text == "Введите пароль")
            {
                passwordField.Text = "";
                passwordField.ForeColor = Color.Gray;
            }
        }

        private void passwordField_Leave(object sender, EventArgs e)
        {
            if (passwordField.Text == "")
            {
                passwordField.Text = "Введите пароль";
                passwordField.ForeColor = Color.Gray;
            }
        }

        private void passwordRepeatField_Enter(object sender, EventArgs e)
        {
            if (passwordRepeatField.Text == "Повторите пароль")
            {
                passwordRepeatField.Text = "";
                passwordRepeatField.ForeColor = Color.Gray;
            }
        }

        private void passwordRepeatField_Leave(object sender, EventArgs e)
        {
            if (passwordRepeatField.Text == "")
            {
                passwordRepeatField.Text = "Повторите пароль";
                passwordRepeatField.ForeColor = Color.Gray;
            }
            if (isEqualPass())
                checkPassImg.Image = Properties.Resources.sign_icon; // пояаляется галочка о совпадении пароля
        }

        private void loginField_Click(object sender, EventArgs e)
        {
            loginField.Clear();
            panelLogin.BackColor = Color.FromArgb(255, 153, 0);
            loginField.ForeColor = Color.FromArgb(255, 153, 0);

            panelEmail.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void studentIDField_Click(object sender, EventArgs e)
        {
            studentIDField.Clear();
            panelEmail.BackColor = Color.FromArgb(255, 153, 0);
            studentIDField.ForeColor = Color.FromArgb(255, 153, 0);

            panelLogin.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void passwordField_Click(object sender, EventArgs e)
        {
            passwordField.Clear();
            panelPassword.BackColor = Color.FromArgb(255, 153, 0);
            passwordField.ForeColor = Color.FromArgb(255, 153, 0);

            panelLogin.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        private void passwordRepeatField_Click(object sender, EventArgs e)
        {
            passwordRepeatField.Clear();
            panelPasswordRepeat.BackColor = Color.FromArgb(255, 153, 0);
            passwordRepeatField.ForeColor = Color.FromArgb(255, 153, 0);

            panelLogin.BackColor = Color.WhiteSmoke;
            panelEmail.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
        }

        private void ForgetPassForm_Click(object sender, EventArgs e)
        {
            panelEmail.BackColor = Color.WhiteSmoke;
            panelLogin.BackColor = Color.WhiteSmoke;
            panelPassword.BackColor = Color.WhiteSmoke;
            panelPasswordRepeat.BackColor = Color.WhiteSmoke;
        }

        // Проверка на заполнение всех полей
        public Boolean isFilled()
        {
            Boolean filled = false;

            if (studentIDField.Text != "Введите студенческий" || loginField.Text != "Введите логин" || passwordField.Text != "" || passwordRepeatField.Text != "")
                filled = true;
            return filled;
        }
        // Проверка на совадение паролей
        public Boolean isEqualPass()
        {
            Boolean isEqual = false;

            if (passwordField.Text == passwordRepeatField.Text)
                isEqual = true;
            return isEqual;
        }
        private void changePassBtn_Click(object sender, EventArgs e)
        {
            // Проверка на заполнение всех полей
            if (!isFilled())
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на существующий логин
            else if (!CheckInfo.isLoginExists(connectDB, loginField.Text))
            {
                MessageBox.Show("Пользователя с таким логином не обнаружено", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на существующий студак
            else if (!CheckInfo.isStudentIDExists(connectDB, studentIDField.Text))
            {
                MessageBox.Show("Пользователя с таким студенческим не обнаружено. Введите другой", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на совадение паролей
            else if (!isEqualPass())
            {
                MessageBox.Show("Пароли не совпадают", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                string login = loginField.Text;
                string password = passwordField.Text;

                string studak = studentIDField.Text;

                UpdateInfo.UpdatePassword(connectDB, login, password);

                MessageBox.Show("Пароль был изменен", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide(); // закрыть активное окно
                AuthorizationForm authorizatioForm = new AuthorizationForm();
                authorizatioForm.ShowDialog(); // открыть окно
            }
        }
    }
}
