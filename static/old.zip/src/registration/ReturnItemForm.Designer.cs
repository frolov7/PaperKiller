﻿namespace registration
{
    partial class ReturnItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.goBackBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.TableLabel = new System.Windows.Forms.Label();
            this.ChairLabel = new System.Windows.Forms.Label();
            this.ShelfLabel = new System.Windows.Forms.Label();
            this.WardrobeLabel = new System.Windows.Forms.Label();
            this.WardrobeTmpLabel = new System.Windows.Forms.Label();
            this.ShelfTmpLabel = new System.Windows.Forms.Label();
            this.TableTmpLabel = new System.Windows.Forms.Label();
            this.ChairTmpLabel = new System.Windows.Forms.Label();
            this.ChairPassBtn = new System.Windows.Forms.Button();
            this.TablePassBtn = new System.Windows.Forms.Button();
            this.ShelfPassBtn = new System.Windows.Forms.Button();
            this.WardrobePassBtn = new System.Windows.Forms.Button();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ChairSNlabel = new System.Windows.Forms.Label();
            this.TableSNLabel = new System.Windows.Forms.Label();
            this.WardrobeSNlabel = new System.Windows.Forms.Label();
            this.ShelfSNlabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.NameLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.changeWardrobeBtn = new System.Windows.Forms.Button();
            this.changeShelfBtn = new System.Windows.Forms.Button();
            this.changeTableBtn = new System.Windows.Forms.Button();
            this.changeChairBtn = new System.Windows.Forms.Button();
            this.getWardrobeBtn = new System.Windows.Forms.Button();
            this.getShelfBtn = new System.Windows.Forms.Button();
            this.getTableBtn = new System.Windows.Forms.Button();
            this.getChairBtn = new System.Windows.Forms.Button();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(571, 642);
            this.goBackBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(333, 49);
            this.goBackBtn.TabIndex = 58;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(1428, 4);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 57;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(571, 73);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(893, 103);
            this.mainPanel.TabIndex = 56;
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(60, 10);
            this.registrationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(424, 74);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Сдать вещь";
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(39, 81);
            this.logoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 55;
            this.logoLabel.Text = "PaperKiller";
            // 
            // TableLabel
            // 
            this.TableLabel.AutoSize = true;
            this.TableLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableLabel.Location = new System.Drawing.Point(97, 338);
            this.TableLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TableLabel.Name = "TableLabel";
            this.TableLabel.Size = new System.Drawing.Size(75, 36);
            this.TableLabel.TabIndex = 59;
            this.TableLabel.Text = "Стол";
            // 
            // ChairLabel
            // 
            this.ChairLabel.AutoSize = true;
            this.ChairLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairLabel.Location = new System.Drawing.Point(97, 271);
            this.ChairLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ChairLabel.Name = "ChairLabel";
            this.ChairLabel.Size = new System.Drawing.Size(75, 36);
            this.ChairLabel.TabIndex = 60;
            this.ChairLabel.Text = "Стул";
            // 
            // ShelfLabel
            // 
            this.ShelfLabel.AutoSize = true;
            this.ShelfLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfLabel.Location = new System.Drawing.Point(97, 406);
            this.ShelfLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ShelfLabel.Name = "ShelfLabel";
            this.ShelfLabel.Size = new System.Drawing.Size(93, 36);
            this.ShelfLabel.TabIndex = 61;
            this.ShelfLabel.Text = "Полка";
            // 
            // WardrobeLabel
            // 
            this.WardrobeLabel.AutoSize = true;
            this.WardrobeLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeLabel.Location = new System.Drawing.Point(97, 474);
            this.WardrobeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WardrobeLabel.Name = "WardrobeLabel";
            this.WardrobeLabel.Size = new System.Drawing.Size(90, 36);
            this.WardrobeLabel.TabIndex = 62;
            this.WardrobeLabel.Text = "Шкаф";
            // 
            // WardrobeTmpLabel
            // 
            this.WardrobeTmpLabel.AutoSize = true;
            this.WardrobeTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeTmpLabel.Location = new System.Drawing.Point(633, 474);
            this.WardrobeTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WardrobeTmpLabel.Name = "WardrobeTmpLabel";
            this.WardrobeTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.WardrobeTmpLabel.TabIndex = 65;
            this.WardrobeTmpLabel.Text = "status";
            // 
            // ShelfTmpLabel
            // 
            this.ShelfTmpLabel.AutoSize = true;
            this.ShelfTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfTmpLabel.Location = new System.Drawing.Point(633, 406);
            this.ShelfTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ShelfTmpLabel.Name = "ShelfTmpLabel";
            this.ShelfTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.ShelfTmpLabel.TabIndex = 66;
            this.ShelfTmpLabel.Text = "status";
            // 
            // TableTmpLabel
            // 
            this.TableTmpLabel.AutoSize = true;
            this.TableTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableTmpLabel.Location = new System.Drawing.Point(633, 338);
            this.TableTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TableTmpLabel.Name = "TableTmpLabel";
            this.TableTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.TableTmpLabel.TabIndex = 67;
            this.TableTmpLabel.Text = "status";
            // 
            // ChairTmpLabel
            // 
            this.ChairTmpLabel.AutoSize = true;
            this.ChairTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairTmpLabel.Location = new System.Drawing.Point(633, 271);
            this.ChairTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ChairTmpLabel.Name = "ChairTmpLabel";
            this.ChairTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.ChairTmpLabel.TabIndex = 68;
            this.ChairTmpLabel.Text = "status";
            // 
            // ChairPassBtn
            // 
            this.ChairPassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChairPassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChairPassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChairPassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ChairPassBtn.Location = new System.Drawing.Point(908, 271);
            this.ChairPassBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ChairPassBtn.Name = "ChairPassBtn";
            this.ChairPassBtn.Size = new System.Drawing.Size(145, 44);
            this.ChairPassBtn.TabIndex = 69;
            this.ChairPassBtn.Text = "Сдать";
            this.ChairPassBtn.UseVisualStyleBackColor = false;
            this.ChairPassBtn.Click += new System.EventHandler(this.ChairPassBtn_Click);
            // 
            // TablePassBtn
            // 
            this.TablePassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TablePassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TablePassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TablePassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.TablePassBtn.Location = new System.Drawing.Point(908, 338);
            this.TablePassBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TablePassBtn.Name = "TablePassBtn";
            this.TablePassBtn.Size = new System.Drawing.Size(145, 44);
            this.TablePassBtn.TabIndex = 70;
            this.TablePassBtn.Text = "Сдать";
            this.TablePassBtn.UseVisualStyleBackColor = false;
            this.TablePassBtn.Click += new System.EventHandler(this.TablePassBtn_Click);
            // 
            // ShelfPassBtn
            // 
            this.ShelfPassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShelfPassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShelfPassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShelfPassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShelfPassBtn.Location = new System.Drawing.Point(908, 406);
            this.ShelfPassBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ShelfPassBtn.Name = "ShelfPassBtn";
            this.ShelfPassBtn.Size = new System.Drawing.Size(145, 44);
            this.ShelfPassBtn.TabIndex = 71;
            this.ShelfPassBtn.Text = "Сдать";
            this.ShelfPassBtn.UseVisualStyleBackColor = false;
            this.ShelfPassBtn.Click += new System.EventHandler(this.ShelfPassBtn_Click);
            // 
            // WardrobePassBtn
            // 
            this.WardrobePassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WardrobePassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WardrobePassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WardrobePassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.WardrobePassBtn.Location = new System.Drawing.Point(908, 474);
            this.WardrobePassBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.WardrobePassBtn.Name = "WardrobePassBtn";
            this.WardrobePassBtn.Size = new System.Drawing.Size(145, 44);
            this.WardrobePassBtn.TabIndex = 72;
            this.WardrobePassBtn.Text = "Сдать";
            this.WardrobePassBtn.UseVisualStyleBackColor = false;
            this.WardrobePassBtn.Click += new System.EventHandler(this.WardrobePassBtn_Click);
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(273, 278);
            this.panelPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(1, 260);
            this.panelPassword.TabIndex = 87;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(863, 287);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 260);
            this.panel1.TabIndex = 88;
            // 
            // ChairSNlabel
            // 
            this.ChairSNlabel.AutoSize = true;
            this.ChairSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairSNlabel.Location = new System.Drawing.Point(333, 271);
            this.ChairSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ChairSNlabel.Name = "ChairSNlabel";
            this.ChairSNlabel.Size = new System.Drawing.Size(176, 36);
            this.ChairSNlabel.TabIndex = 89;
            this.ChairSNlabel.Text = "serialNumber";
            // 
            // TableSNLabel
            // 
            this.TableSNLabel.AutoSize = true;
            this.TableSNLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableSNLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableSNLabel.Location = new System.Drawing.Point(333, 338);
            this.TableSNLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TableSNLabel.Name = "TableSNLabel";
            this.TableSNLabel.Size = new System.Drawing.Size(176, 36);
            this.TableSNLabel.TabIndex = 90;
            this.TableSNLabel.Text = "serialNumber";
            // 
            // WardrobeSNlabel
            // 
            this.WardrobeSNlabel.AutoSize = true;
            this.WardrobeSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeSNlabel.Location = new System.Drawing.Point(333, 474);
            this.WardrobeSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WardrobeSNlabel.Name = "WardrobeSNlabel";
            this.WardrobeSNlabel.Size = new System.Drawing.Size(176, 36);
            this.WardrobeSNlabel.TabIndex = 92;
            this.WardrobeSNlabel.Text = "serialNumber";
            // 
            // ShelfSNlabel
            // 
            this.ShelfSNlabel.AutoSize = true;
            this.ShelfSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfSNlabel.Location = new System.Drawing.Point(333, 406);
            this.ShelfSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ShelfSNlabel.Name = "ShelfSNlabel";
            this.ShelfSNlabel.Size = new System.Drawing.Size(176, 36);
            this.ShelfSNlabel.TabIndex = 91;
            this.ShelfSNlabel.Text = "serialNumber";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(563, 274);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 260);
            this.panel2.TabIndex = 88;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(73, 266);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(813, 1);
            this.panel3.TabIndex = 89;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NameLabel.Location = new System.Drawing.Point(93, 226);
            this.NameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(96, 26);
            this.NameLabel.TabIndex = 94;
            this.NameLabel.Text = "Название";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(307, 226);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 26);
            this.label6.TabIndex = 95;
            this.label6.Text = "Серийный номер";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(616, 226);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 26);
            this.label7.TabIndex = 96;
            this.label7.Text = "Статус предмета";
            // 
            // changeWardrobeBtn
            // 
            this.changeWardrobeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeWardrobeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeWardrobeBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeWardrobeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeWardrobeBtn.Location = new System.Drawing.Point(1088, 474);
            this.changeWardrobeBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.changeWardrobeBtn.Name = "changeWardrobeBtn";
            this.changeWardrobeBtn.Size = new System.Drawing.Size(155, 44);
            this.changeWardrobeBtn.TabIndex = 100;
            this.changeWardrobeBtn.Text = "Обменять";
            this.changeWardrobeBtn.UseVisualStyleBackColor = false;
            this.changeWardrobeBtn.Click += new System.EventHandler(this.changeWardrobeBtn_Click);
            // 
            // changeShelfBtn
            // 
            this.changeShelfBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeShelfBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeShelfBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeShelfBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeShelfBtn.Location = new System.Drawing.Point(1088, 406);
            this.changeShelfBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.changeShelfBtn.Name = "changeShelfBtn";
            this.changeShelfBtn.Size = new System.Drawing.Size(155, 44);
            this.changeShelfBtn.TabIndex = 99;
            this.changeShelfBtn.Text = "Обменять";
            this.changeShelfBtn.UseVisualStyleBackColor = false;
            this.changeShelfBtn.Click += new System.EventHandler(this.changeShelfBtn_Click);
            // 
            // changeTableBtn
            // 
            this.changeTableBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeTableBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeTableBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeTableBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeTableBtn.Location = new System.Drawing.Point(1088, 338);
            this.changeTableBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.changeTableBtn.Name = "changeTableBtn";
            this.changeTableBtn.Size = new System.Drawing.Size(155, 44);
            this.changeTableBtn.TabIndex = 98;
            this.changeTableBtn.Text = "Обменять";
            this.changeTableBtn.UseVisualStyleBackColor = false;
            this.changeTableBtn.Click += new System.EventHandler(this.changeTableBtn_Click);
            // 
            // changeChairBtn
            // 
            this.changeChairBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changeChairBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeChairBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeChairBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changeChairBtn.Location = new System.Drawing.Point(1088, 271);
            this.changeChairBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.changeChairBtn.Name = "changeChairBtn";
            this.changeChairBtn.Size = new System.Drawing.Size(155, 44);
            this.changeChairBtn.TabIndex = 97;
            this.changeChairBtn.Text = "Обменять";
            this.changeChairBtn.UseVisualStyleBackColor = false;
            this.changeChairBtn.Click += new System.EventHandler(this.changeChairBtn_Click);
            // 
            // getWardrobeBtn
            // 
            this.getWardrobeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getWardrobeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getWardrobeBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getWardrobeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getWardrobeBtn.Location = new System.Drawing.Point(1284, 474);
            this.getWardrobeBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.getWardrobeBtn.Name = "getWardrobeBtn";
            this.getWardrobeBtn.Size = new System.Drawing.Size(145, 44);
            this.getWardrobeBtn.TabIndex = 105;
            this.getWardrobeBtn.Text = "Получить";
            this.getWardrobeBtn.UseVisualStyleBackColor = false;
            this.getWardrobeBtn.Click += new System.EventHandler(this.getWardrobeBtn_Click);
            // 
            // getShelfBtn
            // 
            this.getShelfBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getShelfBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getShelfBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getShelfBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getShelfBtn.Location = new System.Drawing.Point(1284, 406);
            this.getShelfBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.getShelfBtn.Name = "getShelfBtn";
            this.getShelfBtn.Size = new System.Drawing.Size(145, 44);
            this.getShelfBtn.TabIndex = 104;
            this.getShelfBtn.Text = "Получить";
            this.getShelfBtn.UseVisualStyleBackColor = false;
            this.getShelfBtn.Click += new System.EventHandler(this.getShelfBtn_Click);
            // 
            // getTableBtn
            // 
            this.getTableBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getTableBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getTableBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getTableBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getTableBtn.Location = new System.Drawing.Point(1284, 338);
            this.getTableBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.getTableBtn.Name = "getTableBtn";
            this.getTableBtn.Size = new System.Drawing.Size(145, 44);
            this.getTableBtn.TabIndex = 103;
            this.getTableBtn.Text = "Получить";
            this.getTableBtn.UseVisualStyleBackColor = false;
            this.getTableBtn.Click += new System.EventHandler(this.getTableBtn_Click);
            // 
            // getChairBtn
            // 
            this.getChairBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.getChairBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getChairBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getChairBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.getChairBtn.Location = new System.Drawing.Point(1284, 271);
            this.getChairBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.getChairBtn.Name = "getChairBtn";
            this.getChairBtn.Size = new System.Drawing.Size(145, 44);
            this.getChairBtn.TabIndex = 102;
            this.getChairBtn.Text = "Получить";
            this.getChairBtn.UseVisualStyleBackColor = false;
            this.getChairBtn.Click += new System.EventHandler(this.getChairBtn_Click);
            // 
            // ReturnItemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1467, 703);
            this.Controls.Add(this.getWardrobeBtn);
            this.Controls.Add(this.getShelfBtn);
            this.Controls.Add(this.getTableBtn);
            this.Controls.Add(this.getChairBtn);
            this.Controls.Add(this.changeWardrobeBtn);
            this.Controls.Add(this.changeShelfBtn);
            this.Controls.Add(this.changeTableBtn);
            this.Controls.Add(this.changeChairBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.WardrobeSNlabel);
            this.Controls.Add(this.ShelfSNlabel);
            this.Controls.Add(this.TableSNLabel);
            this.Controls.Add(this.ChairSNlabel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelPassword);
            this.Controls.Add(this.WardrobePassBtn);
            this.Controls.Add(this.ShelfPassBtn);
            this.Controls.Add(this.TablePassBtn);
            this.Controls.Add(this.ChairPassBtn);
            this.Controls.Add(this.ChairTmpLabel);
            this.Controls.Add(this.TableTmpLabel);
            this.Controls.Add(this.ShelfTmpLabel);
            this.Controls.Add(this.WardrobeTmpLabel);
            this.Controls.Add(this.WardrobeLabel);
            this.Controls.Add(this.ShelfLabel);
            this.Controls.Add(this.ChairLabel);
            this.Controls.Add(this.TableLabel);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ReturnItemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ReturnItemForm";
            this.Load += new System.EventHandler(this.ReturnItemForm_Load);
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label TableLabel;
        private System.Windows.Forms.Label ChairLabel;
        private System.Windows.Forms.Label ShelfLabel;
        private System.Windows.Forms.Label WardrobeLabel;
        private System.Windows.Forms.Label WardrobeTmpLabel;
        private System.Windows.Forms.Label ShelfTmpLabel;
        private System.Windows.Forms.Label TableTmpLabel;
        private System.Windows.Forms.Label ChairTmpLabel;
        private System.Windows.Forms.Button ChairPassBtn;
        private System.Windows.Forms.Button TablePassBtn;
        private System.Windows.Forms.Button ShelfPassBtn;
        private System.Windows.Forms.Button WardrobePassBtn;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label ChairSNlabel;
        private System.Windows.Forms.Label TableSNLabel;
        private System.Windows.Forms.Label WardrobeSNlabel;
        private System.Windows.Forms.Label ShelfSNlabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button changeWardrobeBtn;
        private System.Windows.Forms.Button changeShelfBtn;
        private System.Windows.Forms.Button changeTableBtn;
        private System.Windows.Forms.Button changeChairBtn;
        private System.Windows.Forms.Button getWardrobeBtn;
        private System.Windows.Forms.Button getShelfBtn;
        private System.Windows.Forms.Button getTableBtn;
        private System.Windows.Forms.Button getChairBtn;
    }
}