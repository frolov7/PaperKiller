﻿using AccessToDB;
using DataStructures;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace registration
{
    public partial class ReturnItemForm : Form
    {
        Student currentStudent;

        Linen currentLinen = null;
        Items currentItems = null;

        Chair currentChair = null;
        Table currentTable = null;
        Shelf currentShelf = null;
        Wardrobe currentWardrobe = null;

        Connector connectDB = new Connector();
        public ReturnItemForm(Student currentStudent)
        {
            InitializeComponent();
            this.currentStudent = currentStudent;
            currentLinen = GetInfo.GetLinenByID(connectDB, currentStudent.userID);
            currentItems = GetInfo.GetItemsByID(connectDB, currentStudent.userID);

            currentChair = GetInfo.GetChairByID(connectDB, currentStudent.userID);
            currentTable = GetInfo.GetTableByID(connectDB, currentStudent.userID);
            currentShelf = GetInfo.GetShelfByID(connectDB, currentStudent.userID);
            currentWardrobe = GetInfo.GetWardrobeByID(connectDB, currentStudent.userID);
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            UserMainMenuForm userForm = new UserMainMenuForm(currentStudent);
            userForm.ShowDialog(); // открыть окно
        }

        private void ReturnItemForm_Load(object sender, EventArgs e)
        {
            if (currentItems.chairID != 0)
            {
                ChairTmpLabel.Text = "В наличии";
                ChairSNlabel.Text = currentChair.serialNumber.ToString();
            }
            else
            {
                ChairTmpLabel.Text = "Пусто";
                ChairSNlabel.Text = "Пусто";
            }

            if (currentItems.tableID != 0)
            {
                TableTmpLabel.Text = "В наличии";
                TableSNLabel.Text = currentTable.serialNumber.ToString();
            }
            else
            {
                TableTmpLabel.Text = "Пусто";
                TableSNLabel.Text = "Пусто";
            }

            if (currentItems.shelfID != 0)
            {
                ShelfTmpLabel.Text = "В наличии";
                ShelfSNlabel.Text = currentShelf.serialNumber.ToString();
            }
            else
            {
                ShelfTmpLabel.Text = "Пусто";
                ShelfSNlabel.Text = "Пусто";
            }

            if (currentItems.wardrobeID != 0)
            {
                WardrobeTmpLabel.Text = "В наличии";
                WardrobeSNlabel.Text = currentWardrobe.serialNumber.ToString();
            }
            else
            {
                WardrobeTmpLabel.Text = "Пусто";
                WardrobeSNlabel.Text = "Пусто";
            }
        }

        private void ChairPassBtn_Click(object sender, EventArgs e)
        {
            if (ChairSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "chair_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "chair", "На складе", currentItems.chairID.ToString());
            ChairTmpLabel.Text = "Пусто";
            ChairSNlabel.Text = "Пусто";
        }

        private void TablePassBtn_Click(object sender, EventArgs e)
        {
            if (TableSNLabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "tables_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "tables", "На складе", currentItems.tableID.ToString());
            TableTmpLabel.Text = "Пусто";
            TableSNLabel.Text = "Пусто";
        }

        private void ShelfPassBtn_Click(object sender, EventArgs e)
        {
            if (ShelfSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "shelf_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "shelf", "На складе", currentItems.shelfID.ToString());
            ShelfTmpLabel.Text = "Пусто";
            ShelfSNlabel.Text = "Пусто";
        }

        private void WardrobePassBtn_Click(object sender, EventArgs e)
        {
            if (WardrobeSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnItemBack(connectDB, "wardrobe_id", currentItems.itemID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "wardrobe", "На складе", currentItems.wardrobeID.ToString());
            WardrobeTmpLabel.Text = "Пусто";
            WardrobeSNlabel.Text = "Пусто";
        }

        private void changeChairBtn_Click(object sender, EventArgs e)
        {
            if (ChairSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии стула", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateInfo.ChangeItemStatus(connectDB, "chair", "На складе", currentChair.chairID);
            int chairID = GetInfo.GetFreeItem(connectDB, "id", "chair");
            UpdateInfo.NewSerialNumber(connectDB, "chair_id", chairID.ToString(), currentItems.itemID);

            currentChair = GetInfo.GetChairByID(connectDB, currentItems.itemID);
            ChairSNlabel.Text = currentChair.serialNumber.ToString();
        }

        private void changeTableBtn_Click(object sender, EventArgs e)
        {
            if (TableSNLabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии стола", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateInfo.ChangeItemStatus(connectDB, "tables", "На складе", currentTable.tableID);
            int tableID = GetInfo.GetFreeItem(connectDB, "id", "tables");
            UpdateInfo.NewSerialNumber(connectDB, "tables_id", tableID.ToString(), currentItems.itemID);

            currentTable = GetInfo.GetTableByID(connectDB, currentItems.itemID);
            TableSNLabel.Text = currentTable.serialNumber.ToString();
        }

        private void changeShelfBtn_Click(object sender, EventArgs e)
        {
            if (ShelfSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии полки", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateInfo.ChangeItemStatus(connectDB, "shelf", "На складе", currentShelf.shelfID);
            int shelfID = GetInfo.GetFreeItem(connectDB, "id", "shelf");
            UpdateInfo.NewSerialNumber(connectDB, "shelf_id", shelfID.ToString(), currentItems.itemID);

            currentShelf = GetInfo.GetShelfByID(connectDB, currentItems.itemID);
            ShelfSNlabel.Text = currentShelf.serialNumber.ToString();
        }

        private void changeWardrobeBtn_Click(object sender, EventArgs e)
        {
            if (WardrobeSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии шкафа", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateInfo.ChangeItemStatus(connectDB, "wardrobe", "На складе", currentWardrobe.wardrobeID);
            int wardrobeID = GetInfo.GetFreeItem(connectDB, "id", "wardrobe");
            UpdateInfo.NewSerialNumber(connectDB, "wardrobe_id", wardrobeID.ToString(), currentItems.itemID);

            currentWardrobe = GetInfo.GetWardrobeByID(connectDB, currentItems.itemID);
            WardrobeSNlabel.Text = currentWardrobe.serialNumber.ToString();
        }

        private void getChairBtn_Click(object sender, EventArgs e)
        {
            if (ChairSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас уже есть стул", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int chairID = GetInfo.GetFreeItem(connectDB, "id", "chair");
            UpdateInfo.NewSerialNumber(connectDB, "chair_id", chairID.ToString(), currentItems.itemID);

            currentChair = GetInfo.GetChairByID(connectDB, currentItems.itemID);
            UpdateInfo.ChangeItemStatus(connectDB, "chair", "У студента", currentChair.chairID);

            ChairSNlabel.Text = currentChair.serialNumber.ToString();
            ChairTmpLabel.Text = "В наличии";
        }

        private void getTableBtn_Click(object sender, EventArgs e)
        {
            if (TableSNLabel.Text != "Пусто")
            {
                MessageBox.Show("У вас уже есть стол", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int tableID = GetInfo.GetFreeItem(connectDB, "id", "tables");
            UpdateInfo.NewSerialNumber(connectDB, "tables_id", tableID.ToString(), currentItems.itemID);

            currentTable = GetInfo.GetTableByID(connectDB, currentItems.itemID);
            UpdateInfo.ChangeItemStatus(connectDB, "tables", "У студента", currentTable.tableID);

            TableSNLabel.Text = currentTable.serialNumber.ToString();
            TableTmpLabel.Text = "В наличии";
        }

        private void getShelfBtn_Click(object sender, EventArgs e)
        {
            if (ShelfSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас уже есть полка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int shelfID = GetInfo.GetFreeItem(connectDB, "id", "shelf");
            UpdateInfo.NewSerialNumber(connectDB, "shelf_id", shelfID.ToString(), currentItems.itemID);

            currentShelf = GetInfo.GetShelfByID(connectDB, currentItems.itemID);
            UpdateInfo.ChangeItemStatus(connectDB, "shelf", "У студента", currentShelf.shelfID);

            ShelfSNlabel.Text = currentShelf.serialNumber.ToString();
            ShelfTmpLabel.Text = "В наличии";
        }

        private void getWardrobeBtn_Click(object sender, EventArgs e)
        {
            if (WardrobeSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас уже есть шкаф", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int wardrobeID = GetInfo.GetFreeItem(connectDB, "id", "wardrobe");
            UpdateInfo.NewSerialNumber(connectDB, "wardrobe_id", wardrobeID.ToString(), currentItems.itemID);

            currentWardrobe = GetInfo.GetWardrobeByID(connectDB, currentItems.itemID);
            UpdateInfo.ChangeItemStatus(connectDB, "wardrobe", "У студента", currentWardrobe.wardrobeID);

            WardrobeSNlabel.Text = currentWardrobe.serialNumber.ToString();
            WardrobeTmpLabel.Text = "В наличии";
        }
    }
}

//MessageBox.Show(sda.ToString(), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);