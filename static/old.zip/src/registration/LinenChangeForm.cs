﻿using AccessToDB;
using DataStructures;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace registration
{
    public partial class LinenChangeForm : Form
    {
        Student currentStudent;
        Linen currentLinen;

        Bedsheet currentBedsheet = null;
        Pillowcase currentPillowcase = null;
        Duvet currentDuvet = null;
        Bedspread currentBedspread = null;
        Towel currentTowel = null;

// private Boolean bedsheetChange = false;
        Connector connectDB = new Connector();

        public LinenChangeForm(Student currentStudent)
        {
            InitializeComponent();
            this.currentStudent = currentStudent;
            currentLinen = GetInfo.GetLinenByID(connectDB, currentStudent.userID);

            currentBedsheet = GetInfo.GetBedsheetByID(connectDB, currentLinen.linenID);
            currentPillowcase = GetInfo.GetPillowcaseByID(connectDB, currentLinen.linenID);
            currentDuvet = GetInfo.GetDuvetByID(connectDB, currentLinen.linenID);
            currentBedspread = GetInfo.GetBedspreadByID(connectDB, currentLinen.linenID);
            currentTowel = GetInfo.GetTowelByID(connectDB, currentLinen.linenID);
    }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            UserMainMenuForm userForm = new UserMainMenuForm(currentStudent);
            userForm.ShowDialog(); // открыть окно
        }

        private void LinenChangeForm_Load(object sender, EventArgs e)
        {
            if (currentLinen.bedsheetID != 0)
            {
                bedsheetTmpLabel.Text = "В наличии";
                bedsheetSNlabel.Text = currentBedsheet.serialNumber.ToString();
            }
            else
            {
                bedsheetTmpLabel.Text = "Пусто";
                bedsheetSNlabel.Text = "Пусто";
            }

            if (currentLinen.pillowcaseID != 0)
            {
                pillowcaseTmpLabel.Text = "В наличии";
                pillowcaseSNLabel.Text = currentPillowcase.serialNumber.ToString();
            }
            else
            {
                pillowcaseTmpLabel.Text = "Пусто";
                pillowcaseSNLabel.Text = "Пусто";
            }

            if (currentLinen.duvetID != 0)
            {
                duvetTmpLabel.Text = "В наличии";
                duvetSNlabel.Text = currentDuvet.serialNumber.ToString();
            }
            else
            {
                duvetTmpLabel.Text = "Пусто";
                duvetSNlabel.Text = "Пусто";
            }

            if (currentLinen.bedspreadID != 0)
            {
                bedspreadTmpLabel.Text = "В наличии";
                bedspreadSNlabel.Text = currentBedspread.serialNumber.ToString();
            }
            else
            {
                bedspreadTmpLabel.Text = "Пусто";
                bedspreadSNlabel.Text = "Пусто";
            }

            if (currentLinen.towelID != 0)
            {
                towelTmpLabel.Text = "В наличии";
                towelSNlabel.Text = currentTowel.serialNumber.ToString();
            }
            else
            {
                towelTmpLabel.Text = "Пусто";
                towelSNlabel.Text = "Пусто";
            }
        }

        private void BedsheetPassBtn_Click(object sender, EventArgs e)
        {
            if (bedsheetSNlabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "bedsheet_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "bedsheet", "На складе", currentBedsheet.bedsheetID);
            bedsheetTmpLabel.Text = "Пусто";
            bedsheetSNlabel.Text = "Пусто";
        }

        private void PillowcasePassBtn_Click(object sender, EventArgs e)
        {
            if (pillowcaseSNLabel.Text == "Пусто")
                return;

            UpdateInfo.ReturnLinenBack(connectDB, "pillowcase_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "pillowcase", "На складе", currentPillowcase.pillowcaseID);
            pillowcaseTmpLabel.Text = "Пусто";
            pillowcaseSNLabel.Text = "Пусто";
        }

        private void DuvetPassBtn_Click(object sender, EventArgs e)
        {
            if (duvetSNlabel.Text == "Пусто")
                return;
            
            UpdateInfo.ReturnLinenBack(connectDB, "duvet_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "duvet", "На складе", currentDuvet.duvetID);
            duvetTmpLabel.Text = "Пусто";
            duvetSNlabel.Text = "Пусто";
        }

        private void BedspreadPassBtn_Click(object sender, EventArgs e)
        {
            if (bedspreadSNlabel.Text == "Пусто")
                return;
            
            UpdateInfo.ReturnLinenBack(connectDB, "bedspread_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "bedspread", "На складе", currentBedspread.bedspreadID);
            bedspreadTmpLabel.Text = "Пусто";
            bedspreadSNlabel.Text = "Пусто";
        }

        private void TowelPassBtn_Click(object sender, EventArgs e)
        {
            if (towelSNlabel.Text == "Пусто")
                return;
            
            UpdateInfo.ReturnLinenBack(connectDB, "towel_id", currentLinen.linenID.ToString());
            UpdateInfo.ChangeItemStatus(connectDB, "towel", "На складе", currentTowel.towelID);
            towelTmpLabel.Text = "Пусто";
            towelSNlabel.Text = "Пусто";
        }

        private void changeBedsheetBtn_Click(object sender, EventArgs e)
        {
            if (bedsheetSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии простыни", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (currentBedsheet.bedsheetChange == true)
            {
                MessageBox.Show("Обменять предмет можно один раз за сессию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                UpdateInfo.ChangeItemStatus(connectDB, "bedsheet", "На складе", currentBedsheet.bedsheetID); // отправка на склад
                int bedsheetID = GetInfo.GetFreeItem(connectDB, "id", "bedsheet"); 
                UpdateInfo.NewLinen(connectDB, "bedsheet_id", bedsheetID.ToString(), currentLinen.linenID); // получение нового предмета со склада

                currentBedsheet = GetInfo.GetBedsheetByID(connectDB, currentLinen.linenID);
                bedsheetSNlabel.Text = currentBedsheet.serialNumber.ToString();

                InsertInfo.InsertLinenReport(connectDB, currentStudent.name.ToString(), currentStudent.surname.ToString(), currentStudent.roomNumber.ToString(), "Простыня");
                currentBedsheet.bedsheetChange = true;
            }

        }

        private void changePillowcaseBtn_Click(object sender, EventArgs e)
        {
            if (pillowcaseSNLabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии наволочки", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (currentPillowcase.pillowcaseChange == true)
            {
                MessageBox.Show("Обменять предмет можно один раз за сессию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            { 
                UpdateInfo.ChangeItemStatus(connectDB, "pillowcase", "На складе", currentPillowcase.pillowcaseID);
                int pillowcaseID = GetInfo.GetFreeItem(connectDB, "id", "pillowcase");
                UpdateInfo.NewLinen(connectDB, "pillowcase_id", pillowcaseID.ToString(), currentLinen.linenID);

                currentPillowcase = GetInfo.GetPillowcaseByID(connectDB, currentLinen.linenID);
                pillowcaseSNLabel.Text = currentPillowcase.serialNumber.ToString();

                InsertInfo.InsertLinenReport(connectDB, currentStudent.name.ToString(), currentStudent.surname.ToString(), currentStudent.roomNumber.ToString(), "Наволочка");
                currentPillowcase.pillowcaseChange = true;
            }

        }

        private void changeDuvetBtn_Click(object sender, EventArgs e)
        {
            if (duvetSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии пододеяльника", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (currentDuvet.duvetChange == true)
            {
                MessageBox.Show("Обменять предмет можно один раз за сессию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                UpdateInfo.ChangeItemStatus(connectDB, "duvet", "На складе", currentDuvet.duvetID);
                int duvetID = GetInfo.GetFreeItem(connectDB, "id", "duvet");
                UpdateInfo.NewLinen(connectDB, "duvet_id", duvetID.ToString(), currentLinen.linenID);

                currentDuvet = GetInfo.GetDuvetByID(connectDB, currentLinen.linenID);
                duvetSNlabel.Text = currentDuvet.serialNumber.ToString();

                InsertInfo.InsertLinenReport(connectDB, currentStudent.name.ToString(), currentStudent.surname.ToString(), currentStudent.roomNumber.ToString(), "Пододеяльник");
                currentDuvet.duvetChange = true;
            }
        }

        private void changeBedspreadBtn_Click(object sender, EventArgs e)
        {
            if (bedspreadSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии покрывала", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (currentBedspread.bedspreadChange == true)
            {
                MessageBox.Show("Обменять предмет можно один раз за сессию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                UpdateInfo.ChangeItemStatus(connectDB, "bedspread", "На складе", currentBedspread.bedspreadID);
                int bedspreadID = GetInfo.GetFreeItem(connectDB, "id", "bedspread");
                UpdateInfo.NewLinen(connectDB, "bedspread_id", bedspreadID.ToString(), currentLinen.linenID);

                currentBedspread = GetInfo.GetBedspreadByID(connectDB, currentLinen.linenID);
                bedspreadSNlabel.Text = currentBedspread.serialNumber.ToString();

                InsertInfo.InsertLinenReport(connectDB, currentStudent.name.ToString(), currentStudent.surname.ToString(), currentStudent.roomNumber.ToString(), "Покрывало");
                currentBedspread.bedspreadChange = true;
            }
        }

        private void changeTowelBtn_Click(object sender, EventArgs e)
        {
            if (towelSNlabel.Text == "Пусто")
            {
                MessageBox.Show("У вас нет в наличии полотенца", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (currentTowel.towelChange == true)
            {
                MessageBox.Show("Обменять предмет можно один раз за сессию", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                UpdateInfo.ChangeItemStatus(connectDB, "towel", "На складе", currentTowel.towelID);
                int towelID = GetInfo.GetFreeItem(connectDB, "id", "towel");
                UpdateInfo.NewLinen(connectDB, "towel_id", towelID.ToString(), currentLinen.linenID);

                currentTowel = GetInfo.GetTowelByID(connectDB, currentLinen.linenID);
                towelSNlabel.Text = currentTowel.serialNumber.ToString();

                InsertInfo.InsertLinenReport(connectDB, currentStudent.name.ToString(), currentStudent.surname.ToString(), currentStudent.roomNumber.ToString(), "Полотенце");
                currentTowel.towelChange = true;
            }
        }

        private void getBedsheetBtn_Click(object sender, EventArgs e)
        {
            if (bedsheetSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас нет в наличии простыни", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int bedsheetID = GetInfo.GetFreeItem(connectDB, "id", "bedsheet");
            UpdateInfo.NewLinen(connectDB, "bedsheet_id", bedsheetID.ToString(), currentLinen.linenID);

            currentBedsheet = GetInfo.GetBedsheetByID(connectDB, currentLinen.linenID);
            UpdateInfo.ChangeItemStatus(connectDB, "bedsheet", "У студента", currentBedsheet.bedsheetID);

            bedsheetSNlabel.Text = currentBedsheet.serialNumber.ToString();
            bedsheetTmpLabel.Text = "В наличии";
        }

        private void getPillowcaseBtn_Click(object sender, EventArgs e)
        {
            if (pillowcaseSNLabel.Text != "Пусто")
            {
                MessageBox.Show("У вас нет в наличии наволочки", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int pillowcaseID = GetInfo.GetFreeItem(connectDB, "id", "pillowcase");
            UpdateInfo.NewLinen(connectDB, "pillowcase_id", pillowcaseID.ToString(), currentLinen.linenID);

            currentPillowcase = GetInfo.GetPillowcaseByID(connectDB, currentLinen.linenID);
            UpdateInfo.ChangeItemStatus(connectDB, "pillowcase", "У студента", currentPillowcase.pillowcaseID);

            pillowcaseSNLabel.Text = currentPillowcase.serialNumber.ToString();
            pillowcaseTmpLabel.Text = "В наличии";
        }

        private void getDuvetBtn_Click(object sender, EventArgs e)
        {
            if (duvetSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас нет в наличии пододеяльника", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int duvetID = GetInfo.GetFreeItem(connectDB, "id", "duvet");
            UpdateInfo.NewLinen(connectDB, "duvet_id", duvetID.ToString(), currentLinen.linenID);

            currentDuvet = GetInfo.GetDuvetByID(connectDB, currentLinen.linenID);
            UpdateInfo.ChangeItemStatus(connectDB, "duvet", "У студента", currentDuvet.duvetID);

            duvetSNlabel.Text = currentDuvet.serialNumber.ToString();
            duvetTmpLabel.Text = "В наличии";
        }

        private void getBedspreadBtn_Click(object sender, EventArgs e)
        {
            if (bedspreadSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас нет в наличии покрывала", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int bedspreadID = GetInfo.GetFreeItem(connectDB, "id", "bedspread");
            UpdateInfo.NewLinen(connectDB, "bedspread_id", bedspreadID.ToString(), currentLinen.linenID);

            currentBedspread = GetInfo.GetBedspreadByID(connectDB, currentLinen.linenID);
            UpdateInfo.ChangeItemStatus(connectDB, "bedspread", "У студента", currentBedspread.bedspreadID);

            bedspreadSNlabel.Text = currentBedspread.serialNumber.ToString();
            bedspreadTmpLabel.Text = "В наличии";
        }

        private void getTowelBtn_Click(object sender, EventArgs e)
        {
            if (towelSNlabel.Text != "Пусто")
            {
                MessageBox.Show("У вас нет в наличии полотенца", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int towelID = GetInfo.GetFreeItem(connectDB, "id", "towel");
            UpdateInfo.NewLinen(connectDB, "towel_id", towelID.ToString(), currentLinen.linenID);

            currentTowel = GetInfo.GetTowelByID(connectDB, currentLinen.linenID);
            UpdateInfo.ChangeItemStatus(connectDB, "towel", "У студента", currentTowel.towelID);

            towelSNlabel.Text = currentBedspread.serialNumber.ToString();
            towelTmpLabel.Text = "В наличии";
        }
    }
}
//MessageBox.Show(currentLinen.status.ToString(), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
