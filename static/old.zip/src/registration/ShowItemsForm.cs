﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccessToDB;
using DataStructures;


using System.Data.SqlClient;
using registration.masterDataSetTableAdapters;

namespace registration
{
    public partial class ShowItemsForm : Form
    {
        Connector connectDB = new Connector();
        Student currentStudent;
        public ShowItemsForm(Student currentStudent)
        {
            InitializeComponent();
            this.currentStudent = currentStudent;
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
        }

        private void closeLabel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowChairBtn_Click(object sender, EventArgs e)
        {
            linenBox.Text = "Постель";

            ShowChairBtn.BackColor = Color.FloralWhite;

            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);
            linenBox.BackColor = Color.FromArgb(34, 36, 49);

            dataGridChair.Visible = true;
            this.chairTableAdapter.Fill(this.masterDataSetChair.chair);
            dataGridChair.BringToFront();
        }

        private void ShowTablesBtn_Click(object sender, EventArgs e)
        {
            linenBox.Text = "Постель";

            ShowTablesBtn.BackColor = Color.FloralWhite;

            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);
            linenBox.BackColor = Color.FromArgb(34, 36, 49);

            dataGridTables.Visible = true;
            this.tablesTableAdapter1.Fill(this.masterDataSetTables.tables);
            dataGridTables.BringToFront();
        }

        private void ShowWardrobeBtn_Click(object sender, EventArgs e)
        {
            linenBox.Text = "Постель";

            ShowWardrobeBtn.BackColor = Color.FloralWhite;

            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);
            linenBox.BackColor = Color.FromArgb(34, 36, 49);

            dataGridWardrobe.Visible = true;
            this.wardrobeTableAdapter.Fill(this.masterDataSetWardrobe.wardrobe);
            dataGridWardrobe.BringToFront();
        }

        private void ShowShelfBtn_Click(object sender, EventArgs e)
        {
            linenBox.Text = "Постель";

            ShowShelfBtn.BackColor = Color.FloralWhite;

            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);
            linenBox.BackColor = Color.FromArgb(34, 36, 49);

            dataGridShelf.Visible = true;
            this.shelfTableAdapter.Fill(this.masterDataSetShelf.shelf);
            dataGridShelf.BringToFront();
        }

        private void ShowItemsForm_Load(object sender, EventArgs e)
        {
            dataGridShelf.Visible = false;
            dataGridWardrobe.Visible = false;
            dataGridLinen.Visible = false;
            dataGridTables.Visible = false;
            dataGridChair.Visible = false;
            dataGridBedsheet.Visible = false;
            dataGridPillowcase.Visible = false;
            dataGridDuvet.Visible = false;
            dataGridBedspread.Visible = false;
            dataGridTowel.Visible = false;
        }

        private void linenBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            linenBox.BackColor = Color.FloralWhite;

            ShowShelfBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowChairBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowTablesBtn.BackColor = Color.FromArgb(34, 36, 49);
            ShowWardrobeBtn.BackColor = Color.FromArgb(34, 36, 49);

            if (linenBox.SelectedItem.ToString() == "Простыня")
            {
                dataGridBedsheet.Visible = true;
                this.bedsheetTableAdapter.Fill(this.masterDataSetBedsheet.bedsheet);
                dataGridBedsheet.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Наволочка")
            {
                dataGridPillowcase.Visible = true;
                this.pillowcaseTableAdapter1.Fill(this.masterDataSetPillowcase1.pillowcase);
                dataGridPillowcase.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Пододеяльник")
            {
                dataGridDuvet.Visible = true;
                this.duvetTableAdapter.Fill(this.masterDataSetDuvet.duvet);
                dataGridDuvet.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Покрывало")
            {
                dataGridBedspread.Visible = true;
                this.bedspreadTableAdapter.Fill(this.masterDataSetBedspread.bedspread);
                dataGridBedspread.BringToFront();
            }
            if (linenBox.SelectedItem.ToString() == "Полотенце")
            {
                dataGridTowel.Visible = true;
                this.towelTableAdapter.Fill(this.masterDataSetTowel.towel);
                dataGridTowel.BringToFront();
            }
        }
    }
}
