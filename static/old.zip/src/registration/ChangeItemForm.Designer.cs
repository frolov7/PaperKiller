﻿namespace registration
{
    partial class ChangeItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label2 = new System.Windows.Forms.Label();
            this.pillowcaseTmpLabel = new System.Windows.Forms.Label();
            this.duvetTmpLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.duvetSNlabel = new System.Windows.Forms.Label();
            this.towelSNlabel = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.bedsheetTmpLabel = new System.Windows.Forms.Label();
            this.bedspreadTmpLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pillowcaseSNLabel = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chairLabel = new System.Windows.Forms.Label();
            this.checkStudentImg = new System.Windows.Forms.PictureBox();
            this.TowelGiveBtn = new System.Windows.Forms.Button();
            this.PillowcaseGiveBtn = new System.Windows.Forms.Button();
            this.BedsheetGiveBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.surnameImg = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.wardrobeLabel = new System.Windows.Forms.Label();
            this.WardrobeSNlabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.TableSNLabel = new System.Windows.Forms.Label();
            this.tableLabel = new System.Windows.Forms.Label();
            this.ChairSNlabel = new System.Windows.Forms.Label();
            this.TableTmpLabel = new System.Windows.Forms.Label();
            this.WardrobeTmpLabel = new System.Windows.Forms.Label();
            this.ShelfTmpLabel = new System.Windows.Forms.Label();
            this.ChairTmpLabel = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BedspreadGiveBtn = new System.Windows.Forms.Button();
            this.DuvetGiveBtn = new System.Windows.Forms.Button();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.towelTmpLabel = new System.Windows.Forms.Label();
            this.bedsheetSNlabel = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.nameField = new System.Windows.Forms.TextBox();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.ItemBox = new System.Windows.Forms.Panel();
            this.shelfLabel = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ShelfSNlabel = new System.Windows.Forms.Label();
            this.LinenBox = new System.Windows.Forms.Panel();
            this.Label1 = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.bedspreadSNlabel = new System.Windows.Forms.Label();
            this.ShowLinenBtn = new System.Windows.Forms.Button();
            this.ShowItemBtn = new System.Windows.Forms.Button();
            this.searchBtn = new System.Windows.Forms.Button();
            this.panelRoom = new System.Windows.Forms.Panel();
            this.panelSurname = new System.Windows.Forms.Panel();
            this.roomField = new System.Windows.Forms.TextBox();
            this.surnameField = new System.Windows.Forms.TextBox();
            this.panelName = new System.Windows.Forms.Panel();
            this.nameImg = new System.Windows.Forms.PictureBox();
            this.WardrobeGiveBtn = new System.Windows.Forms.Button();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.logoLabel = new System.Windows.Forms.Label();
            this.ShelfGiveBtn = new System.Windows.Forms.Button();
            this.TableGiveBtn = new System.Windows.Forms.Button();
            this.ChairGiveBtn = new System.Windows.Forms.Button();
            this.resultLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.checkStudentImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.surnameImg)).BeginInit();
            this.ItemBox.SuspendLayout();
            this.LinenBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nameImg)).BeginInit();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label2.Location = new System.Drawing.Point(16, 98);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(147, 36);
            this.Label2.TabIndex = 152;
            this.Label2.Text = "Наволочка";
            // 
            // pillowcaseTmpLabel
            // 
            this.pillowcaseTmpLabel.AutoSize = true;
            this.pillowcaseTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pillowcaseTmpLabel.Location = new System.Drawing.Point(485, 98);
            this.pillowcaseTmpLabel.Name = "pillowcaseTmpLabel";
            this.pillowcaseTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.pillowcaseTmpLabel.TabIndex = 160;
            this.pillowcaseTmpLabel.Text = "status";
            // 
            // duvetTmpLabel
            // 
            this.duvetTmpLabel.AutoSize = true;
            this.duvetTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duvetTmpLabel.Location = new System.Drawing.Point(485, 154);
            this.duvetTmpLabel.Name = "duvetTmpLabel";
            this.duvetTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.duvetTmpLabel.TabIndex = 159;
            this.duvetTmpLabel.Text = "status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(466, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 26);
            this.label7.TabIndex = 178;
            this.label7.Text = "Статус предмета";
            // 
            // duvetSNlabel
            // 
            this.duvetSNlabel.AutoSize = true;
            this.duvetSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duvetSNlabel.Location = new System.Drawing.Point(236, 154);
            this.duvetSNlabel.Name = "duvetSNlabel";
            this.duvetSNlabel.Size = new System.Drawing.Size(176, 36);
            this.duvetSNlabel.TabIndex = 173;
            this.duvetSNlabel.Text = "serialNumber";
            // 
            // towelSNlabel
            // 
            this.towelSNlabel.AutoSize = true;
            this.towelSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.towelSNlabel.Location = new System.Drawing.Point(236, 264);
            this.towelSNlabel.Name = "towelSNlabel";
            this.towelSNlabel.Size = new System.Drawing.Size(176, 36);
            this.towelSNlabel.TabIndex = 175;
            this.towelSNlabel.Text = "serialNumber";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label3.Location = new System.Drawing.Point(16, 154);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(197, 36);
            this.Label3.TabIndex = 154;
            this.Label3.Text = "Пододеяльник";
            // 
            // bedsheetTmpLabel
            // 
            this.bedsheetTmpLabel.AutoSize = true;
            this.bedsheetTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedsheetTmpLabel.Location = new System.Drawing.Point(485, 44);
            this.bedsheetTmpLabel.Name = "bedsheetTmpLabel";
            this.bedsheetTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.bedsheetTmpLabel.TabIndex = 161;
            this.bedsheetTmpLabel.Text = "status";
            // 
            // bedspreadTmpLabel
            // 
            this.bedspreadTmpLabel.AutoSize = true;
            this.bedspreadTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedspreadTmpLabel.Location = new System.Drawing.Point(485, 209);
            this.bedspreadTmpLabel.Name = "bedspreadTmpLabel";
            this.bedspreadTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.bedspreadTmpLabel.TabIndex = 158;
            this.bedspreadTmpLabel.Text = "status";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(236, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 26);
            this.label6.TabIndex = 177;
            this.label6.Text = "Серийный номер";
            // 
            // pillowcaseSNLabel
            // 
            this.pillowcaseSNLabel.AutoSize = true;
            this.pillowcaseSNLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseSNLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pillowcaseSNLabel.Location = new System.Drawing.Point(236, 98);
            this.pillowcaseSNLabel.Name = "pillowcaseSNLabel";
            this.pillowcaseSNLabel.Size = new System.Drawing.Size(176, 36);
            this.pillowcaseSNLabel.TabIndex = 172;
            this.pillowcaseSNLabel.Text = "serialNumber";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label4.Location = new System.Drawing.Point(16, 209);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(155, 36);
            this.Label4.TabIndex = 155;
            this.Label4.Text = "Покрывало";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(426, 46);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 247);
            this.panel2.TabIndex = 169;
            // 
            // chairLabel
            // 
            this.chairLabel.AutoSize = true;
            this.chairLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chairLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chairLabel.Location = new System.Drawing.Point(23, 46);
            this.chairLabel.Name = "chairLabel";
            this.chairLabel.Size = new System.Drawing.Size(75, 36);
            this.chairLabel.TabIndex = 153;
            this.chairLabel.Text = "Стул";
            // 
            // checkStudentImg
            // 
            this.checkStudentImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.checkStudentImg.Location = new System.Drawing.Point(976, 220);
            this.checkStudentImg.Name = "checkStudentImg";
            this.checkStudentImg.Size = new System.Drawing.Size(18, 18);
            this.checkStudentImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.checkStudentImg.TabIndex = 221;
            this.checkStudentImg.TabStop = false;
            // 
            // TowelGiveBtn
            // 
            this.TowelGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TowelGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TowelGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TowelGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.TowelGiveBtn.Location = new System.Drawing.Point(963, 533);
            this.TowelGiveBtn.Name = "TowelGiveBtn";
            this.TowelGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.TowelGiveBtn.TabIndex = 220;
            this.TowelGiveBtn.Text = "Обменять";
            this.TowelGiveBtn.UseVisualStyleBackColor = false;
            this.TowelGiveBtn.Click += new System.EventHandler(this.TowelGiveBtn_Click);
            // 
            // PillowcaseGiveBtn
            // 
            this.PillowcaseGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PillowcaseGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PillowcaseGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PillowcaseGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.PillowcaseGiveBtn.Location = new System.Drawing.Point(963, 366);
            this.PillowcaseGiveBtn.Name = "PillowcaseGiveBtn";
            this.PillowcaseGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.PillowcaseGiveBtn.TabIndex = 217;
            this.PillowcaseGiveBtn.Text = "Обменять";
            this.PillowcaseGiveBtn.UseVisualStyleBackColor = false;
            this.PillowcaseGiveBtn.Click += new System.EventHandler(this.PillowcaseGiveBtn_Click);
            // 
            // BedsheetGiveBtn
            // 
            this.BedsheetGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BedsheetGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BedsheetGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BedsheetGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.BedsheetGiveBtn.Location = new System.Drawing.Point(963, 312);
            this.BedsheetGiveBtn.Name = "BedsheetGiveBtn";
            this.BedsheetGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.BedsheetGiveBtn.TabIndex = 216;
            this.BedsheetGiveBtn.Text = "Обменять";
            this.BedsheetGiveBtn.UseVisualStyleBackColor = false;
            this.BedsheetGiveBtn.Click += new System.EventHandler(this.BedsheetGiveBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::registration.Properties.Resources.user_icon_female;
            this.pictureBox1.Image = global::registration.Properties.Resources.numbers;
            this.pictureBox1.Location = new System.Drawing.Point(599, 206);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 206;
            this.pictureBox1.TabStop = false;
            // 
            // surnameImg
            // 
            this.surnameImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.surnameImg.Image = global::registration.Properties.Resources.user_icon2;
            this.surnameImg.Location = new System.Drawing.Point(317, 206);
            this.surnameImg.Name = "surnameImg";
            this.surnameImg.Size = new System.Drawing.Size(32, 32);
            this.surnameImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.surnameImg.TabIndex = 205;
            this.surnameImg.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(78, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 26);
            this.label9.TabIndex = 176;
            this.label9.Text = "Название";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(433, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 211);
            this.panel1.TabIndex = 169;
            // 
            // wardrobeLabel
            // 
            this.wardrobeLabel.AutoSize = true;
            this.wardrobeLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.wardrobeLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.wardrobeLabel.Location = new System.Drawing.Point(23, 210);
            this.wardrobeLabel.Name = "wardrobeLabel";
            this.wardrobeLabel.Size = new System.Drawing.Size(90, 36);
            this.wardrobeLabel.TabIndex = 155;
            this.wardrobeLabel.Text = "Шкаф";
            // 
            // WardrobeSNlabel
            // 
            this.WardrobeSNlabel.AutoSize = true;
            this.WardrobeSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeSNlabel.Location = new System.Drawing.Point(243, 210);
            this.WardrobeSNlabel.Name = "WardrobeSNlabel";
            this.WardrobeSNlabel.Size = new System.Drawing.Size(176, 36);
            this.WardrobeSNlabel.TabIndex = 174;
            this.WardrobeSNlabel.Text = "serialNumber";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(221, 51);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 211);
            this.panel5.TabIndex = 167;
            // 
            // TableSNLabel
            // 
            this.TableSNLabel.AutoSize = true;
            this.TableSNLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableSNLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableSNLabel.Location = new System.Drawing.Point(243, 100);
            this.TableSNLabel.Name = "TableSNLabel";
            this.TableSNLabel.Size = new System.Drawing.Size(176, 36);
            this.TableSNLabel.TabIndex = 172;
            this.TableSNLabel.Text = "serialNumber";
            // 
            // tableLabel
            // 
            this.tableLabel.AutoSize = true;
            this.tableLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tableLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLabel.Location = new System.Drawing.Point(23, 100);
            this.tableLabel.Name = "tableLabel";
            this.tableLabel.Size = new System.Drawing.Size(75, 36);
            this.tableLabel.TabIndex = 152;
            this.tableLabel.Text = "Стол";
            // 
            // ChairSNlabel
            // 
            this.ChairSNlabel.AutoSize = true;
            this.ChairSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairSNlabel.Location = new System.Drawing.Point(243, 46);
            this.ChairSNlabel.Name = "ChairSNlabel";
            this.ChairSNlabel.Size = new System.Drawing.Size(176, 36);
            this.ChairSNlabel.TabIndex = 171;
            this.ChairSNlabel.Text = "serialNumber";
            // 
            // TableTmpLabel
            // 
            this.TableTmpLabel.AutoSize = true;
            this.TableTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableTmpLabel.Location = new System.Drawing.Point(492, 100);
            this.TableTmpLabel.Name = "TableTmpLabel";
            this.TableTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.TableTmpLabel.TabIndex = 160;
            this.TableTmpLabel.Text = "status";
            // 
            // WardrobeTmpLabel
            // 
            this.WardrobeTmpLabel.AutoSize = true;
            this.WardrobeTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeTmpLabel.Location = new System.Drawing.Point(492, 210);
            this.WardrobeTmpLabel.Name = "WardrobeTmpLabel";
            this.WardrobeTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.WardrobeTmpLabel.TabIndex = 158;
            this.WardrobeTmpLabel.Text = "status";
            // 
            // ShelfTmpLabel
            // 
            this.ShelfTmpLabel.AutoSize = true;
            this.ShelfTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfTmpLabel.Location = new System.Drawing.Point(492, 155);
            this.ShelfTmpLabel.Name = "ShelfTmpLabel";
            this.ShelfTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.ShelfTmpLabel.TabIndex = 159;
            this.ShelfTmpLabel.Text = "status";
            // 
            // ChairTmpLabel
            // 
            this.ChairTmpLabel.AutoSize = true;
            this.ChairTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairTmpLabel.Location = new System.Drawing.Point(492, 46);
            this.ChairTmpLabel.Name = "ChairTmpLabel";
            this.ChairTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.ChairTmpLabel.TabIndex = 161;
            this.ChairTmpLabel.Text = "status";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(26, 41);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(638, 1);
            this.panel6.TabIndex = 170;
            // 
            // BedspreadGiveBtn
            // 
            this.BedspreadGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BedspreadGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BedspreadGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BedspreadGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.BedspreadGiveBtn.Location = new System.Drawing.Point(963, 478);
            this.BedspreadGiveBtn.Name = "BedspreadGiveBtn";
            this.BedspreadGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.BedspreadGiveBtn.TabIndex = 219;
            this.BedspreadGiveBtn.Text = "Обменять";
            this.BedspreadGiveBtn.UseVisualStyleBackColor = false;
            this.BedspreadGiveBtn.Click += new System.EventHandler(this.BedspreadGiveBtn_Click);
            // 
            // DuvetGiveBtn
            // 
            this.DuvetGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DuvetGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DuvetGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DuvetGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.DuvetGiveBtn.Location = new System.Drawing.Point(963, 423);
            this.DuvetGiveBtn.Name = "DuvetGiveBtn";
            this.DuvetGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.DuvetGiveBtn.TabIndex = 218;
            this.DuvetGiveBtn.Text = "Обменять";
            this.DuvetGiveBtn.UseVisualStyleBackColor = false;
            this.DuvetGiveBtn.Click += new System.EventHandler(this.DuvetGiveBtn_Click);
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(214, 50);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(1, 247);
            this.panelPassword.TabIndex = 167;
            // 
            // towelTmpLabel
            // 
            this.towelTmpLabel.AutoSize = true;
            this.towelTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.towelTmpLabel.Location = new System.Drawing.Point(485, 264);
            this.towelTmpLabel.Name = "towelTmpLabel";
            this.towelTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.towelTmpLabel.TabIndex = 157;
            this.towelTmpLabel.Text = "status";
            // 
            // bedsheetSNlabel
            // 
            this.bedsheetSNlabel.AutoSize = true;
            this.bedsheetSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedsheetSNlabel.Location = new System.Drawing.Point(236, 44);
            this.bedsheetSNlabel.Name = "bedsheetSNlabel";
            this.bedsheetSNlabel.Size = new System.Drawing.Size(176, 36);
            this.bedsheetSNlabel.TabIndex = 171;
            this.bedsheetSNlabel.Text = "serialNumber";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label5.Location = new System.Drawing.Point(16, 264);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(149, 36);
            this.Label5.TabIndex = 156;
            this.Label5.Text = "Полотенце";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(19, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(638, 1);
            this.panel3.TabIndex = 170;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(473, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(156, 26);
            this.label14.TabIndex = 178;
            this.label14.Text = "Статус предмета";
            // 
            // nameField
            // 
            this.nameField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nameField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nameField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.nameField.ForeColor = System.Drawing.Color.White;
            this.nameField.HideSelection = false;
            this.nameField.Location = new System.Drawing.Point(75, 216);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(200, 22);
            this.nameField.TabIndex = 203;
            this.nameField.TabStop = false;
            this.nameField.Text = "Женя";
            this.nameField.Click += new System.EventHandler(this.nameField_Click);
            this.nameField.Enter += new System.EventHandler(this.nameField_Enter);
            this.nameField.Leave += new System.EventHandler(this.nameField_Leave);
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(19, 19);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(647, 56);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Заменить студенту вещь";
            // 
            // ItemBox
            // 
            this.ItemBox.Controls.Add(this.chairLabel);
            this.ItemBox.Controls.Add(this.label9);
            this.ItemBox.Controls.Add(this.panel1);
            this.ItemBox.Controls.Add(this.wardrobeLabel);
            this.ItemBox.Controls.Add(this.WardrobeSNlabel);
            this.ItemBox.Controls.Add(this.panel5);
            this.ItemBox.Controls.Add(this.TableSNLabel);
            this.ItemBox.Controls.Add(this.tableLabel);
            this.ItemBox.Controls.Add(this.ChairSNlabel);
            this.ItemBox.Controls.Add(this.TableTmpLabel);
            this.ItemBox.Controls.Add(this.WardrobeTmpLabel);
            this.ItemBox.Controls.Add(this.ShelfTmpLabel);
            this.ItemBox.Controls.Add(this.ChairTmpLabel);
            this.ItemBox.Controls.Add(this.panel6);
            this.ItemBox.Controls.Add(this.label14);
            this.ItemBox.Controls.Add(this.shelfLabel);
            this.ItemBox.Controls.Add(this.label20);
            this.ItemBox.Controls.Add(this.ShelfSNlabel);
            this.ItemBox.Location = new System.Drawing.Point(307, 266);
            this.ItemBox.Margin = new System.Windows.Forms.Padding(2);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(629, 268);
            this.ItemBox.TabIndex = 215;
            // 
            // shelfLabel
            // 
            this.shelfLabel.AutoSize = true;
            this.shelfLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.shelfLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.shelfLabel.Location = new System.Drawing.Point(23, 155);
            this.shelfLabel.Name = "shelfLabel";
            this.shelfLabel.Size = new System.Drawing.Size(93, 36);
            this.shelfLabel.TabIndex = 154;
            this.shelfLabel.Text = "Полка";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(243, 9);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(164, 26);
            this.label20.TabIndex = 177;
            this.label20.Text = "Серийный номер";
            // 
            // ShelfSNlabel
            // 
            this.ShelfSNlabel.AutoSize = true;
            this.ShelfSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfSNlabel.Location = new System.Drawing.Point(243, 155);
            this.ShelfSNlabel.Name = "ShelfSNlabel";
            this.ShelfSNlabel.Size = new System.Drawing.Size(176, 36);
            this.ShelfSNlabel.TabIndex = 173;
            this.ShelfSNlabel.Text = "serialNumber";
            // 
            // LinenBox
            // 
            this.LinenBox.Controls.Add(this.Label1);
            this.LinenBox.Controls.Add(this.NameLabel);
            this.LinenBox.Controls.Add(this.bedspreadSNlabel);
            this.LinenBox.Controls.Add(this.Label2);
            this.LinenBox.Controls.Add(this.pillowcaseTmpLabel);
            this.LinenBox.Controls.Add(this.duvetTmpLabel);
            this.LinenBox.Controls.Add(this.label7);
            this.LinenBox.Controls.Add(this.duvetSNlabel);
            this.LinenBox.Controls.Add(this.towelSNlabel);
            this.LinenBox.Controls.Add(this.Label3);
            this.LinenBox.Controls.Add(this.bedsheetTmpLabel);
            this.LinenBox.Controls.Add(this.bedspreadTmpLabel);
            this.LinenBox.Controls.Add(this.label6);
            this.LinenBox.Controls.Add(this.pillowcaseSNLabel);
            this.LinenBox.Controls.Add(this.Label4);
            this.LinenBox.Controls.Add(this.panel2);
            this.LinenBox.Controls.Add(this.panelPassword);
            this.LinenBox.Controls.Add(this.towelTmpLabel);
            this.LinenBox.Controls.Add(this.bedsheetSNlabel);
            this.LinenBox.Controls.Add(this.Label5);
            this.LinenBox.Controls.Add(this.panel3);
            this.LinenBox.Location = new System.Drawing.Point(313, 267);
            this.LinenBox.Margin = new System.Windows.Forms.Padding(2);
            this.LinenBox.Name = "LinenBox";
            this.LinenBox.Size = new System.Drawing.Size(629, 308);
            this.LinenBox.TabIndex = 214;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label1.Location = new System.Drawing.Point(16, 44);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(141, 36);
            this.Label1.TabIndex = 153;
            this.Label1.Text = "Простыня";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NameLabel.Location = new System.Drawing.Point(71, 7);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(96, 26);
            this.NameLabel.TabIndex = 176;
            this.NameLabel.Text = "Название";
            // 
            // bedspreadSNlabel
            // 
            this.bedspreadSNlabel.AutoSize = true;
            this.bedspreadSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedspreadSNlabel.Location = new System.Drawing.Point(236, 209);
            this.bedspreadSNlabel.Name = "bedspreadSNlabel";
            this.bedspreadSNlabel.Size = new System.Drawing.Size(176, 36);
            this.bedspreadSNlabel.TabIndex = 174;
            this.bedspreadSNlabel.Text = "serialNumber";
            // 
            // ShowLinenBtn
            // 
            this.ShowLinenBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowLinenBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowLinenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowLinenBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowLinenBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowLinenBtn.Location = new System.Drawing.Point(27, 415);
            this.ShowLinenBtn.Name = "ShowLinenBtn";
            this.ShowLinenBtn.Size = new System.Drawing.Size(250, 54);
            this.ShowLinenBtn.TabIndex = 213;
            this.ShowLinenBtn.Text = "Постель";
            this.ShowLinenBtn.UseVisualStyleBackColor = false;
            this.ShowLinenBtn.Click += new System.EventHandler(this.ShowLinenBtn_Click);
            // 
            // ShowItemBtn
            // 
            this.ShowItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowItemBtn.Location = new System.Drawing.Point(27, 319);
            this.ShowItemBtn.Name = "ShowItemBtn";
            this.ShowItemBtn.Size = new System.Drawing.Size(250, 54);
            this.ShowItemBtn.TabIndex = 212;
            this.ShowItemBtn.Text = "Вещи";
            this.ShowItemBtn.UseVisualStyleBackColor = false;
            this.ShowItemBtn.Click += new System.EventHandler(this.ShowItemBtn_Click);
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.searchBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.searchBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.searchBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.searchBtn.Location = new System.Drawing.Point(861, 209);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(109, 36);
            this.searchBtn.TabIndex = 211;
            this.searchBtn.Text = "Поиск";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // panelRoom
            // 
            this.panelRoom.BackColor = System.Drawing.Color.White;
            this.panelRoom.Location = new System.Drawing.Point(589, 244);
            this.panelRoom.Name = "panelRoom";
            this.panelRoom.Size = new System.Drawing.Size(250, 1);
            this.panelRoom.TabIndex = 209;
            // 
            // panelSurname
            // 
            this.panelSurname.BackColor = System.Drawing.Color.White;
            this.panelSurname.Location = new System.Drawing.Point(307, 244);
            this.panelSurname.Name = "panelSurname";
            this.panelSurname.Size = new System.Drawing.Size(250, 1);
            this.panelSurname.TabIndex = 210;
            // 
            // roomField
            // 
            this.roomField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.roomField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.roomField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.roomField.ForeColor = System.Drawing.Color.White;
            this.roomField.HideSelection = false;
            this.roomField.Location = new System.Drawing.Point(637, 216);
            this.roomField.Name = "roomField";
            this.roomField.Size = new System.Drawing.Size(200, 22);
            this.roomField.TabIndex = 208;
            this.roomField.TabStop = false;
            this.roomField.Text = "726";
            this.roomField.Click += new System.EventHandler(this.roomField_Click);
            this.roomField.Enter += new System.EventHandler(this.roomField_Enter);
            this.roomField.Leave += new System.EventHandler(this.roomField_Leave);
            // 
            // surnameField
            // 
            this.surnameField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.surnameField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.surnameField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.surnameField.ForeColor = System.Drawing.Color.White;
            this.surnameField.HideSelection = false;
            this.surnameField.Location = new System.Drawing.Point(355, 216);
            this.surnameField.Name = "surnameField";
            this.surnameField.Size = new System.Drawing.Size(200, 22);
            this.surnameField.TabIndex = 207;
            this.surnameField.TabStop = false;
            this.surnameField.Text = "Фролов";
            this.surnameField.Click += new System.EventHandler(this.surnameField_Click);
            this.surnameField.Enter += new System.EventHandler(this.surnameField_Enter);
            this.surnameField.Leave += new System.EventHandler(this.surnameField_Leave);
            // 
            // panelName
            // 
            this.panelName.BackColor = System.Drawing.Color.White;
            this.panelName.Location = new System.Drawing.Point(27, 244);
            this.panelName.Name = "panelName";
            this.panelName.Size = new System.Drawing.Size(250, 1);
            this.panelName.TabIndex = 204;
            // 
            // nameImg
            // 
            this.nameImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female;
            this.nameImg.Image = global::registration.Properties.Resources.user_icon;
            this.nameImg.Location = new System.Drawing.Point(37, 206);
            this.nameImg.Name = "nameImg";
            this.nameImg.Size = new System.Drawing.Size(32, 32);
            this.nameImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nameImg.TabIndex = 202;
            this.nameImg.TabStop = false;
            // 
            // WardrobeGiveBtn
            // 
            this.WardrobeGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WardrobeGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WardrobeGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WardrobeGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.WardrobeGiveBtn.Location = new System.Drawing.Point(963, 478);
            this.WardrobeGiveBtn.Name = "WardrobeGiveBtn";
            this.WardrobeGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.WardrobeGiveBtn.TabIndex = 201;
            this.WardrobeGiveBtn.Text = "Обменять";
            this.WardrobeGiveBtn.UseVisualStyleBackColor = false;
            this.WardrobeGiveBtn.Click += new System.EventHandler(this.WardrobeGiveBtn_Click);
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(27, 564);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 40);
            this.goBackBtn.TabIndex = 197;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(1069, 3);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 196;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(426, 59);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(670, 84);
            this.mainPanel.TabIndex = 195;
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(27, 66);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 194;
            this.logoLabel.Text = "PaperKiller";
            // 
            // ShelfGiveBtn
            // 
            this.ShelfGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShelfGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShelfGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShelfGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShelfGiveBtn.Location = new System.Drawing.Point(963, 423);
            this.ShelfGiveBtn.Name = "ShelfGiveBtn";
            this.ShelfGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.ShelfGiveBtn.TabIndex = 200;
            this.ShelfGiveBtn.Text = "Обменять";
            this.ShelfGiveBtn.UseVisualStyleBackColor = false;
            this.ShelfGiveBtn.Click += new System.EventHandler(this.ShelfGiveBtn_Click);
            // 
            // TableGiveBtn
            // 
            this.TableGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TableGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TableGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TableGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.TableGiveBtn.Location = new System.Drawing.Point(963, 366);
            this.TableGiveBtn.Name = "TableGiveBtn";
            this.TableGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.TableGiveBtn.TabIndex = 199;
            this.TableGiveBtn.Text = "Обменять";
            this.TableGiveBtn.UseVisualStyleBackColor = false;
            this.TableGiveBtn.Click += new System.EventHandler(this.TableGiveBtn_Click);
            // 
            // ChairGiveBtn
            // 
            this.ChairGiveBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChairGiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChairGiveBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChairGiveBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ChairGiveBtn.Location = new System.Drawing.Point(963, 312);
            this.ChairGiveBtn.Name = "ChairGiveBtn";
            this.ChairGiveBtn.Size = new System.Drawing.Size(119, 36);
            this.ChairGiveBtn.TabIndex = 198;
            this.ChairGiveBtn.Text = "Обменять";
            this.ChairGiveBtn.UseVisualStyleBackColor = false;
            this.ChairGiveBtn.Click += new System.EventHandler(this.ChairGiveBtn_Click);
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Font = new System.Drawing.Font("Imprint MT Shadow", 11F);
            this.resultLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.resultLabel.Location = new System.Drawing.Point(996, 220);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(0, 18);
            this.resultLabel.TabIndex = 179;
            // 
            // ChangeItemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1100, 616);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.checkStudentImg);
            this.Controls.Add(this.TowelGiveBtn);
            this.Controls.Add(this.PillowcaseGiveBtn);
            this.Controls.Add(this.BedsheetGiveBtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.surnameImg);
            this.Controls.Add(this.BedspreadGiveBtn);
            this.Controls.Add(this.DuvetGiveBtn);
            this.Controls.Add(this.nameField);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.LinenBox);
            this.Controls.Add(this.ShowLinenBtn);
            this.Controls.Add(this.ShowItemBtn);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.panelRoom);
            this.Controls.Add(this.panelSurname);
            this.Controls.Add(this.roomField);
            this.Controls.Add(this.surnameField);
            this.Controls.Add(this.panelName);
            this.Controls.Add(this.nameImg);
            this.Controls.Add(this.WardrobeGiveBtn);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.ShelfGiveBtn);
            this.Controls.Add(this.TableGiveBtn);
            this.Controls.Add(this.ChairGiveBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChangeItemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ChangeItemForm";
            this.Load += new System.EventHandler(this.ChangeItemForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.checkStudentImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.surnameImg)).EndInit();
            this.ItemBox.ResumeLayout(false);
            this.ItemBox.PerformLayout();
            this.LinenBox.ResumeLayout(false);
            this.LinenBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nameImg)).EndInit();
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Label pillowcaseTmpLabel;
        private System.Windows.Forms.Label duvetTmpLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label duvetSNlabel;
        private System.Windows.Forms.Label towelSNlabel;
        private System.Windows.Forms.Label Label3;
        private System.Windows.Forms.Label bedsheetTmpLabel;
        private System.Windows.Forms.Label bedspreadTmpLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label pillowcaseSNLabel;
        private System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label chairLabel;
        private System.Windows.Forms.PictureBox checkStudentImg;
        private System.Windows.Forms.Button TowelGiveBtn;
        private System.Windows.Forms.Button PillowcaseGiveBtn;
        private System.Windows.Forms.Button BedsheetGiveBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox surnameImg;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label wardrobeLabel;
        private System.Windows.Forms.Label WardrobeSNlabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label TableSNLabel;
        private System.Windows.Forms.Label tableLabel;
        private System.Windows.Forms.Label ChairSNlabel;
        private System.Windows.Forms.Label TableTmpLabel;
        private System.Windows.Forms.Label WardrobeTmpLabel;
        private System.Windows.Forms.Label ShelfTmpLabel;
        private System.Windows.Forms.Label ChairTmpLabel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button BedspreadGiveBtn;
        private System.Windows.Forms.Button DuvetGiveBtn;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.Label towelTmpLabel;
        private System.Windows.Forms.Label bedsheetSNlabel;
        private System.Windows.Forms.Label Label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Panel ItemBox;
        private System.Windows.Forms.Label shelfLabel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label ShelfSNlabel;
        private System.Windows.Forms.Panel LinenBox;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label bedspreadSNlabel;
        private System.Windows.Forms.Button ShowLinenBtn;
        private System.Windows.Forms.Button ShowItemBtn;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.Panel panelRoom;
        private System.Windows.Forms.Panel panelSurname;
        private System.Windows.Forms.TextBox roomField;
        private System.Windows.Forms.TextBox surnameField;
        private System.Windows.Forms.Panel panelName;
        private System.Windows.Forms.PictureBox nameImg;
        private System.Windows.Forms.Button WardrobeGiveBtn;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Button ShelfGiveBtn;
        private System.Windows.Forms.Button TableGiveBtn;
        private System.Windows.Forms.Button ChairGiveBtn;
        private System.Windows.Forms.Label resultLabel;
    }
}