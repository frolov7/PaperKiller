﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccessToDB;
using DataStructures;


using System.Data.SqlClient;

namespace registration
{
    public partial class AuthorizationForm : Form
    {
        Connector connectDB = new Connector();
        Student currentStudent = null;
        //List<Student> allStudents = null;

        public AuthorizationForm()
        {
            InitializeComponent();
            int flag = 0;
            if (flag == 1)
            { 
                loginField.Text = "Логин";
                loginField.ForeColor = Color.Gray;

                passwordField.Text = "Пароль";
                passwordField.ForeColor = Color.Gray;

                studentIDField.Text = "Студенческий";
                studentIDField.ForeColor = Color.Gray;
            }

            
        }

        private void closeLabel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loginField_Click(object sender, EventArgs e)
        {
            loginField.Clear();
            loginImg.BackgroundImage = Properties.Resources.user_icon2;
            panel1.BackColor = Color.FromArgb(255, 153, 0);
            loginField.ForeColor = Color.FromArgb(255, 153, 0);

            panel2.BackColor = Color.WhiteSmoke;
            panel3.BackColor = Color.WhiteSmoke;
        }

        private void passwordField_Click(object sender, EventArgs e)
        {
            passwordField.Clear();
            passwordField.PasswordChar = '*';
            passwordImg.BackgroundImage = Properties.Resources.secure_icon2;
            panel2.BackColor = Color.FromArgb(255, 153, 0);

            panel1.BackColor = Color.WhiteSmoke;
            panel3.BackColor = Color.WhiteSmoke;
        }

        private void emailField_Click(object sender, EventArgs e)
        {
            studentIDField.Clear();
            studentIDImg.BackgroundImage = Properties.Resources.message_icon2;
            panel3.BackColor = Color.FromArgb(255, 153, 0);
            studentIDField.ForeColor = Color.FromArgb(255, 153, 0);

            panel1.BackColor = Color.WhiteSmoke;
            panel2.BackColor = Color.WhiteSmoke;
        }

        private void signinBtn_MouseLeave(object sender, EventArgs e)
        {
            signinBtn.ForeColor = Color.FromArgb(34, 36, 49);
        }

        private void signinBtn_MouseEnter(object sender, EventArgs e)
        {
            signinBtn.ForeColor = Color.White;
        }

        private void registerBtn_MouseEnter(object sender, EventArgs e)
        {
            registerBtn.ForeColor = Color.White;
        }

        Point LastPoint;
        private void authorizationForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - LastPoint.X;
                this.Top += e.Y - LastPoint.Y;
            }
        }

        private void authorizationForm_MouseDown(object sender, MouseEventArgs e)
        {
            LastPoint = new Point(e.X, e.Y);
        }

        private void loginField_Enter(object sender, EventArgs e)
        {
            if (loginField.Text == "Логин")
            {
                loginField.Text = "";
                loginField.ForeColor = Color.Gray;
            }
        }

        private void loginField_Leave(object sender, EventArgs e)
        {
            if (loginField.Text == "")
            {
                loginField.Text = "Логин";
                loginField.ForeColor = Color.Gray;
            }
            if (CheckInfo.isLoginExists(connectDB, loginField.Text))
                checkLoginImg.Image = Properties.Resources.sign_icon;
            else
                checkLoginImg.Image = Properties.Resources.error_icon;
        }

        private void passwordField_Enter(object sender, EventArgs e)
        {
            if (passwordField.Text == "Пароль")
            {
                passwordField.Text = "";
                passwordField.ForeColor = Color.Gray;
            }
        }

        private void passwordField_Leave(object sender, EventArgs e)
        {
            if (passwordField.Text == "")
            {
                passwordField.Text = "Пароль";
                passwordField.ForeColor = Color.Gray;
            }
        }

        private void studentIDField_Leave(object sender, EventArgs e)
        {
            if (studentIDField.Text == "")
            {
                studentIDField.Text = "Студенческий";
                studentIDField.ForeColor = Color.Gray;
            }
            if (CheckInfo.isStudentIDExists(connectDB, studentIDField.Text))
                checkStudentIDImg.Image = Properties.Resources.sign_icon;
            else
                checkStudentIDImg.Image = Properties.Resources.error_icon;
        }

        private void studentIDField_Enter(object sender, EventArgs e)
        {
            if (studentIDField.Text == "Студенческий")
            {
                studentIDField.Text = "";
                studentIDField.ForeColor = Color.Gray;
            }
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog(); // открыть окно
        }

        private void AuthorizationForm_Click(object sender, EventArgs e)
        {
            changePassLabel.Focus();
            panel1.BackColor = Color.WhiteSmoke;
            panel2.BackColor = Color.WhiteSmoke;
            panel3.BackColor = Color.WhiteSmoke;
        }

        private void signinBtn_Click(object sender, EventArgs e)
        {
            string login = loginField.Text;
            string password = passwordField.Text;
            string studentID = studentIDField.Text;

            if (login == "Admin" && password == "Commandant")
            {
                this.Hide(); // закрыть активное окно
                AdminMainMenuForm adminMainMenu = new AdminMainMenuForm(currentStudent, "Commandant");
                adminMainMenu.ShowDialog(); // открыть окно

            }
            else if (login == "Admin" && password == "Manager")
            {
                this.Hide(); // закрыть активное окно
                AdminMainMenuForm adminMainMenu = new AdminMainMenuForm(currentStudent, "Manager");
                adminMainMenu.ShowDialog(); // открыть окно

            }

            bool isLoginTaken = CheckInfo.isLoginExists(connectDB, login); // проверка существования логина
            bool isStudentIDTaken = CheckInfo.isStudentIDExists(connectDB, studentID);

            if (isLoginTaken)
            {
                if (isStudentIDTaken)
                {
                    currentStudent = GetInfo.GetStudentByLogin(connectDB, login, password);
                    if (currentStudent == null)
                        MessageBox.Show("Неверный пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        this.Hide(); // закрыть активное окно
                        UserMainMenuForm userMainMenu = new UserMainMenuForm(currentStudent);
                        userMainMenu.ShowDialog(); // открыть окно

                    }
                }
            }
            else
                MessageBox.Show("Пользователь не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void changePassLabel_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            ForgetPassForm forgetPassForm = new ForgetPassForm();
            forgetPassForm.ShowDialog(); // открыть окно
        }
    }
}
