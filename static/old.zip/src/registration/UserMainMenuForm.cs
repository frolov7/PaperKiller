﻿using AccessToDB;
using DataStructures;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace registration
{
    public partial class UserMainMenuForm : Form
    {
        Connector connectDB = new Connector();
        Student currentStudent;

        Linen currentLinen = null;
        Items currentItems = null;

        public UserMainMenuForm(Student currentStudent)
        {
            InitializeComponent();

            this.currentStudent = currentStudent;
            currentStudent = GetInfo.GetStudentByLogin(connectDB, currentStudent.login, currentStudent.password);

            currentLinen = GetInfo.GetLinenByID(connectDB, currentStudent.userID);
            currentItems = GetInfo.GetItemsByID(connectDB, currentStudent.userID);

            loginLabelTmp.Text = currentStudent.login.ToString();
            nameLabelTmp.Text = currentStudent.name.ToString();
            surnameLabelTmp.Text = currentStudent.surname.ToString();
            phoneLabelTmp.Text = currentStudent.phoneNumber.ToString();
            studentIDLabelTmp.Text = currentStudent.studentID.ToString();
            
            roomLabelTmp.Text = currentStudent.roomNumber.ToString();

            if (currentStudent.roomNumber == "Не назначена")
            {
                statusLabelTmp.Text = "Не проживает";
                PassItemBtn.Enabled = false;
                ChangeLinenBtn.Enabled = false;
                MoveOutBtn.Enabled = false;
            }
            else if (currentStudent.userType == "O")
            {
                statusLabelTmp.Text = "Выселен";
                PassItemBtn.Enabled = false;
                ChangeLinenBtn.Enabled = false;
                MoveOutBtn.Enabled = false;
            }
            else
                statusLabelTmp.Text = "Проживает";


        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            AuthorizationForm authorization = new AuthorizationForm();
            authorization.ShowDialog(); // открыть окно
        }

        private void ChangeDataBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            ChangeDataForm changeForm = new ChangeDataForm(currentStudent);
            changeForm.ShowDialog(); // открыть окно
        }

        private void PassItemBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            ReturnItemForm returnItemForm = new ReturnItemForm(currentStudent);
            returnItemForm.ShowDialog(); // открыть окно
        }

        private void ChangeLinenBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            LinenChangeForm linenChangeForm = new LinenChangeForm(currentStudent);
            linenChangeForm.ShowDialog(); // открыть окно
        }

        private void AllItemsBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            MyItemsForm MyItems = new MyItemsForm(currentStudent);
            MyItems.ShowDialog(); // открыть окно
        }

        private void MoveOutBtn_Click(object sender, EventArgs e)
        {
            if (currentStudent.roomNumber == "Выселен") 
            {
                MessageBox.Show("Вы уже выселены", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }

            DialogResult isOut = MessageBox.Show("Вы уверены, что хотите съехать из комнаты?", "", MessageBoxButtons.YesNo);

            if (isOut == DialogResult.Yes)
            {
                UpdateInfo.UpdateUserType(connectDB, currentStudent.userID, "O");
                UpdateInfo.UpdateRoomNumber(connectDB, currentStudent.userID, "Не назначена");

                roomLabelTmp.Text = "Выселен";
                statusLabelTmp.Text = "Не проживает";

                UpdateInfo.ReturnItemBack(connectDB, "chair_id", currentItems.itemID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "chair", "На складе", currentItems.chairID.ToString());

                UpdateInfo.ReturnItemBack(connectDB, "tables_id", currentItems.itemID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "tables", "На складе", currentItems.tableID.ToString());

                UpdateInfo.ReturnItemBack(connectDB, "shelf_id", currentItems.itemID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "shelf", "На складе", currentItems.shelfID.ToString());

                UpdateInfo.ReturnItemBack(connectDB, "wardrobe_id", currentItems.itemID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "wardrobe", "На складе", currentItems.wardrobeID.ToString());

                UpdateInfo.ReturnLinenBack(connectDB, "bedsheet_id", currentLinen.linenID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "bedsheet", "На складе", currentLinen.bedsheetID.ToString());

                UpdateInfo.ReturnLinenBack(connectDB, "pillowcase_id", currentLinen.linenID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "pillowcase", "На складе", currentLinen.pillowcaseID.ToString());

                UpdateInfo.ReturnLinenBack(connectDB, "duvet_id", currentLinen.linenID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "duvet", "На складе", currentLinen.duvetID.ToString());

                UpdateInfo.ReturnLinenBack(connectDB, "bedspread_id", currentLinen.linenID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "bedspread", "На складе", currentLinen.bedspreadID.ToString());

                UpdateInfo.ReturnLinenBack(connectDB, "towel_id", currentLinen.linenID.ToString());
                UpdateInfo.ChangeItemStatus(connectDB, "towel", "На складе", currentLinen.towelID.ToString());

                PassItemBtn.Enabled = false;
                ChangeLinenBtn.Enabled = false;
                MoveOutBtn.Enabled = false;
                currentStudent = GetInfo.GetStudentByLogin(connectDB, currentStudent.login, currentStudent.password);
            }
            else
                return; 
        }
    }
}
