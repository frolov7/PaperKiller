﻿namespace registration
{
    partial class AdminMainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headingPanel = new System.Windows.Forms.Panel();
            this.headingLabel = new System.Windows.Forms.Label();
            this.closeBtn = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.AllStudentBtn = new System.Windows.Forms.Button();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.userLabel = new System.Windows.Forms.Label();
            this.loginLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusLabelTmp = new System.Windows.Forms.Label();
            this.loginLabelTmp = new System.Windows.Forms.Label();
            this.userLabelTmp = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.AllItemsBtn = new System.Windows.Forms.Button();
            this.GiveItemBtn = new System.Windows.Forms.Button();
            this.ChangeItemBtn = new System.Windows.Forms.Button();
            this.AddItemBtn = new System.Windows.Forms.Button();
            this.TakeItemBtn = new System.Windows.Forms.Button();
            this.ReportBtn = new System.Windows.Forms.Button();
            this.headingPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // headingPanel
            // 
            this.headingPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.headingPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.headingPanel.Controls.Add(this.headingLabel);
            this.headingPanel.Location = new System.Drawing.Point(432, 56);
            this.headingPanel.Name = "headingPanel";
            this.headingPanel.Size = new System.Drawing.Size(670, 84);
            this.headingPanel.TabIndex = 42;
            // 
            // headingLabel
            // 
            this.headingLabel.AutoSize = true;
            this.headingLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.headingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.headingLabel.Location = new System.Drawing.Point(45, 8);
            this.headingLabel.Name = "headingLabel";
            this.headingLabel.Size = new System.Drawing.Size(507, 74);
            this.headingLabel.TabIndex = 30;
            this.headingLabel.Text = "Главное меню";
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(1075, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 43;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(33, 63);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 41;
            this.logoLabel.Text = "PaperKiller";
            // 
            // AllStudentBtn
            // 
            this.AllStudentBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.AllStudentBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AllStudentBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllStudentBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllStudentBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.AllStudentBtn.Location = new System.Drawing.Point(31, 287);
            this.AllStudentBtn.Name = "AllStudentBtn";
            this.AllStudentBtn.Size = new System.Drawing.Size(300, 70);
            this.AllStudentBtn.TabIndex = 45;
            this.AllStudentBtn.Text = "Посмотреть список студентов";
            this.AllStudentBtn.UseVisualStyleBackColor = false;
            this.AllStudentBtn.Click += new System.EventHandler(this.AllStudentBtn_Click);
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(432, 519);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 40);
            this.goBackBtn.TabIndex = 47;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userLabel.ForeColor = System.Drawing.Color.White;
            this.userLabel.Location = new System.Drawing.Point(6, 16);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(147, 28);
            this.userLabel.TabIndex = 49;
            this.userLabel.Text = "Пользователь:";
            // 
            // loginLabel
            // 
            this.loginLabel.AutoSize = true;
            this.loginLabel.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginLabel.ForeColor = System.Drawing.Color.White;
            this.loginLabel.Location = new System.Drawing.Point(6, 49);
            this.loginLabel.Name = "loginLabel";
            this.loginLabel.Size = new System.Drawing.Size(72, 28);
            this.loginLabel.TabIndex = 50;
            this.loginLabel.Text = "Логин:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.statusLabelTmp);
            this.groupBox1.Controls.Add(this.loginLabelTmp);
            this.groupBox1.Controls.Add(this.userLabelTmp);
            this.groupBox1.Controls.Add(this.statusLabel);
            this.groupBox1.Controls.Add(this.userLabel);
            this.groupBox1.Controls.Add(this.loginLabel);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(31, 134);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(356, 121);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            // 
            // statusLabelTmp
            // 
            this.statusLabelTmp.AutoSize = true;
            this.statusLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabelTmp.ForeColor = System.Drawing.Color.White;
            this.statusLabelTmp.Location = new System.Drawing.Point(183, 81);
            this.statusLabelTmp.Name = "statusLabelTmp";
            this.statusLabelTmp.Size = new System.Drawing.Size(82, 28);
            this.statusLabelTmp.TabIndex = 54;
            this.statusLabelTmp.Text = "status";
            // 
            // loginLabelTmp
            // 
            this.loginLabelTmp.AutoSize = true;
            this.loginLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.loginLabelTmp.ForeColor = System.Drawing.Color.White;
            this.loginLabelTmp.Location = new System.Drawing.Point(183, 49);
            this.loginLabelTmp.Name = "loginLabelTmp";
            this.loginLabelTmp.Size = new System.Drawing.Size(69, 28);
            this.loginLabelTmp.TabIndex = 53;
            this.loginLabelTmp.Text = "login";
            // 
            // userLabelTmp
            // 
            this.userLabelTmp.AutoSize = true;
            this.userLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.userLabelTmp.ForeColor = System.Drawing.Color.White;
            this.userLabelTmp.Location = new System.Drawing.Point(183, 16);
            this.userLabelTmp.Name = "userLabelTmp";
            this.userLabelTmp.Size = new System.Drawing.Size(64, 28);
            this.userLabelTmp.TabIndex = 52;
            this.userLabelTmp.Text = "user";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.ForeColor = System.Drawing.Color.White;
            this.statusLabel.Location = new System.Drawing.Point(7, 81);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(175, 28);
            this.statusLabel.TabIndex = 51;
            this.statusLabel.Text = "Уровень доступа:";
            // 
            // AllItemsBtn
            // 
            this.AllItemsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.AllItemsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AllItemsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllItemsBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllItemsBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.AllItemsBtn.Location = new System.Drawing.Point(400, 285);
            this.AllItemsBtn.Name = "AllItemsBtn";
            this.AllItemsBtn.Size = new System.Drawing.Size(300, 70);
            this.AllItemsBtn.TabIndex = 52;
            this.AllItemsBtn.Text = "Посмотреть список вещей";
            this.AllItemsBtn.UseVisualStyleBackColor = false;
            this.AllItemsBtn.Click += new System.EventHandler(this.AllItemsBtn_Click);
            // 
            // GiveItemBtn
            // 
            this.GiveItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.GiveItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GiveItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GiveItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiveItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.GiveItemBtn.Location = new System.Drawing.Point(31, 389);
            this.GiveItemBtn.Name = "GiveItemBtn";
            this.GiveItemBtn.Size = new System.Drawing.Size(300, 70);
            this.GiveItemBtn.TabIndex = 53;
            this.GiveItemBtn.Text = "Выдать студенту вещь";
            this.GiveItemBtn.UseVisualStyleBackColor = false;
            this.GiveItemBtn.Click += new System.EventHandler(this.GiveItemBtn_Click);
            // 
            // ChangeItemBtn
            // 
            this.ChangeItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ChangeItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangeItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ChangeItemBtn.Location = new System.Drawing.Point(400, 389);
            this.ChangeItemBtn.Name = "ChangeItemBtn";
            this.ChangeItemBtn.Size = new System.Drawing.Size(300, 70);
            this.ChangeItemBtn.TabIndex = 54;
            this.ChangeItemBtn.Text = "Заменить студенту вещь";
            this.ChangeItemBtn.UseVisualStyleBackColor = false;
            this.ChangeItemBtn.Click += new System.EventHandler(this.ChangeItemBtn_Click);
            // 
            // AddItemBtn
            // 
            this.AddItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.AddItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.AddItemBtn.Location = new System.Drawing.Point(769, 285);
            this.AddItemBtn.Name = "AddItemBtn";
            this.AddItemBtn.Size = new System.Drawing.Size(300, 70);
            this.AddItemBtn.TabIndex = 55;
            this.AddItemBtn.Text = "Добавить вещь на склад";
            this.AddItemBtn.UseVisualStyleBackColor = false;
            this.AddItemBtn.Click += new System.EventHandler(this.AddItemBtn_Click);
            // 
            // TakeItemBtn
            // 
            this.TakeItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.TakeItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TakeItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TakeItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TakeItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.TakeItemBtn.Location = new System.Drawing.Point(769, 389);
            this.TakeItemBtn.Name = "TakeItemBtn";
            this.TakeItemBtn.Size = new System.Drawing.Size(300, 70);
            this.TakeItemBtn.TabIndex = 56;
            this.TakeItemBtn.Text = "Забрать вещь у студента";
            this.TakeItemBtn.UseVisualStyleBackColor = false;
            this.TakeItemBtn.Click += new System.EventHandler(this.TakeItemBtn_Click);
            // 
            // ReportBtn
            // 
            this.ReportBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ReportBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReportBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReportBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ReportBtn.Location = new System.Drawing.Point(769, 181);
            this.ReportBtn.Name = "ReportBtn";
            this.ReportBtn.Size = new System.Drawing.Size(300, 70);
            this.ReportBtn.TabIndex = 57;
            this.ReportBtn.Text = "Журнал обмена";
            this.ReportBtn.UseVisualStyleBackColor = false;
            this.ReportBtn.Click += new System.EventHandler(this.ReportBtn_Click);
            // 
            // AdminMainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1100, 571);
            this.Controls.Add(this.ReportBtn);
            this.Controls.Add(this.TakeItemBtn);
            this.Controls.Add(this.AddItemBtn);
            this.Controls.Add(this.ChangeItemBtn);
            this.Controls.Add(this.GiveItemBtn);
            this.Controls.Add(this.AllItemsBtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.AllStudentBtn);
            this.Controls.Add(this.headingPanel);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminMainMenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AdminMainMenuForm";
            this.Load += new System.EventHandler(this.AdminMainMenuForm_Load);
            this.headingPanel.ResumeLayout(false);
            this.headingPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel headingPanel;
        private System.Windows.Forms.Label headingLabel;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Button AllStudentBtn;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label loginLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label statusLabelTmp;
        private System.Windows.Forms.Label loginLabelTmp;
        private System.Windows.Forms.Label userLabelTmp;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button AllItemsBtn;
        private System.Windows.Forms.Button GiveItemBtn;
        private System.Windows.Forms.Button ChangeItemBtn;
        private System.Windows.Forms.Button AddItemBtn;
        private System.Windows.Forms.Button TakeItemBtn;
        private System.Windows.Forms.Button ReportBtn;
    }
}