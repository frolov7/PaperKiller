﻿namespace registration
{
    partial class UserMainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainPanel = new System.Windows.Forms.Panel();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.closeBtn = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusLabelTmp = new System.Windows.Forms.Label();
            this.roomLabelTmp = new System.Windows.Forms.Label();
            this.studentIDLabelTmp = new System.Windows.Forms.Label();
            this.phoneLabelTmp = new System.Windows.Forms.Label();
            this.surnameLabelTmp = new System.Windows.Forms.Label();
            this.nameLabelTmp = new System.Windows.Forms.Label();
            this.labelStatus = new System.Windows.Forms.Label();
            this.labelLogin = new System.Windows.Forms.Label();
            this.loginLabelTmp = new System.Windows.Forms.Label();
            this.labelRoom = new System.Windows.Forms.Label();
            this.labelStudentID = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelSurname = new System.Windows.Forms.Label();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.ChangeLinenBtn = new System.Windows.Forms.Button();
            this.PassItemBtn = new System.Windows.Forms.Button();
            this.ChangeDataBtn = new System.Windows.Forms.Button();
            this.MoveOutBtn = new System.Windows.Forms.Button();
            this.AllItemsBtn = new System.Windows.Forms.Button();
            this.mainPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(576, 69);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(4);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(893, 103);
            this.mainPanel.TabIndex = 33;
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(60, 10);
            this.registrationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(507, 74);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Главное меню";
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(44, 78);
            this.logoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 32;
            this.logoLabel.Text = "PaperKiller";
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(1433, 0);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 40;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.statusLabelTmp);
            this.groupBox1.Controls.Add(this.roomLabelTmp);
            this.groupBox1.Controls.Add(this.studentIDLabelTmp);
            this.groupBox1.Controls.Add(this.phoneLabelTmp);
            this.groupBox1.Controls.Add(this.surnameLabelTmp);
            this.groupBox1.Controls.Add(this.nameLabelTmp);
            this.groupBox1.Controls.Add(this.labelStatus);
            this.groupBox1.Controls.Add(this.labelLogin);
            this.groupBox1.Controls.Add(this.loginLabelTmp);
            this.groupBox1.Controls.Add(this.labelRoom);
            this.groupBox1.Controls.Add(this.labelStudentID);
            this.groupBox1.Controls.Add(this.labelPhone);
            this.groupBox1.Controls.Add(this.labelName);
            this.groupBox1.Controls.Add(this.labelSurname);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(41, 191);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(475, 343);
            this.groupBox1.TabIndex = 55;
            this.groupBox1.TabStop = false;
            // 
            // statusLabelTmp
            // 
            this.statusLabelTmp.AutoSize = true;
            this.statusLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.statusLabelTmp.ForeColor = System.Drawing.Color.White;
            this.statusLabelTmp.Location = new System.Drawing.Point(207, 290);
            this.statusLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.statusLabelTmp.Name = "statusLabelTmp";
            this.statusLabelTmp.Size = new System.Drawing.Size(82, 28);
            this.statusLabelTmp.TabIndex = 61;
            this.statusLabelTmp.Text = "status";
            // 
            // roomLabelTmp
            // 
            this.roomLabelTmp.AutoSize = true;
            this.roomLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.roomLabelTmp.ForeColor = System.Drawing.Color.White;
            this.roomLabelTmp.Location = new System.Drawing.Point(207, 245);
            this.roomLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.roomLabelTmp.Name = "roomLabelTmp";
            this.roomLabelTmp.Size = new System.Drawing.Size(165, 28);
            this.roomLabelTmp.TabIndex = 60;
            this.roomLabelTmp.Text = "roomNumber";
            // 
            // studentIDLabelTmp
            // 
            this.studentIDLabelTmp.AutoSize = true;
            this.studentIDLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.studentIDLabelTmp.ForeColor = System.Drawing.Color.White;
            this.studentIDLabelTmp.Location = new System.Drawing.Point(207, 199);
            this.studentIDLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.studentIDLabelTmp.Name = "studentIDLabelTmp";
            this.studentIDLabelTmp.Size = new System.Drawing.Size(124, 28);
            this.studentIDLabelTmp.TabIndex = 59;
            this.studentIDLabelTmp.Text = "studentID";
            // 
            // phoneLabelTmp
            // 
            this.phoneLabelTmp.AutoSize = true;
            this.phoneLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.phoneLabelTmp.ForeColor = System.Drawing.Color.White;
            this.phoneLabelTmp.Location = new System.Drawing.Point(207, 153);
            this.phoneLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.phoneLabelTmp.Name = "phoneLabelTmp";
            this.phoneLabelTmp.Size = new System.Drawing.Size(176, 28);
            this.phoneLabelTmp.TabIndex = 58;
            this.phoneLabelTmp.Text = "phoneNumber";
            // 
            // surnameLabelTmp
            // 
            this.surnameLabelTmp.AutoSize = true;
            this.surnameLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.surnameLabelTmp.ForeColor = System.Drawing.Color.White;
            this.surnameLabelTmp.Location = new System.Drawing.Point(207, 107);
            this.surnameLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.surnameLabelTmp.Name = "surnameLabelTmp";
            this.surnameLabelTmp.Size = new System.Drawing.Size(113, 28);
            this.surnameLabelTmp.TabIndex = 57;
            this.surnameLabelTmp.Text = "surname";
            // 
            // nameLabelTmp
            // 
            this.nameLabelTmp.AutoSize = true;
            this.nameLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.nameLabelTmp.ForeColor = System.Drawing.Color.White;
            this.nameLabelTmp.Location = new System.Drawing.Point(207, 62);
            this.nameLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameLabelTmp.Name = "nameLabelTmp";
            this.nameLabelTmp.Size = new System.Drawing.Size(75, 28);
            this.nameLabelTmp.TabIndex = 56;
            this.nameLabelTmp.Text = "name";
            // 
            // labelStatus
            // 
            this.labelStatus.AutoSize = true;
            this.labelStatus.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatus.ForeColor = System.Drawing.Color.White;
            this.labelStatus.Location = new System.Drawing.Point(9, 290);
            this.labelStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(80, 28);
            this.labelStatus.TabIndex = 55;
            this.labelStatus.Text = "Статус:";
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelLogin.ForeColor = System.Drawing.Color.White;
            this.labelLogin.Location = new System.Drawing.Point(8, 20);
            this.labelLogin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(61, 25);
            this.labelLogin.TabIndex = 54;
            this.labelLogin.Text = "Login:";
            // 
            // loginLabelTmp
            // 
            this.loginLabelTmp.AutoSize = true;
            this.loginLabelTmp.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F);
            this.loginLabelTmp.ForeColor = System.Drawing.Color.White;
            this.loginLabelTmp.Location = new System.Drawing.Point(207, 20);
            this.loginLabelTmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.loginLabelTmp.Name = "loginLabelTmp";
            this.loginLabelTmp.Size = new System.Drawing.Size(69, 28);
            this.loginLabelTmp.TabIndex = 53;
            this.loginLabelTmp.Text = "login";
            // 
            // labelRoom
            // 
            this.labelRoom.AutoSize = true;
            this.labelRoom.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRoom.ForeColor = System.Drawing.Color.White;
            this.labelRoom.Location = new System.Drawing.Point(9, 245);
            this.labelRoom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRoom.Name = "labelRoom";
            this.labelRoom.Size = new System.Drawing.Size(122, 28);
            this.labelRoom.TabIndex = 53;
            this.labelRoom.Text = "№ комнаты:";
            // 
            // labelStudentID
            // 
            this.labelStudentID.AutoSize = true;
            this.labelStudentID.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStudentID.ForeColor = System.Drawing.Color.White;
            this.labelStudentID.Location = new System.Drawing.Point(9, 199);
            this.labelStudentID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStudentID.Name = "labelStudentID";
            this.labelStudentID.Size = new System.Drawing.Size(146, 28);
            this.labelStudentID.TabIndex = 52;
            this.labelStudentID.Text = "Студенческий:";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPhone.ForeColor = System.Drawing.Color.White;
            this.labelPhone.Location = new System.Drawing.Point(9, 153);
            this.labelPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(98, 28);
            this.labelPhone.TabIndex = 51;
            this.labelPhone.Text = "Телефон:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(9, 62);
            this.labelName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(54, 28);
            this.labelName.TabIndex = 49;
            this.labelName.Text = "Имя:";
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSurname.ForeColor = System.Drawing.Color.White;
            this.labelSurname.Location = new System.Drawing.Point(9, 107);
            this.labelSurname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(99, 28);
            this.labelSurname.TabIndex = 50;
            this.labelSurname.Text = "Фамилия:";
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(576, 639);
            this.goBackBtn.Margin = new System.Windows.Forms.Padding(4);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(333, 49);
            this.goBackBtn.TabIndex = 54;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // ChangeLinenBtn
            // 
            this.ChangeLinenBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ChangeLinenBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangeLinenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeLinenBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.ChangeLinenBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ChangeLinenBtn.Location = new System.Drawing.Point(1035, 246);
            this.ChangeLinenBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ChangeLinenBtn.Name = "ChangeLinenBtn";
            this.ChangeLinenBtn.Size = new System.Drawing.Size(400, 86);
            this.ChangeLinenBtn.TabIndex = 53;
            this.ChangeLinenBtn.Text = "Обменять белье";
            this.ChangeLinenBtn.UseVisualStyleBackColor = false;
            this.ChangeLinenBtn.Click += new System.EventHandler(this.ChangeLinenBtn_Click);
            // 
            // PassItemBtn
            // 
            this.PassItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PassItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PassItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PassItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.PassItemBtn.Location = new System.Drawing.Point(576, 246);
            this.PassItemBtn.Margin = new System.Windows.Forms.Padding(4);
            this.PassItemBtn.Name = "PassItemBtn";
            this.PassItemBtn.Size = new System.Drawing.Size(400, 86);
            this.PassItemBtn.TabIndex = 52;
            this.PassItemBtn.Text = "Обменять вещи";
            this.PassItemBtn.UseVisualStyleBackColor = false;
            this.PassItemBtn.Click += new System.EventHandler(this.PassItemBtn_Click);
            // 
            // ChangeDataBtn
            // 
            this.ChangeDataBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ChangeDataBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangeDataBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeDataBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeDataBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ChangeDataBtn.Location = new System.Drawing.Point(84, 542);
            this.ChangeDataBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ChangeDataBtn.Name = "ChangeDataBtn";
            this.ChangeDataBtn.Size = new System.Drawing.Size(400, 54);
            this.ChangeDataBtn.TabIndex = 56;
            this.ChangeDataBtn.Text = "Изменить данные";
            this.ChangeDataBtn.UseVisualStyleBackColor = false;
            this.ChangeDataBtn.Click += new System.EventHandler(this.ChangeDataBtn_Click);
            // 
            // MoveOutBtn
            // 
            this.MoveOutBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.MoveOutBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MoveOutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MoveOutBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoveOutBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.MoveOutBtn.Location = new System.Drawing.Point(576, 411);
            this.MoveOutBtn.Margin = new System.Windows.Forms.Padding(4);
            this.MoveOutBtn.Name = "MoveOutBtn";
            this.MoveOutBtn.Size = new System.Drawing.Size(400, 86);
            this.MoveOutBtn.TabIndex = 59;
            this.MoveOutBtn.Text = "Съехать из общежития";
            this.MoveOutBtn.UseVisualStyleBackColor = false;
            this.MoveOutBtn.Click += new System.EventHandler(this.MoveOutBtn_Click);
            // 
            // AllItemsBtn
            // 
            this.AllItemsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.AllItemsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AllItemsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllItemsBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllItemsBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.AllItemsBtn.Location = new System.Drawing.Point(1035, 410);
            this.AllItemsBtn.Margin = new System.Windows.Forms.Padding(4);
            this.AllItemsBtn.Name = "AllItemsBtn";
            this.AllItemsBtn.Size = new System.Drawing.Size(400, 86);
            this.AllItemsBtn.TabIndex = 60;
            this.AllItemsBtn.Text = "Мои вещи";
            this.AllItemsBtn.UseVisualStyleBackColor = false;
            this.AllItemsBtn.Click += new System.EventHandler(this.AllItemsBtn_Click);
            // 
            // UserMainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1467, 703);
            this.Controls.Add(this.AllItemsBtn);
            this.Controls.Add(this.MoveOutBtn);
            this.Controls.Add(this.ChangeDataBtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.ChangeLinenBtn);
            this.Controls.Add(this.PassItemBtn);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UserMainMenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserMainMenuForm";
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label statusLabelTmp;
        private System.Windows.Forms.Label roomLabelTmp;
        private System.Windows.Forms.Label studentIDLabelTmp;
        private System.Windows.Forms.Label phoneLabelTmp;
        private System.Windows.Forms.Label surnameLabelTmp;
        private System.Windows.Forms.Label nameLabelTmp;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.Label loginLabelTmp;
        private System.Windows.Forms.Label labelRoom;
        private System.Windows.Forms.Label labelStudentID;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Button ChangeLinenBtn;
        private System.Windows.Forms.Button PassItemBtn;
        private System.Windows.Forms.Button ChangeDataBtn;
        private System.Windows.Forms.Button MoveOutBtn;
        private System.Windows.Forms.Button AllItemsBtn;
    }
}