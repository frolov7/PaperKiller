﻿namespace registration
{
    partial class AddItemsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ShowWardrobeBtn = new System.Windows.Forms.Button();
            this.ShowShelfBtn = new System.Windows.Forms.Button();
            this.ShowTablesBtn = new System.Windows.Forms.Button();
            this.closeLabel = new System.Windows.Forms.Label();
            this.studentsTableAdapter = new registration.masterDataSetTableAdapters.studentsTableAdapter();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.masterDataSet = new registration.masterDataSet();
            this.studentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.headingLabel = new System.Windows.Forms.Label();
            this.headingPanel = new System.Windows.Forms.Panel();
            this.logoLabel = new System.Windows.Forms.Label();
            this.ShowChairBtn = new System.Windows.Forms.Button();
            this.AddChairBtn = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chairField = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableField = new System.Windows.Forms.TextBox();
            this.wardrobeField = new System.Windows.Forms.TextBox();
            this.shelfField = new System.Windows.Forms.TextBox();
            this.AddShelfBtn = new System.Windows.Forms.PictureBox();
            this.AddWardrobeBtn = new System.Windows.Forms.PictureBox();
            this.AddTableBtn = new System.Windows.Forms.PictureBox();
            this.dataGridChair = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isGivenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chairBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetChair = new registration.masterDataSetChair();
            this.chairTableAdapter = new registration.masterDataSetChairTableAdapters.chairTableAdapter();
            this.dataGridTables = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetTables = new registration.masterDataSetTables();
            this.tablesTableAdapter1 = new registration.masterDataSetTablesTableAdapters.tablesTableAdapter();
            this.dataGridLinen = new System.Windows.Forms.DataGridView();
            this.dataGridWardrobe = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wardrobeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetWardrobe = new registration.masterDataSetWardrobe();
            this.wardrobeTableAdapter = new registration.masterDataSetWardrobeTableAdapters.wardrobeTableAdapter();
            this.dataGridShelf = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shelfBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetShelf = new registration.masterDataSetShelf();
            this.shelfTableAdapter = new registration.masterDataSetShelfTableAdapters.shelfTableAdapter();
            this.linenBox = new System.Windows.Forms.ComboBox();
            this.AddPillowcaseBtn = new System.Windows.Forms.PictureBox();
            this.pillowcaseField = new System.Windows.Forms.TextBox();
            this.AddDuvetBtn = new System.Windows.Forms.PictureBox();
            this.duvetField = new System.Windows.Forms.TextBox();
            this.AddBedsheetBtn = new System.Windows.Forms.PictureBox();
            this.bedsheetField = new System.Windows.Forms.TextBox();
            this.bedspreadField = new System.Windows.Forms.TextBox();
            this.AddBedspreadBtn = new System.Windows.Forms.PictureBox();
            this.AddTowelBtn = new System.Windows.Forms.PictureBox();
            this.towelField = new System.Windows.Forms.TextBox();
            this.dataGridTowel = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.towelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetTowel = new registration.masterDataSetTowel();
            this.bedsheetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetBedsheet = new registration.masterDataSetBedsheet();
            this.bedsheetTableAdapter = new registration.masterDataSetBedsheetTableAdapters.bedsheetTableAdapter();
            this.bedspreadBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetBedspread = new registration.masterDataSetBedspread();
            this.bedspreadTableAdapter = new registration.masterDataSetBedspreadTableAdapters.bedspreadTableAdapter();
            this.towelTableAdapter = new registration.masterDataSetTowelTableAdapters.towelTableAdapter();
            this.pillowcaseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetPillowcase1 = new registration.masterDataSetPillowcase();
            this.duvetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSetDuvet = new registration.masterDataSetDuvet();
            this.duvetTableAdapter = new registration.masterDataSetDuvetTableAdapters.duvetTableAdapter();
            this.pillowcaseTableAdapter1 = new registration.masterDataSetPillowcaseTableAdapters.pillowcaseTableAdapter();
            this.dataGridDuvet = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridBedsheet = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridBedspread = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridPillowcase = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).BeginInit();
            this.headingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddChairBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddShelfBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddWardrobeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddTableBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridChair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chairBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetChair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTables)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetTables)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridLinen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridWardrobe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wardrobeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetWardrobe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridShelf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shelfBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetShelf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddPillowcaseBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddDuvetBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBedsheetBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBedspreadBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddTowelBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTowel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.towelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetTowel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bedsheetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetBedsheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bedspreadBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetBedspread)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillowcaseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetPillowcase1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.duvetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetDuvet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDuvet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBedsheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBedspread)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPillowcase)).BeginInit();
            this.SuspendLayout();
            // 
            // ShowWardrobeBtn
            // 
            this.ShowWardrobeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowWardrobeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowWardrobeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowWardrobeBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowWardrobeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowWardrobeBtn.Location = new System.Drawing.Point(463, 442);
            this.ShowWardrobeBtn.Name = "ShowWardrobeBtn";
            this.ShowWardrobeBtn.Size = new System.Drawing.Size(187, 35);
            this.ShowWardrobeBtn.TabIndex = 81;
            this.ShowWardrobeBtn.Text = "Шкафы";
            this.ShowWardrobeBtn.UseVisualStyleBackColor = false;
            this.ShowWardrobeBtn.Click += new System.EventHandler(this.ShowWardrobeBtn_Click);
            // 
            // ShowShelfBtn
            // 
            this.ShowShelfBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowShelfBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowShelfBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowShelfBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowShelfBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowShelfBtn.Location = new System.Drawing.Point(675, 442);
            this.ShowShelfBtn.Name = "ShowShelfBtn";
            this.ShowShelfBtn.Size = new System.Drawing.Size(187, 35);
            this.ShowShelfBtn.TabIndex = 82;
            this.ShowShelfBtn.Text = "Полки";
            this.ShowShelfBtn.UseVisualStyleBackColor = false;
            this.ShowShelfBtn.Click += new System.EventHandler(this.ShowShelfBtn_Click);
            // 
            // ShowTablesBtn
            // 
            this.ShowTablesBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowTablesBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowTablesBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowTablesBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowTablesBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowTablesBtn.Location = new System.Drawing.Point(246, 442);
            this.ShowTablesBtn.Name = "ShowTablesBtn";
            this.ShowTablesBtn.Size = new System.Drawing.Size(187, 35);
            this.ShowTablesBtn.TabIndex = 80;
            this.ShowTablesBtn.Text = "Столы";
            this.ShowTablesBtn.UseVisualStyleBackColor = false;
            this.ShowTablesBtn.Click += new System.EventHandler(this.ShowTablesBtn_Click);
            // 
            // closeLabel
            // 
            this.closeLabel.AutoSize = true;
            this.closeLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeLabel.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.closeLabel.Location = new System.Drawing.Point(1071, 2);
            this.closeLabel.Name = "closeLabel";
            this.closeLabel.Size = new System.Drawing.Size(27, 36);
            this.closeLabel.TabIndex = 73;
            this.closeLabel.Text = "X";
            this.closeLabel.Click += new System.EventHandler(this.closeLabel_Click);
            // 
            // studentsTableAdapter
            // 
            this.studentsTableAdapter.ClearBeforeFill = true;
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(432, 519);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 40);
            this.goBackBtn.TabIndex = 77;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // masterDataSet
            // 
            this.masterDataSet.DataSetName = "masterDataSet";
            this.masterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentsBindingSource
            // 
            this.studentsBindingSource.DataMember = "students";
            this.studentsBindingSource.DataSource = this.masterDataSet;
            // 
            // headingLabel
            // 
            this.headingLabel.AutoSize = true;
            this.headingLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 36.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.headingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.headingLabel.Location = new System.Drawing.Point(7, 17);
            this.headingLabel.Name = "headingLabel";
            this.headingLabel.Size = new System.Drawing.Size(662, 57);
            this.headingLabel.TabIndex = 30;
            this.headingLabel.Text = "Добавить вещь на склад";
            // 
            // headingPanel
            // 
            this.headingPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.headingPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.headingPanel.Controls.Add(this.headingLabel);
            this.headingPanel.Location = new System.Drawing.Point(432, 56);
            this.headingPanel.Name = "headingPanel";
            this.headingPanel.Size = new System.Drawing.Size(670, 84);
            this.headingPanel.TabIndex = 75;
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(33, 63);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 74;
            this.logoLabel.Text = "PaperKiller";
            // 
            // ShowChairBtn
            // 
            this.ShowChairBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowChairBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowChairBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowChairBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowChairBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowChairBtn.Location = new System.Drawing.Point(28, 442);
            this.ShowChairBtn.Name = "ShowChairBtn";
            this.ShowChairBtn.Size = new System.Drawing.Size(187, 35);
            this.ShowChairBtn.TabIndex = 79;
            this.ShowChairBtn.Text = "Стулья";
            this.ShowChairBtn.UseVisualStyleBackColor = false;
            this.ShowChairBtn.Click += new System.EventHandler(this.ShowChairBtn_Click);
            // 
            // AddChairBtn
            // 
            this.AddChairBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddChairBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddChairBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddChairBtn.Location = new System.Drawing.Point(353, 398);
            this.AddChairBtn.Name = "AddChairBtn";
            this.AddChairBtn.Size = new System.Drawing.Size(18, 18);
            this.AddChairBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddChairBtn.TabIndex = 90;
            this.AddChairBtn.TabStop = false;
            this.AddChairBtn.Click += new System.EventHandler(this.AddChairBtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panel1.Location = new System.Drawing.Point(29, 422);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(350, 1);
            this.panel1.TabIndex = 89;
            // 
            // chairField
            // 
            this.chairField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.chairField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chairField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chairField.ForeColor = System.Drawing.Color.White;
            this.chairField.HideSelection = false;
            this.chairField.Location = new System.Drawing.Point(147, 395);
            this.chairField.Name = "chairField";
            this.chairField.Size = new System.Drawing.Size(200, 25);
            this.chairField.TabIndex = 88;
            this.chairField.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(32, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 18);
            this.label1.TabIndex = 91;
            this.label1.Text = "Serial Number";
            // 
            // tableField
            // 
            this.tableField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tableField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tableField.ForeColor = System.Drawing.Color.White;
            this.tableField.HideSelection = false;
            this.tableField.Location = new System.Drawing.Point(147, 395);
            this.tableField.Name = "tableField";
            this.tableField.Size = new System.Drawing.Size(200, 25);
            this.tableField.TabIndex = 92;
            this.tableField.TabStop = false;
            // 
            // wardrobeField
            // 
            this.wardrobeField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.wardrobeField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wardrobeField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.wardrobeField.ForeColor = System.Drawing.Color.White;
            this.wardrobeField.HideSelection = false;
            this.wardrobeField.Location = new System.Drawing.Point(147, 395);
            this.wardrobeField.Name = "wardrobeField";
            this.wardrobeField.Size = new System.Drawing.Size(200, 25);
            this.wardrobeField.TabIndex = 94;
            this.wardrobeField.TabStop = false;
            // 
            // shelfField
            // 
            this.shelfField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.shelfField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shelfField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.shelfField.ForeColor = System.Drawing.Color.White;
            this.shelfField.HideSelection = false;
            this.shelfField.Location = new System.Drawing.Point(147, 395);
            this.shelfField.Name = "shelfField";
            this.shelfField.Size = new System.Drawing.Size(200, 25);
            this.shelfField.TabIndex = 95;
            this.shelfField.TabStop = false;
            // 
            // AddShelfBtn
            // 
            this.AddShelfBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddShelfBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddShelfBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddShelfBtn.Location = new System.Drawing.Point(353, 398);
            this.AddShelfBtn.Name = "AddShelfBtn";
            this.AddShelfBtn.Size = new System.Drawing.Size(18, 18);
            this.AddShelfBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddShelfBtn.TabIndex = 97;
            this.AddShelfBtn.TabStop = false;
            this.AddShelfBtn.Click += new System.EventHandler(this.AddShelfBtn_Click);
            // 
            // AddWardrobeBtn
            // 
            this.AddWardrobeBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddWardrobeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddWardrobeBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddWardrobeBtn.Location = new System.Drawing.Point(353, 398);
            this.AddWardrobeBtn.Name = "AddWardrobeBtn";
            this.AddWardrobeBtn.Size = new System.Drawing.Size(18, 18);
            this.AddWardrobeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddWardrobeBtn.TabIndex = 98;
            this.AddWardrobeBtn.TabStop = false;
            this.AddWardrobeBtn.Click += new System.EventHandler(this.AddWardrobeBtn_Click);
            // 
            // AddTableBtn
            // 
            this.AddTableBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddTableBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddTableBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddTableBtn.Location = new System.Drawing.Point(353, 398);
            this.AddTableBtn.Name = "AddTableBtn";
            this.AddTableBtn.Size = new System.Drawing.Size(18, 18);
            this.AddTableBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddTableBtn.TabIndex = 99;
            this.AddTableBtn.TabStop = false;
            this.AddTableBtn.Click += new System.EventHandler(this.AddTableBtn_Click);
            // 
            // dataGridChair
            // 
            this.dataGridChair.AutoGenerateColumns = false;
            this.dataGridChair.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridChair.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridChair.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridChair.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.serialNumberDataGridViewTextBoxColumn,
            this.isGivenDataGridViewTextBoxColumn});
            this.dataGridChair.DataSource = this.chairBindingSource;
            this.dataGridChair.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridChair.Location = new System.Drawing.Point(28, 155);
            this.dataGridChair.Name = "dataGridChair";
            this.dataGridChair.Size = new System.Drawing.Size(1044, 221);
            this.dataGridChair.TabIndex = 100;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // serialNumberDataGridViewTextBoxColumn
            // 
            this.serialNumberDataGridViewTextBoxColumn.DataPropertyName = "serialNumber";
            this.serialNumberDataGridViewTextBoxColumn.HeaderText = "serialNumber";
            this.serialNumberDataGridViewTextBoxColumn.Name = "serialNumberDataGridViewTextBoxColumn";
            // 
            // isGivenDataGridViewTextBoxColumn
            // 
            this.isGivenDataGridViewTextBoxColumn.DataPropertyName = "isGiven";
            this.isGivenDataGridViewTextBoxColumn.HeaderText = "isGiven";
            this.isGivenDataGridViewTextBoxColumn.Name = "isGivenDataGridViewTextBoxColumn";
            // 
            // chairBindingSource
            // 
            this.chairBindingSource.DataMember = "chair";
            this.chairBindingSource.DataSource = this.masterDataSetChair;
            // 
            // masterDataSetChair
            // 
            this.masterDataSetChair.DataSetName = "masterDataSetChair";
            this.masterDataSetChair.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // chairTableAdapter
            // 
            this.chairTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridTables
            // 
            this.dataGridTables.AutoGenerateColumns = false;
            this.dataGridTables.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridTables.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridTables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridTables.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dataGridTables.DataSource = this.tablesBindingSource;
            this.dataGridTables.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridTables.Location = new System.Drawing.Point(28, 155);
            this.dataGridTables.Name = "dataGridTables";
            this.dataGridTables.Size = new System.Drawing.Size(1044, 221);
            this.dataGridTables.TabIndex = 101;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn1.HeaderText = "id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn2.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn3.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // tablesBindingSource
            // 
            this.tablesBindingSource.DataMember = "tables";
            this.tablesBindingSource.DataSource = this.masterDataSetTables;
            // 
            // masterDataSetTables
            // 
            this.masterDataSetTables.DataSetName = "masterDataSetTables";
            this.masterDataSetTables.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tablesTableAdapter1
            // 
            this.tablesTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridLinen
            // 
            this.dataGridLinen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridLinen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridLinen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridLinen.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridLinen.Location = new System.Drawing.Point(28, 155);
            this.dataGridLinen.Name = "dataGridLinen";
            this.dataGridLinen.Size = new System.Drawing.Size(1044, 221);
            this.dataGridLinen.TabIndex = 102;
            // 
            // dataGridWardrobe
            // 
            this.dataGridWardrobe.AutoGenerateColumns = false;
            this.dataGridWardrobe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridWardrobe.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridWardrobe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridWardrobe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.dataGridWardrobe.DataSource = this.wardrobeBindingSource;
            this.dataGridWardrobe.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridWardrobe.Location = new System.Drawing.Point(29, 155);
            this.dataGridWardrobe.Name = "dataGridWardrobe";
            this.dataGridWardrobe.Size = new System.Drawing.Size(1044, 221);
            this.dataGridWardrobe.TabIndex = 103;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn7.HeaderText = "id";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn8.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn9.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // wardrobeBindingSource
            // 
            this.wardrobeBindingSource.DataMember = "wardrobe";
            this.wardrobeBindingSource.DataSource = this.masterDataSetWardrobe;
            // 
            // masterDataSetWardrobe
            // 
            this.masterDataSetWardrobe.DataSetName = "masterDataSetWardrobe";
            this.masterDataSetWardrobe.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // wardrobeTableAdapter
            // 
            this.wardrobeTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridShelf
            // 
            this.dataGridShelf.AutoGenerateColumns = false;
            this.dataGridShelf.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridShelf.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridShelf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridShelf.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dataGridShelf.DataSource = this.shelfBindingSource;
            this.dataGridShelf.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridShelf.Location = new System.Drawing.Point(28, 155);
            this.dataGridShelf.Name = "dataGridShelf";
            this.dataGridShelf.Size = new System.Drawing.Size(1044, 221);
            this.dataGridShelf.TabIndex = 104;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn10.HeaderText = "id";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn11.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn12.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // shelfBindingSource
            // 
            this.shelfBindingSource.DataMember = "shelf";
            this.shelfBindingSource.DataSource = this.masterDataSetShelf;
            // 
            // masterDataSetShelf
            // 
            this.masterDataSetShelf.DataSetName = "masterDataSetShelf";
            this.masterDataSetShelf.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // shelfTableAdapter
            // 
            this.shelfTableAdapter.ClearBeforeFill = true;
            // 
            // linenBox
            // 
            this.linenBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.linenBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linenBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.linenBox.Font = new System.Drawing.Font("Century", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linenBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.linenBox.FormattingEnabled = true;
            this.linenBox.Items.AddRange(new object[] {
            "Полотенце",
            "Простыня",
            "Покрывало",
            "Пододеяльник",
            "Наволочка"});
            this.linenBox.Location = new System.Drawing.Point(885, 441);
            this.linenBox.Name = "linenBox";
            this.linenBox.Size = new System.Drawing.Size(187, 36);
            this.linenBox.TabIndex = 105;
            this.linenBox.Text = "Постель";
            this.linenBox.SelectedIndexChanged += new System.EventHandler(this.linenBox_SelectedIndexChanged);
            // 
            // AddPillowcaseBtn
            // 
            this.AddPillowcaseBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddPillowcaseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddPillowcaseBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddPillowcaseBtn.Location = new System.Drawing.Point(353, 398);
            this.AddPillowcaseBtn.Name = "AddPillowcaseBtn";
            this.AddPillowcaseBtn.Size = new System.Drawing.Size(18, 18);
            this.AddPillowcaseBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddPillowcaseBtn.TabIndex = 106;
            this.AddPillowcaseBtn.TabStop = false;
            this.AddPillowcaseBtn.Click += new System.EventHandler(this.AddPillowcaseBtn_Click);
            // 
            // pillowcaseField
            // 
            this.pillowcaseField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pillowcaseField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pillowcaseField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseField.ForeColor = System.Drawing.Color.White;
            this.pillowcaseField.HideSelection = false;
            this.pillowcaseField.Location = new System.Drawing.Point(147, 395);
            this.pillowcaseField.Name = "pillowcaseField";
            this.pillowcaseField.Size = new System.Drawing.Size(200, 25);
            this.pillowcaseField.TabIndex = 107;
            this.pillowcaseField.TabStop = false;
            // 
            // AddDuvetBtn
            // 
            this.AddDuvetBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddDuvetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddDuvetBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddDuvetBtn.Location = new System.Drawing.Point(353, 398);
            this.AddDuvetBtn.Name = "AddDuvetBtn";
            this.AddDuvetBtn.Size = new System.Drawing.Size(18, 18);
            this.AddDuvetBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddDuvetBtn.TabIndex = 108;
            this.AddDuvetBtn.TabStop = false;
            this.AddDuvetBtn.Click += new System.EventHandler(this.AddDuvetBtn_Click);
            // 
            // duvetField
            // 
            this.duvetField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.duvetField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.duvetField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetField.ForeColor = System.Drawing.Color.White;
            this.duvetField.HideSelection = false;
            this.duvetField.Location = new System.Drawing.Point(147, 395);
            this.duvetField.Name = "duvetField";
            this.duvetField.Size = new System.Drawing.Size(200, 25);
            this.duvetField.TabIndex = 109;
            this.duvetField.TabStop = false;
            // 
            // AddBedsheetBtn
            // 
            this.AddBedsheetBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddBedsheetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddBedsheetBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddBedsheetBtn.Location = new System.Drawing.Point(353, 398);
            this.AddBedsheetBtn.Name = "AddBedsheetBtn";
            this.AddBedsheetBtn.Size = new System.Drawing.Size(18, 18);
            this.AddBedsheetBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddBedsheetBtn.TabIndex = 110;
            this.AddBedsheetBtn.TabStop = false;
            this.AddBedsheetBtn.Click += new System.EventHandler(this.AddBedsheetBtn_Click);
            // 
            // bedsheetField
            // 
            this.bedsheetField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.bedsheetField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bedsheetField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetField.ForeColor = System.Drawing.Color.White;
            this.bedsheetField.HideSelection = false;
            this.bedsheetField.Location = new System.Drawing.Point(147, 395);
            this.bedsheetField.Name = "bedsheetField";
            this.bedsheetField.Size = new System.Drawing.Size(200, 25);
            this.bedsheetField.TabIndex = 111;
            this.bedsheetField.TabStop = false;
            // 
            // bedspreadField
            // 
            this.bedspreadField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.bedspreadField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bedspreadField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadField.ForeColor = System.Drawing.Color.White;
            this.bedspreadField.HideSelection = false;
            this.bedspreadField.Location = new System.Drawing.Point(147, 395);
            this.bedspreadField.Name = "bedspreadField";
            this.bedspreadField.Size = new System.Drawing.Size(200, 25);
            this.bedspreadField.TabIndex = 112;
            this.bedspreadField.TabStop = false;
            // 
            // AddBedspreadBtn
            // 
            this.AddBedspreadBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddBedspreadBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddBedspreadBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddBedspreadBtn.Location = new System.Drawing.Point(353, 398);
            this.AddBedspreadBtn.Name = "AddBedspreadBtn";
            this.AddBedspreadBtn.Size = new System.Drawing.Size(18, 18);
            this.AddBedspreadBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddBedspreadBtn.TabIndex = 113;
            this.AddBedspreadBtn.TabStop = false;
            this.AddBedspreadBtn.Click += new System.EventHandler(this.AddBedspreadBtn_Click);
            // 
            // AddTowelBtn
            // 
            this.AddTowelBtn.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.AddTowelBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddTowelBtn.Image = global::registration.Properties.Resources.sign_icon;
            this.AddTowelBtn.Location = new System.Drawing.Point(353, 398);
            this.AddTowelBtn.Name = "AddTowelBtn";
            this.AddTowelBtn.Size = new System.Drawing.Size(18, 18);
            this.AddTowelBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AddTowelBtn.TabIndex = 114;
            this.AddTowelBtn.TabStop = false;
            this.AddTowelBtn.Click += new System.EventHandler(this.AddTowelBtn_Click);
            // 
            // towelField
            // 
            this.towelField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.towelField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.towelField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelField.ForeColor = System.Drawing.Color.White;
            this.towelField.HideSelection = false;
            this.towelField.Location = new System.Drawing.Point(147, 395);
            this.towelField.Name = "towelField";
            this.towelField.Size = new System.Drawing.Size(200, 25);
            this.towelField.TabIndex = 115;
            this.towelField.TabStop = false;
            // 
            // dataGridTowel
            // 
            this.dataGridTowel.AutoGenerateColumns = false;
            this.dataGridTowel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridTowel.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridTowel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridTowel.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dataGridTowel.DataSource = this.towelBindingSource;
            this.dataGridTowel.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridTowel.Location = new System.Drawing.Point(29, 155);
            this.dataGridTowel.Name = "dataGridTowel";
            this.dataGridTowel.Size = new System.Drawing.Size(1044, 221);
            this.dataGridTowel.TabIndex = 116;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn4.HeaderText = "id";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn5.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn6.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // towelBindingSource
            // 
            this.towelBindingSource.DataMember = "towel";
            this.towelBindingSource.DataSource = this.masterDataSetTowel;
            // 
            // masterDataSetTowel
            // 
            this.masterDataSetTowel.DataSetName = "masterDataSetTowel";
            this.masterDataSetTowel.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bedsheetBindingSource
            // 
            this.bedsheetBindingSource.DataMember = "bedsheet";
            this.bedsheetBindingSource.DataSource = this.masterDataSetBedsheet;
            // 
            // masterDataSetBedsheet
            // 
            this.masterDataSetBedsheet.DataSetName = "masterDataSetBedsheet";
            this.masterDataSetBedsheet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bedsheetTableAdapter
            // 
            this.bedsheetTableAdapter.ClearBeforeFill = true;
            // 
            // bedspreadBindingSource
            // 
            this.bedspreadBindingSource.DataMember = "bedspread";
            this.bedspreadBindingSource.DataSource = this.masterDataSetBedspread;
            // 
            // masterDataSetBedspread
            // 
            this.masterDataSetBedspread.DataSetName = "masterDataSetBedspread";
            this.masterDataSetBedspread.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bedspreadTableAdapter
            // 
            this.bedspreadTableAdapter.ClearBeforeFill = true;
            // 
            // towelTableAdapter
            // 
            this.towelTableAdapter.ClearBeforeFill = true;
            // 
            // pillowcaseBindingSource
            // 
            this.pillowcaseBindingSource.DataMember = "pillowcase";
            this.pillowcaseBindingSource.DataSource = this.masterDataSetPillowcase1;
            // 
            // masterDataSetPillowcase1
            // 
            this.masterDataSetPillowcase1.DataSetName = "masterDataSetPillowcase";
            this.masterDataSetPillowcase1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // duvetBindingSource
            // 
            this.duvetBindingSource.DataMember = "duvet";
            this.duvetBindingSource.DataSource = this.masterDataSetDuvet;
            // 
            // masterDataSetDuvet
            // 
            this.masterDataSetDuvet.DataSetName = "masterDataSetDuvet";
            this.masterDataSetDuvet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // duvetTableAdapter
            // 
            this.duvetTableAdapter.ClearBeforeFill = true;
            // 
            // pillowcaseTableAdapter1
            // 
            this.pillowcaseTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridDuvet
            // 
            this.dataGridDuvet.AutoGenerateColumns = false;
            this.dataGridDuvet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridDuvet.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridDuvet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridDuvet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.dataGridDuvet.DataSource = this.duvetBindingSource;
            this.dataGridDuvet.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridDuvet.Location = new System.Drawing.Point(28, 155);
            this.dataGridDuvet.Name = "dataGridDuvet";
            this.dataGridDuvet.Size = new System.Drawing.Size(1044, 221);
            this.dataGridDuvet.TabIndex = 117;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn13.HeaderText = "id";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn14.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn15.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridBedsheet
            // 
            this.dataGridBedsheet.AutoGenerateColumns = false;
            this.dataGridBedsheet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridBedsheet.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridBedsheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridBedsheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.dataGridBedsheet.DataSource = this.bedsheetBindingSource;
            this.dataGridBedsheet.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridBedsheet.Location = new System.Drawing.Point(28, 155);
            this.dataGridBedsheet.Name = "dataGridBedsheet";
            this.dataGridBedsheet.Size = new System.Drawing.Size(1044, 221);
            this.dataGridBedsheet.TabIndex = 118;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn16.HeaderText = "id";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn17.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn18.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridBedspread
            // 
            this.dataGridBedspread.AutoGenerateColumns = false;
            this.dataGridBedspread.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridBedspread.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridBedspread.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridBedspread.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21});
            this.dataGridBedspread.DataSource = this.bedspreadBindingSource;
            this.dataGridBedspread.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridBedspread.Location = new System.Drawing.Point(28, 155);
            this.dataGridBedspread.Name = "dataGridBedspread";
            this.dataGridBedspread.Size = new System.Drawing.Size(1044, 221);
            this.dataGridBedspread.TabIndex = 119;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn19.HeaderText = "id";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn20.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn21.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridPillowcase
            // 
            this.dataGridPillowcase.AutoGenerateColumns = false;
            this.dataGridPillowcase.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridPillowcase.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridPillowcase.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPillowcase.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24});
            this.dataGridPillowcase.DataSource = this.pillowcaseBindingSource;
            this.dataGridPillowcase.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.dataGridPillowcase.Location = new System.Drawing.Point(28, 155);
            this.dataGridPillowcase.Name = "dataGridPillowcase";
            this.dataGridPillowcase.Size = new System.Drawing.Size(1044, 221);
            this.dataGridPillowcase.TabIndex = 120;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn22.HeaderText = "id";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "serialNumber";
            this.dataGridViewTextBoxColumn23.HeaderText = "serialNumber";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "isGiven";
            this.dataGridViewTextBoxColumn24.HeaderText = "isGiven";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // AddItemsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1100, 571);
            this.Controls.Add(this.dataGridPillowcase);
            this.Controls.Add(this.dataGridBedspread);
            this.Controls.Add(this.dataGridBedsheet);
            this.Controls.Add(this.dataGridDuvet);
            this.Controls.Add(this.dataGridTowel);
            this.Controls.Add(this.towelField);
            this.Controls.Add(this.AddTowelBtn);
            this.Controls.Add(this.AddBedspreadBtn);
            this.Controls.Add(this.bedspreadField);
            this.Controls.Add(this.bedsheetField);
            this.Controls.Add(this.AddBedsheetBtn);
            this.Controls.Add(this.duvetField);
            this.Controls.Add(this.AddDuvetBtn);
            this.Controls.Add(this.pillowcaseField);
            this.Controls.Add(this.AddPillowcaseBtn);
            this.Controls.Add(this.linenBox);
            this.Controls.Add(this.dataGridShelf);
            this.Controls.Add(this.dataGridWardrobe);
            this.Controls.Add(this.dataGridLinen);
            this.Controls.Add(this.dataGridTables);
            this.Controls.Add(this.dataGridChair);
            this.Controls.Add(this.AddTableBtn);
            this.Controls.Add(this.AddWardrobeBtn);
            this.Controls.Add(this.AddShelfBtn);
            this.Controls.Add(this.shelfField);
            this.Controls.Add(this.wardrobeField);
            this.Controls.Add(this.tableField);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AddChairBtn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.chairField);
            this.Controls.Add(this.ShowWardrobeBtn);
            this.Controls.Add(this.ShowShelfBtn);
            this.Controls.Add(this.ShowTablesBtn);
            this.Controls.Add(this.closeLabel);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.headingPanel);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.ShowChairBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddItemsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddItemsForm";
            this.Load += new System.EventHandler(this.AddItemsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).EndInit();
            this.headingPanel.ResumeLayout(false);
            this.headingPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddChairBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddShelfBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddWardrobeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddTableBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridChair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chairBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetChair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTables)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetTables)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridLinen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridWardrobe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wardrobeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetWardrobe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridShelf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shelfBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetShelf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddPillowcaseBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddDuvetBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBedsheetBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddBedspreadBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddTowelBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTowel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.towelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetTowel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bedsheetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetBedsheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bedspreadBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetBedspread)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillowcaseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetPillowcase1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.duvetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSetDuvet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDuvet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBedsheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridBedspread)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPillowcase)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button ShowWardrobeBtn;
        private System.Windows.Forms.Button ShowShelfBtn;
        private System.Windows.Forms.Button ShowTablesBtn;
        private System.Windows.Forms.Label closeLabel;
        private masterDataSetTableAdapters.studentsTableAdapter studentsTableAdapter;
        private System.Windows.Forms.Button goBackBtn;
        private masterDataSet masterDataSet;
        private System.Windows.Forms.BindingSource studentsBindingSource;
        private System.Windows.Forms.Label headingLabel;
        private System.Windows.Forms.Panel headingPanel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Button ShowChairBtn;
        private System.Windows.Forms.PictureBox AddChairBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox chairField;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tableField;
        private System.Windows.Forms.TextBox wardrobeField;
        private System.Windows.Forms.TextBox shelfField;
        private System.Windows.Forms.PictureBox AddShelfBtn;
        private System.Windows.Forms.PictureBox AddWardrobeBtn;
        private System.Windows.Forms.PictureBox AddTableBtn;
        private System.Windows.Forms.DataGridView dataGridChair;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn isGivenDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource chairBindingSource;
        private masterDataSetChair masterDataSetChair;
        private masterDataSetChairTableAdapters.chairTableAdapter chairTableAdapter;
        private System.Windows.Forms.DataGridView dataGridTables;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource tablesBindingSource;
        private masterDataSetTables masterDataSetTables;
        private masterDataSetTablesTableAdapters.tablesTableAdapter tablesTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridLinen;
        private System.Windows.Forms.DataGridView dataGridWardrobe;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.BindingSource wardrobeBindingSource;
        private masterDataSetWardrobe masterDataSetWardrobe;
        private masterDataSetWardrobeTableAdapters.wardrobeTableAdapter wardrobeTableAdapter;
        private System.Windows.Forms.DataGridView dataGridShelf;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private masterDataSetShelf masterDataSetShelf;
        private System.Windows.Forms.BindingSource shelfBindingSource;
        private masterDataSetShelfTableAdapters.shelfTableAdapter shelfTableAdapter;
        private System.Windows.Forms.ComboBox linenBox;
        private System.Windows.Forms.PictureBox AddPillowcaseBtn;
        private System.Windows.Forms.TextBox pillowcaseField;
        private System.Windows.Forms.PictureBox AddDuvetBtn;
        private System.Windows.Forms.TextBox duvetField;
        private System.Windows.Forms.PictureBox AddBedsheetBtn;
        private System.Windows.Forms.TextBox bedsheetField;
        private System.Windows.Forms.TextBox bedspreadField;
        private System.Windows.Forms.PictureBox AddBedspreadBtn;
        private System.Windows.Forms.PictureBox AddTowelBtn;
        private System.Windows.Forms.TextBox towelField;
        private System.Windows.Forms.DataGridView dataGridTowel;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.BindingSource bedsheetBindingSource;
        private masterDataSetBedsheet masterDataSetBedsheet;
        private masterDataSetBedsheetTableAdapters.bedsheetTableAdapter bedsheetTableAdapter;
        private System.Windows.Forms.BindingSource bedspreadBindingSource;
        private masterDataSetBedspread masterDataSetBedspread;
        private masterDataSetBedspreadTableAdapters.bedspreadTableAdapter bedspreadTableAdapter;
        private System.Windows.Forms.BindingSource towelBindingSource;
        private masterDataSetTowel masterDataSetTowel;
        private masterDataSetTowelTableAdapters.towelTableAdapter towelTableAdapter;
        private System.Windows.Forms.BindingSource pillowcaseBindingSource;
        private masterDataSetPillowcase masterDataSetPillowcase1;
        private System.Windows.Forms.BindingSource duvetBindingSource;
        private masterDataSetDuvet masterDataSetDuvet;
        private masterDataSetDuvetTableAdapters.duvetTableAdapter duvetTableAdapter;
        private masterDataSetPillowcaseTableAdapters.pillowcaseTableAdapter pillowcaseTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridDuvet;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridView dataGridBedsheet;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridView dataGridBedspread;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridView dataGridPillowcase;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
    }
}