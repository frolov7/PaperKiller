﻿namespace registration
{
    partial class AuthorizationForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AuthorizationForm));
            this.logoLabel = new System.Windows.Forms.Label();
            this.loginField = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.passwordField = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.studentIDField = new System.Windows.Forms.TextBox();
            this.signinBtn = new System.Windows.Forms.Button();
            this.registerBtn = new System.Windows.Forms.Button();
            this.closeLabel = new System.Windows.Forms.Label();
            this.changePassLabel = new System.Windows.Forms.Label();
            this.checkStudentIDImg = new System.Windows.Forms.PictureBox();
            this.checkLoginImg = new System.Windows.Forms.PictureBox();
            this.studentIDImg = new System.Windows.Forms.PictureBox();
            this.passwordImg = new System.Windows.Forms.PictureBox();
            this.loginImg = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.checkStudentIDImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkLoginImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentIDImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).BeginInit();
            this.SuspendLayout();
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(22, 61);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(277, 46);
            this.logoLabel.TabIndex = 1;
            this.logoLabel.Text = "PaperKiller";
            // 
            // loginField
            // 
            this.loginField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.loginField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loginField.ForeColor = System.Drawing.Color.White;
            this.loginField.HideSelection = false;
            this.loginField.Location = new System.Drawing.Point(93, 161);
            this.loginField.Name = "loginField";
            this.loginField.Size = new System.Drawing.Size(200, 18);
            this.loginField.TabIndex = 4;
            this.loginField.TabStop = false;
            this.loginField.Text = "Admin";
            this.loginField.Click += new System.EventHandler(this.loginField_Click);
            this.loginField.Enter += new System.EventHandler(this.loginField_Enter);
            this.loginField.Leave += new System.EventHandler(this.loginField_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(43, 185);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 1);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(43, 255);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 1);
            this.panel2.TabIndex = 8;
            // 
            // passwordField
            // 
            this.passwordField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passwordField.ForeColor = System.Drawing.Color.White;
            this.passwordField.HideSelection = false;
            this.passwordField.Location = new System.Drawing.Point(93, 231);
            this.passwordField.Name = "passwordField";
            this.passwordField.Size = new System.Drawing.Size(200, 18);
            this.passwordField.TabIndex = 7;
            this.passwordField.TabStop = false;
            this.passwordField.Text = "Manager";
            this.passwordField.Click += new System.EventHandler(this.passwordField_Click);
            this.passwordField.Enter += new System.EventHandler(this.passwordField_Enter);
            this.passwordField.Leave += new System.EventHandler(this.passwordField_Leave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(43, 325);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 11;
            // 
            // studentIDField
            // 
            this.studentIDField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.studentIDField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.studentIDField.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.studentIDField.ForeColor = System.Drawing.Color.White;
            this.studentIDField.HideSelection = false;
            this.studentIDField.Location = new System.Drawing.Point(93, 301);
            this.studentIDField.Name = "studentIDField";
            this.studentIDField.Size = new System.Drawing.Size(200, 18);
            this.studentIDField.TabIndex = 10;
            this.studentIDField.TabStop = false;
            this.studentIDField.Text = "19u962";
            this.studentIDField.Click += new System.EventHandler(this.emailField_Click);
            this.studentIDField.Enter += new System.EventHandler(this.studentIDField_Enter);
            this.studentIDField.Leave += new System.EventHandler(this.studentIDField_Leave);
            // 
            // signinBtn
            // 
            this.signinBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.signinBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signinBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signinBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.signinBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.signinBtn.Location = new System.Drawing.Point(43, 348);
            this.signinBtn.Name = "signinBtn";
            this.signinBtn.Size = new System.Drawing.Size(250, 37);
            this.signinBtn.TabIndex = 12;
            this.signinBtn.Text = "Войти";
            this.signinBtn.UseVisualStyleBackColor = false;
            this.signinBtn.Click += new System.EventHandler(this.signinBtn_Click);
            this.signinBtn.MouseEnter += new System.EventHandler(this.signinBtn_MouseEnter);
            this.signinBtn.MouseLeave += new System.EventHandler(this.signinBtn_MouseLeave);
            // 
            // registerBtn
            // 
            this.registerBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registerBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.registerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registerBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.registerBtn.ForeColor = System.Drawing.Color.White;
            this.registerBtn.Location = new System.Drawing.Point(43, 400);
            this.registerBtn.Name = "registerBtn";
            this.registerBtn.Size = new System.Drawing.Size(250, 37);
            this.registerBtn.TabIndex = 13;
            this.registerBtn.Text = "Зарегистрироваться";
            this.registerBtn.UseVisualStyleBackColor = false;
            this.registerBtn.Click += new System.EventHandler(this.registerBtn_Click);
            this.registerBtn.MouseEnter += new System.EventHandler(this.registerBtn_MouseEnter);
            // 
            // closeLabel
            // 
            this.closeLabel.AutoSize = true;
            this.closeLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeLabel.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.closeLabel.Location = new System.Drawing.Point(287, 0);
            this.closeLabel.Name = "closeLabel";
            this.closeLabel.Size = new System.Drawing.Size(27, 36);
            this.closeLabel.TabIndex = 14;
            this.closeLabel.Text = "X";
            this.closeLabel.Click += new System.EventHandler(this.closeLabel_Click);
            // 
            // changePassLabel
            // 
            this.changePassLabel.AutoSize = true;
            this.changePassLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changePassLabel.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.changePassLabel.ForeColor = System.Drawing.Color.Gold;
            this.changePassLabel.Location = new System.Drawing.Point(116, 451);
            this.changePassLabel.Name = "changePassLabel";
            this.changePassLabel.Size = new System.Drawing.Size(97, 14);
            this.changePassLabel.TabIndex = 15;
            this.changePassLabel.Text = "Забыли пароль?";
            this.changePassLabel.Click += new System.EventHandler(this.changePassLabel_Click);
            // 
            // checkStudentIDImg
            // 
            this.checkStudentIDImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.checkStudentIDImg.Location = new System.Drawing.Point(275, 301);
            this.checkStudentIDImg.Name = "checkStudentIDImg";
            this.checkStudentIDImg.Size = new System.Drawing.Size(18, 18);
            this.checkStudentIDImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.checkStudentIDImg.TabIndex = 45;
            this.checkStudentIDImg.TabStop = false;
            // 
            // checkLoginImg
            // 
            this.checkLoginImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.checkLoginImg.Location = new System.Drawing.Point(275, 161);
            this.checkLoginImg.Name = "checkLoginImg";
            this.checkLoginImg.Size = new System.Drawing.Size(18, 18);
            this.checkLoginImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.checkLoginImg.TabIndex = 44;
            this.checkLoginImg.TabStop = false;
            // 
            // studentIDImg
            // 
            this.studentIDImg.BackgroundImage = global::registration.Properties.Resources.message_icon2;
            this.studentIDImg.Image = global::registration.Properties.Resources.learning;
            this.studentIDImg.Location = new System.Drawing.Point(53, 295);
            this.studentIDImg.Name = "studentIDImg";
            this.studentIDImg.Size = new System.Drawing.Size(24, 24);
            this.studentIDImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.studentIDImg.TabIndex = 9;
            this.studentIDImg.TabStop = false;
            // 
            // passwordImg
            // 
            this.passwordImg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passwordImg.BackgroundImage")));
            this.passwordImg.Image = ((System.Drawing.Image)(resources.GetObject("passwordImg.Image")));
            this.passwordImg.Location = new System.Drawing.Point(53, 225);
            this.passwordImg.Name = "passwordImg";
            this.passwordImg.Size = new System.Drawing.Size(24, 24);
            this.passwordImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordImg.TabIndex = 6;
            this.passwordImg.TabStop = false;
            // 
            // loginImg
            // 
            this.loginImg.BackgroundImage = global::registration.Properties.Resources.user_icon2;
            this.loginImg.Image = global::registration.Properties.Resources.login_icon;
            this.loginImg.Location = new System.Drawing.Point(53, 155);
            this.loginImg.Name = "loginImg";
            this.loginImg.Size = new System.Drawing.Size(24, 24);
            this.loginImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginImg.TabIndex = 3;
            this.loginImg.TabStop = false;
            // 
            // AuthorizationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(314, 483);
            this.Controls.Add(this.checkStudentIDImg);
            this.Controls.Add(this.checkLoginImg);
            this.Controls.Add(this.changePassLabel);
            this.Controls.Add(this.closeLabel);
            this.Controls.Add(this.registerBtn);
            this.Controls.Add(this.signinBtn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.studentIDField);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.studentIDImg);
            this.Controls.Add(this.passwordField);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.passwordImg);
            this.Controls.Add(this.loginField);
            this.Controls.Add(this.loginImg);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AuthorizationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.TopMost = true;
            this.Click += new System.EventHandler(this.AuthorizationForm_Click);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.authorizationForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.authorizationForm_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.checkStudentIDImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkLoginImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentIDImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.PictureBox loginImg;
        private System.Windows.Forms.TextBox loginField;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox passwordField;
        private System.Windows.Forms.PictureBox passwordImg;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox studentIDField;
        private System.Windows.Forms.PictureBox studentIDImg;
        private System.Windows.Forms.Button signinBtn;
        private System.Windows.Forms.Button registerBtn;
        private System.Windows.Forms.Label closeLabel;
        private System.Windows.Forms.Label changePassLabel;
        private System.Windows.Forms.PictureBox checkLoginImg;
        private System.Windows.Forms.PictureBox checkStudentIDImg;
    }
}

