﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccessToDB;
using DataStructures;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace registration
{
    public partial class ChangeDataForm : Form
    {
        Student currentStudent;
        Connector connectDB = new Connector();
        public ChangeDataForm(Student currentStudent)
        {
            InitializeComponent();

            this.currentStudent = currentStudent;

            nameField.Text = currentStudent.name.ToString();
            surnameField.Text = currentStudent.surname.ToString();
            loginField.Text = currentStudent.login.ToString();
            phoneField.Text = currentStudent.phoneNumber.ToString();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            UserMainMenuForm userMainMenu = new UserMainMenuForm(currentStudent);
            userMainMenu.ShowDialog(); // открыть окно
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
        }

        // Проверка на заполнение всех полей
        public Boolean isFilled()
        {
            Boolean filled = true;

            if (nameField.Text != "" || surnameField.Text != "" || phoneField.Text != "" || 
                loginField.Text != "" || passwordField.Text != "" || passwordRepeatField.Text != "")
                filled = false;
            return filled;
        }
        // Проверка на совадение паролей
        public Boolean isEqualPass()
        {
            Boolean isEqual = false;

            if (passwordField.Text == passwordRepeatField.Text)
                isEqual = true;
            return isEqual;
        }
        // Проверка на корректность телефона
        public Boolean isRightPhone()
        {
            Boolean isRightPhone = false;

            if (Regex.IsMatch(phoneField.Text, @"\+7\d{3}\d{3}\d{4}$"))
                isRightPhone = true;

            return isRightPhone;
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            // Проверка на заполнение всех полей
            if (isFilled())
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на существующий логин
            else if (currentStudent.login != loginField.Text)
            {
                if (CheckInfo.isLoginExists(connectDB, loginField.Text))
                {
                    MessageBox.Show("Такой логин уже существует. Введите другой", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // Проверка на совадение паролей
            else if (!isEqualPass())
            {
                MessageBox.Show("Пароли не совпадают", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Проверка на корректность телефона
            else if (!isRightPhone())
            {
                MessageBox.Show("Задайте правильно номер телефона", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                string newLogin = loginField.Text;
                string newPassword = passwordField.Text;

                string newName = nameField.Text;
                string newSurname = surnameField.Text;
                string newPhone = phoneField.Text;

                //UpdateInfo.UpdateStudentsData(connectDB, newName, newSurname, newPhone, currentStudent.login);
                UpdateInfo.ProcUpdateData(connectDB);
                UpdateInfo.ExecProc(connectDB, newName, newSurname, newPhone, currentStudent.login);
                UpdateInfo.DropProc(connectDB);
                UpdateInfo.UpdateUsersData(connectDB, currentStudent.login, newLogin, newPassword);
                currentStudent = GetInfo.GetStudentByLogin(connectDB, newLogin, newPassword);

                MessageBox.Show("Изменения были добавлены", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide(); // закрыть активное окно
                UserMainMenuForm userMainMenu = new UserMainMenuForm(currentStudent);
                userMainMenu.ShowDialog(); // открыть окно
            }
        }
    }
}
