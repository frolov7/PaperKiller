﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccessToDB;
using DataStructures;


using System.Data.SqlClient;
using registration.masterDataSetTableAdapters;

namespace registration
{
    public partial class ShowStudentsForm : Form
    {
        Connector connectDB = new Connector();
        Student currentStudent;

        public ShowStudentsForm(Student currentStudent)
        {
            InitializeComponent();
            this.currentStudent = currentStudent;
        }

        private void closeLabel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowStudentsForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "masterDataSetS.students". При необходимости она может быть перемещена или удалена.
            this.studentsTableAdapter1.Fill(this.masterDataSetS.students);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "masterDataSet.students". При необходимости она может быть перемещена или удалена.
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            UpdateInfo.UpdateUserType(connectDB, (index + 1).ToString(), "S".ToString());
            UpdateInfo.UpdateRoomNumber(connectDB, (index + 1).ToString(), dataGridView1.SelectedCells[0].Value.ToString());
            studentsTableAdapter1.Fill(this.masterDataSetS.students);
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;

            if (dataGridView1.SelectedCells[0].Value.ToString() == "")
                MessageBox.Show("Студент не распределен", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            { 
                UpdateInfo.UpdateUserType(connectDB, (index + 1).ToString(), "O".ToString());
                UpdateInfo.UpdateRoomNumber(connectDB, (index + 1).ToString(), "Выселен");
                studentsTableAdapter1.Fill(this.masterDataSetS.students);

                MessageBox.Show("Студент выселен", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(SurnameTextBox.Text))
                studentsBindingSource1.Filter = string.Empty;
            else if (string.IsNullOrEmpty(NameTextBox.Text))
                studentsBindingSource.Filter = string.Format("surname = '{0}'", SurnameTextBox.Text);
            else if (string.IsNullOrEmpty(SurnameTextBox.Text))
                studentsBindingSource1.Filter = string.Format("name = '{0}'", NameTextBox.Text);
            else
                studentsBindingSource1.Filter = string.Format("name ='{0}' and surname = '{1}'", NameTextBox.Text, SurnameTextBox.Text);
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
        }

        private void ResetFiltersBtn_Click(object sender, EventArgs e)
        {
            NameTextBox.Text = string.Empty;
            SurnameTextBox.Text = string.Empty;
        }
    }
}
