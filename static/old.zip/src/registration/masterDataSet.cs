﻿namespace registration
{


    public partial class masterDataSet
    {
    }
}
