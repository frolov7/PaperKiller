﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Bedsheet
    {
        public Boolean bedsheetChange = false;
        public string bedsheetID;
        public string serialNumber { get; set; }
        public string status { get; set; }
        public Bedsheet(string id, string serialNumber, string status)
        {
            bedsheetID = id;
            this.serialNumber = serialNumber;
            this.status = status;

        }

        public Bedsheet(object[] data)
        {
            bedsheetID = data[0].ToString();
            serialNumber = (string)data[1];
            if (data[2] != System.DBNull.Value)
                status = data[2].ToString();
            else
                status = "На складе";
        }
    }
}
