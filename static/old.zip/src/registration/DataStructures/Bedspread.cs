﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Bedspread
    {
        public Boolean bedspreadChange = false;
        public string bedspreadID;
        public string serialNumber { get; set; }
        public string status { get; set; }
        public Bedspread(string id, string serialNumber, string status)
        {
            bedspreadID = id;
            this.serialNumber = serialNumber;
            this.status = status;

        }

        public Bedspread(object[] data)
        {
            bedspreadID = data[0].ToString();
            serialNumber = (string)data[1];
            if (data[2] != System.DBNull.Value)
                status = data[2].ToString();
            else
                status = "На складе";
        }
    }
}
