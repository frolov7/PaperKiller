﻿using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Items
    {
        public string itemID;
        //public string serialNumber { get; set; }
        //public string status { get; set; }

        public int chairID { get; set; }
        public int tableID { get; set; }
        public int shelfID { get; set; }
        public int wardrobeID { get; set; }
        public int linenID { get; set; }

        public Items(string id, string serialNumber, string status, int chairID, int tableID, int shelfID, int wardrobeID, int linenID)
        {
            itemID = id;
           // this.serialNumber = serialNumber;
           // this.status = status;
            this.chairID = chairID;
            this.tableID = tableID;
            this.shelfID = shelfID;
            this.wardrobeID = wardrobeID;
            this.linenID = linenID;

        }

        public Items(object[] data)
        {
            itemID = data[0].ToString();
           // serialNumber = (string)data[1];
           // status = data[2].ToString();

            if (data[1] != System.DBNull.Value)
                chairID = (int)data[1];
            else
                chairID = 0;

            if (data[2] != System.DBNull.Value)
                tableID = (int)data[2];
            else
                tableID = 0;

            if (data[3] != System.DBNull.Value)
                shelfID = (int)data[3];
            else
                shelfID = 0;

            if (data[4] != System.DBNull.Value)
                wardrobeID = (int)data[4];
            else
                wardrobeID = 0;

            if (data[5] != System.DBNull.Value)
                linenID = (int)data[5];
            else
                linenID = 0;
        }
    }
}
