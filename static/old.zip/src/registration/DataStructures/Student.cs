﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Student
    {
        public string userID;
        public string login { get; set; }
        public string password { get; set; }
        public string userType { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
        public string phoneNumber { get; set; }
        public string checkInData { get; set; }
        public string gender { get; set; }
        public string studentID { get; set; }
        public string roomNumber { get; set; }
        public int linenID { get; set; }
        public int itemsID { get; set; }

        public Student(string id, string login, string password, string name, string surname, string phoneNumber, string checkInData, string gender, string studentID, string roomNumber, string userType, int linenID, int itemsID)
        {
            userID = id;
            this.login = login;
            this.password = password;
            this.userType = userType;
            this.name = name;
            this.surname = surname;
            this.phoneNumber = phoneNumber;
            this.checkInData = checkInData;
            this.gender = gender;
            this.studentID = studentID;
            this.roomNumber = roomNumber;
            this.linenID = linenID;
            this.itemsID = itemsID;
        }

        public Student(object[] data)
        {
            userID = data[0].ToString();
            login = (string)data[1];
            password = (string)data[2];
            userType = (string)data[3];
            name = (string)data[4];
            surname = (string)data[5];
            phoneNumber = (string)data[6];
            checkInData = (string)data[7];
            studentID = (string)data[8];
            gender = (string)data[9];
            if (data[10] != System.DBNull.Value)
                roomNumber = data[10].ToString();
            else
                roomNumber = "Не назначена";

            if (data[11] != System.DBNull.Value)
                linenID = (int)data[11];
            else
                linenID = 0;

            if (data[12] != System.DBNull.Value)
                itemsID = (int)data[12];
            else
                itemsID = 0; 
        }
    }
}
