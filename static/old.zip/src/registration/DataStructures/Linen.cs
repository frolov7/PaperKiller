﻿using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Linen
    {
        public string linenID;
        //public string serialNumber { get; set; }
        //public string status { get; set; }

        public int bedsheetID { get; set; }
        public int pillowcaseID { get; set; }
        public int duvetID { get; set; }
        public int bedspreadID { get; set; }
        public int towelID { get; set; }

        public Linen(string id, string serialNumber, string status, int bedsheetID, int pillowcaseID, int duvetID, int bedspreaID, int towelID)
        {
            linenID = id;
            //this.serialNumber = serialNumber;
           //this.status = status;
            this.bedsheetID = bedsheetID;
            this.pillowcaseID = pillowcaseID;
            this.duvetID = duvetID;
            this.bedspreadID = bedspreaID;
            this.towelID = towelID;

        }

        public Linen(object[] data)
        {
            linenID = data[0].ToString();
            //serialNumber = (string)data[1];
            //status = data[2].ToString();

            if (data[1] != System.DBNull.Value)
                bedsheetID = (int)data[1];
            else
                bedsheetID = 0;

            if (data[2] != System.DBNull.Value)
                pillowcaseID = (int)data[2];
            else
                pillowcaseID = 0;

            if (data[3] != System.DBNull.Value)
                duvetID = (int)data[3];
            else
                duvetID = 0;

            if (data[4] != System.DBNull.Value)
                bedspreadID = (int)data[4];
            else
                bedspreadID = 0;

            if (data[5] != System.DBNull.Value)
                towelID = (int)data[5];
            else
                towelID = 0;
        }
    }
}
