﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Duvet
    {
        public Boolean duvetChange = false;
        public string duvetID;
        public string serialNumber { get; set; }
        public string status { get; set; }
        public Duvet(string id, string serialNumber, string status)
        {
            duvetID = id;
            this.serialNumber = serialNumber;
            this.status = status;

        }

        public Duvet(object[] data)
        {
            duvetID = data[0].ToString();
            serialNumber = (string)data[1];
            if (data[2] != System.DBNull.Value)
                status = data[2].ToString();
            else
                status = "На складе";
        }
    }
}
