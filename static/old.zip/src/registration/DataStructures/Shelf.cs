﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Shelf
    {
        public Boolean shelfChange = false;
        public string shelfID;
        public string serialNumber { get; set; }
        public string status { get; set; }

        public Shelf(string id, string serialNumber, string status)
        {
            shelfID = id;
            this.serialNumber = serialNumber;
            this.status = status;
        }

        public Shelf(object[] data)
        {
            shelfID = data[0].ToString();
            serialNumber = data[1].ToString();
            if (data[2] != System.DBNull.Value)
                status = data[2].ToString();
            else
                status = "На складе";
        }
    }
}
