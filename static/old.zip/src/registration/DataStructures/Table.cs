﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataStructures
{
    public class Table
    {
        public Boolean tableChange = false;
        public string tableID;
        public string serialNumber { get; set; }
        public string status { get; set; }

        public Table(string id, string serialNumber, string status)
        {
            tableID = id;
            this.serialNumber = serialNumber;
            this.status = status;
        }

        public Table(object[] data)
        {
            tableID = data[0].ToString();
            serialNumber = data[1].ToString();
            if (data[2] != System.DBNull.Value)
                status = data[2].ToString();
            else
                status = "На складе";
        }
    }
}
