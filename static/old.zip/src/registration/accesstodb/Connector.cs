﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using DataStructures;
using registration;
using System.Windows.Forms;

namespace AccessToDB
{
    public class Connector
    {
        SqlConnection connection;

        public Connector(string connectionString = @"Data Source=LAPTOP-34F82EN1;Initial Catalog=master;Integrated Security=true")

        {
            connection = new SqlConnection(connectionString);
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();  

        }
        /// Выполняет запрос возвращающий список результатов
        public List<object[]> ExecuteSelect(string cmdTxt)
        {
            List<object[]> res = new List<object[]>();

            using (var comand = new SqlCommand(cmdTxt, connection))
            {
                var reader = comand.ExecuteReader();
                int nCol = reader.VisibleFieldCount; // количество столбцов

                while (reader.Read()) // получаем очередную строку результата
                {
                    object[] tmp = new object[nCol];
                    reader.GetValues(tmp); // считать в tmp значения строк
                    res.Add(tmp);
                }
                reader.Close();
            }
            return res;
        }
        /// Выполняет инструкцию
        public int ExecuteNonQuery(string cmdTxt)
        {
            int res = 0;
            using (var comand = new SqlCommand(cmdTxt, connection))
            {
                res = comand.ExecuteNonQuery();
            }
            return res;
        }

        public void closeConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }
    }
}
