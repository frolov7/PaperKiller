﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessToDB
{
    public static class CheckInfo
    {
        /// Проверяет занят ли такой login
        public static bool isLoginExists(Connector connection, string login)
        {
            var tmp = connection.ExecuteSelect(
                "select * from users " +
                "where login = '" + login + "'");

            return tmp.Count == 0 ? false : true;
        }
        /// Проверяет занят ли такой студак
        public static bool isStudentIDExists(Connector connection, string studak)
        {
            var tmp = connection.ExecuteSelect(
                "select * from users, students " +
                "where studak = '" + studak + "'");

            return tmp.Count == 0 ? false : true;
        }
        /// Проверяет есть ли такой пользователь с логином
        public static bool isUserExists(Connector connection, string studak)
        {
            var tmp = connection.ExecuteSelect(
                "select * from users " +
                "where login = '" + studak + "'");

            return tmp.Count == 0 ? false : true;
        }
    }
}
