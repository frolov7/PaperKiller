﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessToDB
{
    public static class DeleteInfo
    {
        public static int DeleteUserByID(Connector connection, string userID)
        {
            return connection.ExecuteNonQuery(
                "delete from users " +
                "where id = '" + userID + "'");
        }
    }
}
