﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataStructures;
using MySqlX.XDevAPI;
using static System.Windows.Forms.LinkLabel;

namespace AccessToDB
{
    public static class GetInfo
    {
        public static Student GetStudentByLogin(Connector connection, string login, string pass)
        {
            var tmp = connection.ExecuteSelect(
                "SELECT students.id, login, password, userType, name, surname, phoneNumber, checkInDate, studak, gender, roomNumber, linen_id, items_id " +
                "FROM students INNER JOIN users ON users.id = students.id " +
                "where login = '" + login + "' and password = '" + pass + "'");

            if (tmp.Count != 0)
                return new Student(tmp[0]);
            else
                return null;
        }

        public static Student GetStudentByRoom(Connector connection, string name, string surname, string room)
        {
            var tmp = connection.ExecuteSelect(
                "SELECT students.id, login, password, userType, name, surname, phoneNumber, checkInDate, studak, gender, roomNumber, linen_id, items_id " +
                "FROM students INNER JOIN users ON users.id = students.id " +
                "where name = '" + name + "' and surname = '" + surname + "' and roomNumber = '" + room + "'");

            if (tmp.Count != 0)
                return new Student(tmp[0]);
            else
                return null;
        }

        public static Linen GetLinenByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT linen.id, bedsheet_id, pillowcase_id, duvet_id, bedspread_id, towel_id " +
            "FROM students INNER JOIN linen ON linen.id = students.linen_id " +
            "where students.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Linen(tmp[0]);
            else
                return null;
        }

        public static Items GetItemsByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT items.id, chair_id, tables_id, shelf_id, wardrobe_id, items.linen_id " +
            "FROM students INNER JOIN items ON items.id = students.items_id " +
            "where students.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Items(tmp[0]);
            else
                return null;
        }

        public static Chair GetChairByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT chair.id, chair.serialNumber, chair.isGiven " +
            "FROM items INNER JOIN chair ON chair.id = items.chair_id " +
            "where items.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Chair(tmp[0]);
            else
                return null;
        }

        public static Table GetTableByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT tables.id, tables.serialNumber, tables.isGiven " +
            "FROM items INNER JOIN tables ON tables.id = items.tables_id " +
            "where items.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Table(tmp[0]);
            else
                return null;
        }

        public static Wardrobe GetWardrobeByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT wardrobe.id, wardrobe.serialNumber, wardrobe.isGiven " +
            "FROM items INNER JOIN wardrobe ON wardrobe.id = items.wardrobe_id " +
            "where items.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Wardrobe(tmp[0]);
            else
                return null;
        }

        public static Shelf GetShelfByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT shelf.id, shelf.serialNumber, shelf.isGiven " +
            "FROM items INNER JOIN shelf ON shelf.id = items.shelf_id " +
            "where items.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Shelf(tmp[0]);
            else
                return null;
        }

        public static Bedsheet GetBedsheetByID(Connector connection, string linenID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT bedsheet.id, bedsheet.serialNumber, bedsheet.isGiven " +
            "FROM bedsheet INNER JOIN linen ON bedsheet.id = linen.bedsheet_id " +
            "where linen.id = '" + linenID + "'");

            if (tmp.Count != 0)
                return new Bedsheet(tmp[0]);
            else
                return null;
        }

        public static Pillowcase GetPillowcaseByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT pillowcase.id, pillowcase.serialNumber, pillowcase.isGiven " +
            "FROM pillowcase INNER JOIN linen ON pillowcase.id = linen.pillowcase_id " +
            "where linen.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Pillowcase(tmp[0]);
            else
                return null;
        }

        public static Duvet GetDuvetByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT duvet.id, duvet.serialNumber, duvet.isGiven " +
            "FROM duvet INNER JOIN linen ON duvet.id = linen.duvet_id " +
            "where linen.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Duvet(tmp[0]);
            else
                return null;
        }

        public static Bedspread GetBedspreadByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT bedspread.id, bedspread.serialNumber, bedspread.isGiven " +
            "FROM bedspread INNER JOIN linen ON bedspread.id = linen.bedspread_id " +
            "where linen.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Bedspread(tmp[0]);
            else
                return null;
        }

        public static Towel GetTowelByID(Connector connection, string userID)
        {
            var tmp = connection.ExecuteSelect(
            "SELECT towel.id, towel.serialNumber, towel.isGiven " +
            "FROM towel INNER JOIN linen ON towel.id = linen.towel_id " +
            "where linen.id = '" + userID + "'");

            if (tmp.Count != 0)
                return new Towel(tmp[0]);
            else
                return null;
        }
        /// Поиск индекса предмета который на складе
        public static int GetFreeItem(Connector connection, string nameID, string tableName)
        {
            List<int> indexes = new List<int>();

            string sqlExpression = "select " + nameID + " from " + tableName + " where isGiven = 'На складе'";
            using (SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-34F82EN1;Initial Catalog=master;Integrated Security=true"))
            {
                con.Open();
                SqlCommand command = new SqlCommand(sqlExpression, con);
                SqlDataReader reader = command.ExecuteReader();

                int i = 0;
                while (reader.Read()) // построчно считываем данные
                {
                    indexes.Add((int)reader.GetValue(0));
                    i++;
                }
                reader.Close();
            }

            return indexes[new Random().Next(indexes.Count)];
        }
    }
}
