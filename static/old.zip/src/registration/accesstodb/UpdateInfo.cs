﻿using DataStructures;
using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AccessToDB
{
    public static class UpdateInfo
    {
        /// Восстановить пароль
        public static int UpdatePassword(Connector connection, string login, string newPassword)
        {
            return connection.ExecuteNonQuery(
                "update users " +
                "set password ='" + newPassword + "' " +
                "where login = '" + login + "'");
        }
        /// Изменить данные пользователя
        public static int UpdateUsersData(Connector connection, string oldLogin, string newLogin, string newPassword)
        {
            return connection.ExecuteNonQuery(
                "update users " +
                "set login ='" + newLogin + "', " +
                "password = '" + newPassword + "' " +
                "where login = '" + oldLogin + "'");
        }


        /// Изменить данные студента процедура
        public static int ProcUpdateData(Connector connection)
        {
            return connection.ExecuteNonQuery(
                "create proc update_user_data " +
                    "@name varchar(10) = 'name', " +
                    "@surname varchar(10) = 'surname', " +
                    "@phoneNumber varchar(10) = 'phoneNumber', " +
                    "@login varchar(10) = 'login' " +
                "as " +
                    "update students " +

                    "set name = @name, " +
                    "surname = @surname, " +
                    "phoneNumber = @phoneNumber " +
                    "where id = (select id from users where login = @login)");
        }

        /// Вызов процедуры
        public static int ExecProc(Connector connection, string newName, string newSurname, string newPhone, string login)
        {
            return connection.ExecuteNonQuery(
                "exec update_user_data '" + newName + "' , '" + newSurname + "' , '" + newPhone + "' , '" + login + "' ");
        }

        /// Удаление процедуры
        public static int DropProc(Connector connection)
        {
            return connection.ExecuteNonQuery(
                "drop procedure IF EXISTS update_user_data ");
        }

        /// Изменить данные студента (Не используется)
        public static int UpdateStudentsData(Connector connection, string newName, string newSurname, string newPhone, string login)
        {
            return connection.ExecuteNonQuery(
                "update students " +
                "set name ='" + newName + "', " +
                "surname ='" + newSurname + "', " +
                "phoneNumber = '" + newPhone + "'" +
                "where id = (select id from users where login = '" + login + "')");
        }
        /// Изменить статус студента
        public static int UpdateUserType(Connector connection, string userID, string newType)
        {
            return connection.ExecuteNonQuery(
                "update users " +
                "set userType ='" + newType + "' " +
                "where id = '" + userID + "'");
        }
        /// Изменить номер комнаты
        public static int UpdateRoomNumber(Connector connection, string userID, string newRoom)
        {
            return connection.ExecuteNonQuery(
                "update students " +
                "set roomNumber ='" + newRoom + "' " +
                "where id = '" + userID + "'");
        }
        /// Сдать студенту вещь
        public static int ReturnItemBack(Connector connection, string item, string userID)
        {
            return connection.ExecuteNonQuery(
                "update items " +
                "set " + item + " = NULL " +
                "where id = '" + userID + "'");
        }
        /// Сдать студенту белье
        public static int ReturnLinenBack(Connector connection, string item, string linenID)
        {
            return connection.ExecuteNonQuery(
                "update linen " +
                "set " + item + " = NULL " +
                "where id = '" + linenID + "'");
        }
        /// Выдать новый предмет студенту
        public static int NewSerialNumber(Connector connection, string item_id, string newItemID, string userID)
        {
            return connection.ExecuteNonQuery(
                "update items " +
                "set " + item_id + " ='" + newItemID + "' " +
                "where id = '" + userID + "'");
        }
        /// Выдать новый комплект белья
        public static int NewLinen(Connector connection, string item_id, string newItemID, string linenID)
        {
            return connection.ExecuteNonQuery(
                "update linen " +
                "set " + item_id + " ='" + newItemID + "' " +
                "where id = '" + linenID + "'");
        }
        /// Сменить статус вещи на складе
        public static int ChangeItemStatus(Connector connection, string tableName, string itemStatus, string itemID)
        {
            return connection.ExecuteNonQuery(
                "update " + tableName + " " +
                "set isGiven = '" + itemStatus + "' " +
                "where id = '" + itemID + "'");
        }
        /// Увеличить id linen и item
        public static int UpLinenID(Connector connection)
        {
            return connection.ExecuteNonQuery(
                "update students " +
                "set linen_id = " +
                "(select count(linen_id) from students) + 1 " +
                "where id = (select count(id) from students)");
        }
        /// Увеличить id linen и item
        public static int UpItemID(Connector connection)
        {
            return connection.ExecuteNonQuery(
                "update students " +
                "set items_id = " +
                "(select count(items_id) from students) + 1 " +
                "where id = (select count(id) from students)");
        }
    }
}
