﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AccessToDB
{
    public static class InsertInfo
    {
        /// Вставка данных для доступа к аккаунту Студента
        public static int InsertUser(Connector connection, string login, string password)
        {
            return connection.ExecuteNonQuery(
                "insert into users " +
                "(login, password, userType) " +
                "values ('" + login + "', '" + password + "', 'S')");
        }
        /// Вставка данных Студента
        public static int InsertUserData(Connector connection, string name, string surname, string phoneNumber, string studak, string gender)
        {
            return connection.ExecuteNonQuery(
                "insert into students " +
                "(name, surname, phoneNumber, checkInDate, studak, gender) " +
                "values('" + name + "', '" + surname + "', '" + phoneNumber + "', GETDATE(), '" + studak + "', '" + gender + "')");
        }
        /// Вставка данных предметов 
        public static int InsertItemStorage(Connector connection, string tableName, string sNumber)
        {
            return connection.ExecuteNonQuery(
                "insert into " + tableName + " " +
                "(serialNumber, isGiven) " +
                "values('" + sNumber + "', 'На складе')");
        }
        /// Вставка данных обмен белья 
        public static int InsertLinenReport(Connector connection, string name, string surname, string room, string item)
        {
            return connection.ExecuteNonQuery(
                "insert report " +
                "(name, surname, DateChange, roomNumber, itemType) " +
                "values('" + name + "', '" + surname + "', GETDATE(), '" + room + "', '" + item + "')");
        }
    }
}
