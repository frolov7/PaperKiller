﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace registration
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "masterDataSetReport.report". При необходимости она может быть перемещена или удалена.
            this.reportTableAdapter.Fill(this.masterDataSetReport.report);

        }

        private void closeLabel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(RoomTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Empty;
            else if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(RoomTextBox.Text))
                reportBindingSource.Filter = string.Format("itemType = '{0}'", ItemTextBox.Text);
            else if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Format("roomNumber = '{0}'", RoomTextBox.Text);
            else if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text) & string.IsNullOrEmpty(RoomTextBox.Text))
                reportBindingSource.Filter = string.Format("surname = '{0}'", SurnameTextBox.Text);
            else if (string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Format("name = '{0}'", NameTextBox.Text);

            else if (string.IsNullOrEmpty(RoomTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Format("name ='{0}' and surname = '{1}'", NameTextBox.Text, SurnameTextBox.Text);
            else if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Format("surname ='{0}' and roomNumber = '{1}'", SurnameTextBox.Text, RoomTextBox.Text);
            else if (string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Format("name ='{0}' and roomNumber = '{1}'", NameTextBox.Text, RoomTextBox.Text);
            else if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(RoomTextBox.Text))
                reportBindingSource.Filter = string.Format("surname ='{0}' and itemType = '{1}'", SurnameTextBox.Text, ItemTextBox.Text);
            else if (string.IsNullOrEmpty(SurnameTextBox.Text) & string.IsNullOrEmpty(RoomTextBox.Text))
                reportBindingSource.Filter = string.Format("name ='{0}' and itemType = '{1}'", NameTextBox.Text, ItemTextBox.Text);
            else if (string.IsNullOrEmpty(NameTextBox.Text) & string.IsNullOrEmpty(SurnameTextBox.Text))
                reportBindingSource.Filter = string.Format("roomNumber ='{0}' and itemType = '{1}'", RoomTextBox.Text, ItemTextBox.Text);

            else if (string.IsNullOrEmpty(NameTextBox.Text))
                reportBindingSource.Filter = string.Format("surname ='{0}' and roomNumber = '{1}' and itemType = '{3}'", SurnameTextBox.Text, RoomTextBox.Text, ItemTextBox.Text);
            else if (string.IsNullOrEmpty(SurnameTextBox.Text))
                reportBindingSource.Filter = string.Format("name ='{0}' and roomNumber = '{1}' and itemType = '{3}'", NameTextBox.Text, RoomTextBox.Text, ItemTextBox.Text);
            else if (string.IsNullOrEmpty(RoomTextBox.Text))
                reportBindingSource.Filter = string.Format("name ='{0}' and surname = '{1}' and itemType = '{3}'", NameTextBox.Text, SurnameTextBox.Text, ItemTextBox.Text);
            else if (string.IsNullOrEmpty(ItemTextBox.Text))
                reportBindingSource.Filter = string.Format("name ='{0}' and surname = '{1}' and roomNumber = '{3}'", NameTextBox.Text, SurnameTextBox.Text, RoomTextBox.Text);
            else
                reportBindingSource.Filter = string.Format("name ='{0}' and surname = '{1}' and roomNumber ='{2}' and itemType = '{3}'", NameTextBox.Text, SurnameTextBox.Text, RoomTextBox.Text, ItemTextBox.Text);
        }

        private void ResetFiltersBtn_Click(object sender, EventArgs e)
        {
            NameTextBox.Text = string.Empty;
            SurnameTextBox.Text = string.Empty;
            RoomTextBox.Text = string.Empty;
            ItemTextBox.Text = string.Empty;
        }
    }
}
