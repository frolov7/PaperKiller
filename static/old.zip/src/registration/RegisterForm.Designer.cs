﻿namespace registration
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.goBackBtn = new System.Windows.Forms.Button();
            this.registerBtn = new System.Windows.Forms.Button();
            this.panelPhone = new System.Windows.Forms.Panel();
            this.phoneField = new System.Windows.Forms.TextBox();
            this.panelLogin = new System.Windows.Forms.Panel();
            this.loginField = new System.Windows.Forms.TextBox();
            this.panelName = new System.Windows.Forms.Panel();
            this.nameField = new System.Windows.Forms.TextBox();
            this.logoLabel = new System.Windows.Forms.Label();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.panelEmail = new System.Windows.Forms.Panel();
            this.passwordField = new System.Windows.Forms.TextBox();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.studentIDField = new System.Windows.Forms.TextBox();
            this.panelSurname = new System.Windows.Forms.Panel();
            this.surnameField = new System.Windows.Forms.TextBox();
            this.panelPasswordRepeat = new System.Windows.Forms.Panel();
            this.passwordRepeatField = new System.Windows.Forms.TextBox();
            this.closeBtn = new System.Windows.Forms.Label();
            this.sexLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkPassImg = new System.Windows.Forms.PictureBox();
            this.maleBtn = new System.Windows.Forms.PictureBox();
            this.passwordRepeatImg = new System.Windows.Forms.PictureBox();
            this.femaleBtn = new System.Windows.Forms.PictureBox();
            this.passwordImg = new System.Windows.Forms.PictureBox();
            this.studentIDImg = new System.Windows.Forms.PictureBox();
            this.surnameImg = new System.Windows.Forms.PictureBox();
            this.phoneImg = new System.Windows.Forms.PictureBox();
            this.loginImg = new System.Windows.Forms.PictureBox();
            this.nameImg = new System.Windows.Forms.PictureBox();
            this.mainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkPassImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maleBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordRepeatImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.femaleBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentIDImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.surnameImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameImg)).BeginInit();
            this.SuspendLayout();
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(22, 591);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 40);
            this.goBackBtn.TabIndex = 27;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // registerBtn
            // 
            this.registerBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.registerBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.registerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registerBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.registerBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registerBtn.Location = new System.Drawing.Point(598, 591);
            this.registerBtn.Name = "registerBtn";
            this.registerBtn.Size = new System.Drawing.Size(250, 40);
            this.registerBtn.TabIndex = 26;
            this.registerBtn.Text = "Зарегистрироваться";
            this.registerBtn.UseVisualStyleBackColor = false;
            this.registerBtn.Click += new System.EventHandler(this.registerBtn_Click);
            // 
            // panelPhone
            // 
            this.panelPhone.BackColor = System.Drawing.Color.White;
            this.panelPhone.Location = new System.Drawing.Point(106, 418);
            this.panelPhone.Name = "panelPhone";
            this.panelPhone.Size = new System.Drawing.Size(250, 1);
            this.panelPhone.TabIndex = 25;
            // 
            // phoneField
            // 
            this.phoneField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.phoneField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phoneField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.phoneField.ForeColor = System.Drawing.Color.White;
            this.phoneField.HideSelection = false;
            this.phoneField.Location = new System.Drawing.Point(154, 390);
            this.phoneField.Name = "phoneField";
            this.phoneField.Size = new System.Drawing.Size(200, 22);
            this.phoneField.TabIndex = 24;
            this.phoneField.TabStop = false;
            this.phoneField.Click += new System.EventHandler(this.phoneField_Click);
            this.phoneField.Enter += new System.EventHandler(this.phoneField_Enter);
            this.phoneField.Leave += new System.EventHandler(this.phoneField_Leave);
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.White;
            this.panelLogin.Location = new System.Drawing.Point(106, 348);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(250, 1);
            this.panelLogin.TabIndex = 22;
            // 
            // loginField
            // 
            this.loginField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.loginField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.loginField.ForeColor = System.Drawing.Color.White;
            this.loginField.HideSelection = false;
            this.loginField.Location = new System.Drawing.Point(154, 320);
            this.loginField.Name = "loginField";
            this.loginField.Size = new System.Drawing.Size(200, 22);
            this.loginField.TabIndex = 21;
            this.loginField.TabStop = false;
            this.loginField.Click += new System.EventHandler(this.loginField_Click);
            this.loginField.Enter += new System.EventHandler(this.loginField_Enter);
            this.loginField.Leave += new System.EventHandler(this.loginField_Leave);
            // 
            // panelName
            // 
            this.panelName.BackColor = System.Drawing.Color.White;
            this.panelName.Location = new System.Drawing.Point(106, 278);
            this.panelName.Name = "panelName";
            this.panelName.Size = new System.Drawing.Size(250, 1);
            this.panelName.TabIndex = 19;
            // 
            // nameField
            // 
            this.nameField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nameField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nameField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.nameField.ForeColor = System.Drawing.Color.White;
            this.nameField.HideSelection = false;
            this.nameField.Location = new System.Drawing.Point(154, 250);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(200, 22);
            this.nameField.TabIndex = 18;
            this.nameField.TabStop = false;
            this.nameField.Click += new System.EventHandler(this.nameField_Click);
            this.nameField.Enter += new System.EventHandler(this.nameField_Enter);
            this.nameField.Leave += new System.EventHandler(this.nameField_Leave);
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(29, 46);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 16;
            this.logoLabel.Text = "PaperKiller";
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(14, 23);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(260, 43);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Регистрация";
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(412, 39);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(450, 84);
            this.mainPanel.TabIndex = 31;
            // 
            // panelEmail
            // 
            this.panelEmail.BackColor = System.Drawing.Color.White;
            this.panelEmail.Location = new System.Drawing.Point(496, 348);
            this.panelEmail.Name = "panelEmail";
            this.panelEmail.Size = new System.Drawing.Size(250, 1);
            this.panelEmail.TabIndex = 34;
            // 
            // passwordField
            // 
            this.passwordField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.passwordField.ForeColor = System.Drawing.Color.White;
            this.passwordField.HideSelection = false;
            this.passwordField.Location = new System.Drawing.Point(544, 390);
            this.passwordField.Name = "passwordField";
            this.passwordField.Size = new System.Drawing.Size(200, 22);
            this.passwordField.TabIndex = 33;
            this.passwordField.TabStop = false;
            this.passwordField.Click += new System.EventHandler(this.passwordField_Click);
            this.passwordField.Enter += new System.EventHandler(this.passwordField_Enter);
            this.passwordField.Leave += new System.EventHandler(this.passwordField_Leave);
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(496, 418);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(250, 1);
            this.panelPassword.TabIndex = 31;
            // 
            // studentIDField
            // 
            this.studentIDField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.studentIDField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.studentIDField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.studentIDField.ForeColor = System.Drawing.Color.White;
            this.studentIDField.HideSelection = false;
            this.studentIDField.Location = new System.Drawing.Point(544, 320);
            this.studentIDField.Name = "studentIDField";
            this.studentIDField.Size = new System.Drawing.Size(200, 22);
            this.studentIDField.TabIndex = 30;
            this.studentIDField.TabStop = false;
            this.studentIDField.Click += new System.EventHandler(this.emailField_Click);
            this.studentIDField.Enter += new System.EventHandler(this.emailField_Enter);
            this.studentIDField.Leave += new System.EventHandler(this.emailField_Leave);
            // 
            // panelSurname
            // 
            this.panelSurname.BackColor = System.Drawing.Color.White;
            this.panelSurname.Location = new System.Drawing.Point(496, 278);
            this.panelSurname.Name = "panelSurname";
            this.panelSurname.Size = new System.Drawing.Size(250, 1);
            this.panelSurname.TabIndex = 28;
            // 
            // surnameField
            // 
            this.surnameField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.surnameField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.surnameField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.surnameField.ForeColor = System.Drawing.Color.White;
            this.surnameField.HideSelection = false;
            this.surnameField.Location = new System.Drawing.Point(544, 250);
            this.surnameField.Name = "surnameField";
            this.surnameField.Size = new System.Drawing.Size(200, 22);
            this.surnameField.TabIndex = 27;
            this.surnameField.TabStop = false;
            this.surnameField.Click += new System.EventHandler(this.surnameField_Click);
            this.surnameField.Enter += new System.EventHandler(this.surnameField_Enter);
            this.surnameField.Leave += new System.EventHandler(this.surnameField_Leave);
            // 
            // panelPasswordRepeat
            // 
            this.panelPasswordRepeat.BackColor = System.Drawing.Color.White;
            this.panelPasswordRepeat.Location = new System.Drawing.Point(496, 489);
            this.panelPasswordRepeat.Name = "panelPasswordRepeat";
            this.panelPasswordRepeat.Size = new System.Drawing.Size(250, 1);
            this.panelPasswordRepeat.TabIndex = 37;
            // 
            // passwordRepeatField
            // 
            this.passwordRepeatField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordRepeatField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordRepeatField.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passwordRepeatField.ForeColor = System.Drawing.Color.White;
            this.passwordRepeatField.HideSelection = false;
            this.passwordRepeatField.Location = new System.Drawing.Point(544, 460);
            this.passwordRepeatField.Name = "passwordRepeatField";
            this.passwordRepeatField.Size = new System.Drawing.Size(200, 22);
            this.passwordRepeatField.TabIndex = 36;
            this.passwordRepeatField.TabStop = false;
            this.passwordRepeatField.Click += new System.EventHandler(this.passwordRepeatField_Click);
            this.passwordRepeatField.Enter += new System.EventHandler(this.passwordRepeatField_Enter);
            this.passwordRepeatField.Leave += new System.EventHandler(this.passwordRepeatField_Leave);
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(833, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 39;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // sexLabel
            // 
            this.sexLabel.AutoSize = true;
            this.sexLabel.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sexLabel.ForeColor = System.Drawing.Color.FloralWhite;
            this.sexLabel.Location = new System.Drawing.Point(380, 211);
            this.sexLabel.Name = "sexLabel";
            this.sexLabel.Size = new System.Drawing.Size(78, 16);
            this.sexLabel.TabIndex = 42;
            this.sexLabel.Text = "Выберите пол";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FloralWhite;
            this.label1.Location = new System.Drawing.Point(163, 422);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 16);
            this.label1.TabIndex = 44;
            this.label1.Text = "Формат \"+71234567890\"";
            // 
            // checkPassImg
            // 
            this.checkPassImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.checkPassImg.Location = new System.Drawing.Point(759, 464);
            this.checkPassImg.Name = "checkPassImg";
            this.checkPassImg.Size = new System.Drawing.Size(18, 18);
            this.checkPassImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.checkPassImg.TabIndex = 43;
            this.checkPassImg.TabStop = false;
            // 
            // maleBtn
            // 
            this.maleBtn.BackgroundImage = global::registration.Properties.Resources.man_icon2;
            this.maleBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.maleBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.maleBtn.Image = global::registration.Properties.Resources.man_icon;
            this.maleBtn.Location = new System.Drawing.Point(352, 156);
            this.maleBtn.Name = "maleBtn";
            this.maleBtn.Size = new System.Drawing.Size(52, 52);
            this.maleBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.maleBtn.TabIndex = 37;
            this.maleBtn.TabStop = false;
            this.maleBtn.Click += new System.EventHandler(this.maleBtn_Click);
            // 
            // passwordRepeatImg
            // 
            this.passwordRepeatImg.Image = global::registration.Properties.Resources.secure_icon2;
            this.passwordRepeatImg.Location = new System.Drawing.Point(506, 450);
            this.passwordRepeatImg.Name = "passwordRepeatImg";
            this.passwordRepeatImg.Size = new System.Drawing.Size(32, 32);
            this.passwordRepeatImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordRepeatImg.TabIndex = 35;
            this.passwordRepeatImg.TabStop = false;
            // 
            // femaleBtn
            // 
            this.femaleBtn.BackgroundImage = global::registration.Properties.Resources.girl_icon2;
            this.femaleBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.femaleBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.femaleBtn.Image = global::registration.Properties.Resources.girl_icon;
            this.femaleBtn.Location = new System.Drawing.Point(431, 156);
            this.femaleBtn.Name = "femaleBtn";
            this.femaleBtn.Size = new System.Drawing.Size(52, 52);
            this.femaleBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.femaleBtn.TabIndex = 36;
            this.femaleBtn.TabStop = false;
            this.femaleBtn.Click += new System.EventHandler(this.femaleBtn_Click);
            // 
            // passwordImg
            // 
            this.passwordImg.Image = global::registration.Properties.Resources.secure_icon;
            this.passwordImg.Location = new System.Drawing.Point(506, 380);
            this.passwordImg.Name = "passwordImg";
            this.passwordImg.Size = new System.Drawing.Size(32, 32);
            this.passwordImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordImg.TabIndex = 32;
            this.passwordImg.TabStop = false;
            // 
            // studentIDImg
            // 
            this.studentIDImg.Image = global::registration.Properties.Resources.learning;
            this.studentIDImg.Location = new System.Drawing.Point(506, 310);
            this.studentIDImg.Name = "studentIDImg";
            this.studentIDImg.Size = new System.Drawing.Size(32, 32);
            this.studentIDImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.studentIDImg.TabIndex = 29;
            this.studentIDImg.TabStop = false;
            // 
            // surnameImg
            // 
            this.surnameImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.surnameImg.Image = global::registration.Properties.Resources.user_icon2;
            this.surnameImg.Location = new System.Drawing.Point(506, 240);
            this.surnameImg.Name = "surnameImg";
            this.surnameImg.Size = new System.Drawing.Size(32, 32);
            this.surnameImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.surnameImg.TabIndex = 26;
            this.surnameImg.TabStop = false;
            // 
            // phoneImg
            // 
            this.phoneImg.Image = global::registration.Properties.Resources.phone_icon;
            this.phoneImg.Location = new System.Drawing.Point(116, 380);
            this.phoneImg.Name = "phoneImg";
            this.phoneImg.Size = new System.Drawing.Size(32, 32);
            this.phoneImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.phoneImg.TabIndex = 23;
            this.phoneImg.TabStop = false;
            // 
            // loginImg
            // 
            this.loginImg.BackgroundImage = global::registration.Properties.Resources.login_icon2;
            this.loginImg.Image = global::registration.Properties.Resources.login_icon;
            this.loginImg.Location = new System.Drawing.Point(116, 310);
            this.loginImg.Name = "loginImg";
            this.loginImg.Size = new System.Drawing.Size(32, 32);
            this.loginImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginImg.TabIndex = 20;
            this.loginImg.TabStop = false;
            // 
            // nameImg
            // 
            this.nameImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female;
            this.nameImg.Image = global::registration.Properties.Resources.user_icon;
            this.nameImg.Location = new System.Drawing.Point(116, 240);
            this.nameImg.Name = "nameImg";
            this.nameImg.Size = new System.Drawing.Size(32, 32);
            this.nameImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nameImg.TabIndex = 17;
            this.nameImg.TabStop = false;
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(860, 643);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkPassImg);
            this.Controls.Add(this.sexLabel);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.panelPasswordRepeat);
            this.Controls.Add(this.passwordRepeatField);
            this.Controls.Add(this.maleBtn);
            this.Controls.Add(this.passwordRepeatImg);
            this.Controls.Add(this.femaleBtn);
            this.Controls.Add(this.panelEmail);
            this.Controls.Add(this.passwordField);
            this.Controls.Add(this.panelPassword);
            this.Controls.Add(this.passwordImg);
            this.Controls.Add(this.studentIDField);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.panelSurname);
            this.Controls.Add(this.studentIDImg);
            this.Controls.Add(this.registerBtn);
            this.Controls.Add(this.surnameField);
            this.Controls.Add(this.panelPhone);
            this.Controls.Add(this.surnameImg);
            this.Controls.Add(this.phoneField);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.phoneImg);
            this.Controls.Add(this.loginField);
            this.Controls.Add(this.panelName);
            this.Controls.Add(this.loginImg);
            this.Controls.Add(this.nameField);
            this.Controls.Add(this.nameImg);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegisterForm";
            this.Click += new System.EventHandler(this.RegisterForm_Click);
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkPassImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maleBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordRepeatImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.femaleBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentIDImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.surnameImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Button registerBtn;
        private System.Windows.Forms.Panel panelPhone;
        private System.Windows.Forms.TextBox phoneField;
        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.PictureBox phoneImg;
        private System.Windows.Forms.TextBox loginField;
        private System.Windows.Forms.Panel panelName;
        private System.Windows.Forms.PictureBox loginImg;
        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.PictureBox nameImg;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel panelEmail;
        private System.Windows.Forms.TextBox passwordField;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.PictureBox passwordImg;
        private System.Windows.Forms.TextBox studentIDField;
        private System.Windows.Forms.Panel panelSurname;
        private System.Windows.Forms.PictureBox studentIDImg;
        private System.Windows.Forms.TextBox surnameField;
        private System.Windows.Forms.PictureBox surnameImg;
        private System.Windows.Forms.PictureBox femaleBtn;
        private System.Windows.Forms.PictureBox maleBtn;
        private System.Windows.Forms.Panel panelPasswordRepeat;
        private System.Windows.Forms.TextBox passwordRepeatField;
        private System.Windows.Forms.PictureBox passwordRepeatImg;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Label sexLabel;
        private System.Windows.Forms.PictureBox checkPassImg;
        private System.Windows.Forms.Label label1;
    }
}