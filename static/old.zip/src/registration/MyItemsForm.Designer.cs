﻿namespace registration
{
    partial class MyItemsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registrationLabel = new System.Windows.Forms.Label();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.logoLabel = new System.Windows.Forms.Label();
            this.ShowLinenBtn = new System.Windows.Forms.Button();
            this.ShowItemBtn = new System.Windows.Forms.Button();
            this.ShelfSNlabel = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.shelfLabel = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.ChairTmpLabel = new System.Windows.Forms.Label();
            this.ShelfTmpLabel = new System.Windows.Forms.Label();
            this.WardrobeTmpLabel = new System.Windows.Forms.Label();
            this.TableTmpLabel = new System.Windows.Forms.Label();
            this.ChairSNlabel = new System.Windows.Forms.Label();
            this.tableLabel = new System.Windows.Forms.Label();
            this.TableSNLabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.WardrobeSNlabel = new System.Windows.Forms.Label();
            this.wardrobeLabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.chairLabel = new System.Windows.Forms.Label();
            this.LinenBox = new System.Windows.Forms.Panel();
            this.Label1 = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.bedspreadSNlabel = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.pillowcaseTmpLabel = new System.Windows.Forms.Label();
            this.duvetTmpLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.duvetSNlabel = new System.Windows.Forms.Label();
            this.towelSNlabel = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.bedsheetTmpLabel = new System.Windows.Forms.Label();
            this.bedspreadTmpLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pillowcaseSNLabel = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.towelTmpLabel = new System.Windows.Forms.Label();
            this.bedsheetSNlabel = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ItemBox = new System.Windows.Forms.Panel();
            this.mainPanel.SuspendLayout();
            this.LinenBox.SuspendLayout();
            this.ItemBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(97, 10);
            this.registrationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(368, 74);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Мои вещи";
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(485, 641);
            this.goBackBtn.Margin = new System.Windows.Forms.Padding(4);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(333, 49);
            this.goBackBtn.TabIndex = 151;
            this.goBackBtn.Text = "Вернуться в главное меню";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(1272, 3);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 150;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(578, 72);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(4);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(725, 103);
            this.mainPanel.TabIndex = 149;
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(46, 80);
            this.logoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(354, 60);
            this.logoLabel.TabIndex = 148;
            this.logoLabel.Text = "PaperKiller";
            // 
            // ShowLinenBtn
            // 
            this.ShowLinenBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowLinenBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowLinenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowLinenBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowLinenBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowLinenBtn.Location = new System.Drawing.Point(782, 580);
            this.ShowLinenBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ShowLinenBtn.Name = "ShowLinenBtn";
            this.ShowLinenBtn.Size = new System.Drawing.Size(300, 43);
            this.ShowLinenBtn.TabIndex = 180;
            this.ShowLinenBtn.Text = "Постель";
            this.ShowLinenBtn.UseVisualStyleBackColor = false;
            this.ShowLinenBtn.Click += new System.EventHandler(this.ShowLinenBtn_Click);
            // 
            // ShowItemBtn
            // 
            this.ShowItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ShowItemBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ShowItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShowItemBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.ShowItemBtn.Location = new System.Drawing.Point(206, 580);
            this.ShowItemBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ShowItemBtn.Name = "ShowItemBtn";
            this.ShowItemBtn.Size = new System.Drawing.Size(300, 43);
            this.ShowItemBtn.TabIndex = 183;
            this.ShowItemBtn.Text = "Вещи";
            this.ShowItemBtn.UseVisualStyleBackColor = false;
            this.ShowItemBtn.Click += new System.EventHandler(this.ShowItemBtn_Click_1);
            // 
            // ShelfSNlabel
            // 
            this.ShelfSNlabel.AutoSize = true;
            this.ShelfSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfSNlabel.Location = new System.Drawing.Point(324, 191);
            this.ShelfSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ShelfSNlabel.Name = "ShelfSNlabel";
            this.ShelfSNlabel.Size = new System.Drawing.Size(176, 36);
            this.ShelfSNlabel.TabIndex = 173;
            this.ShelfSNlabel.Text = "serialNumber";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(324, 11);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(164, 26);
            this.label20.TabIndex = 177;
            this.label20.Text = "Серийный номер";
            // 
            // shelfLabel
            // 
            this.shelfLabel.AutoSize = true;
            this.shelfLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.shelfLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.shelfLabel.Location = new System.Drawing.Point(31, 191);
            this.shelfLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.shelfLabel.Name = "shelfLabel";
            this.shelfLabel.Size = new System.Drawing.Size(93, 36);
            this.shelfLabel.TabIndex = 154;
            this.shelfLabel.Text = "Полка";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(631, 11);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(156, 26);
            this.label14.TabIndex = 178;
            this.label14.Text = "Статус предмета";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(34, 51);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(850, 1);
            this.panel6.TabIndex = 170;
            // 
            // ChairTmpLabel
            // 
            this.ChairTmpLabel.AutoSize = true;
            this.ChairTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairTmpLabel.Location = new System.Drawing.Point(656, 56);
            this.ChairTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ChairTmpLabel.Name = "ChairTmpLabel";
            this.ChairTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.ChairTmpLabel.TabIndex = 161;
            this.ChairTmpLabel.Text = "status";
            // 
            // ShelfTmpLabel
            // 
            this.ShelfTmpLabel.AutoSize = true;
            this.ShelfTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShelfTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ShelfTmpLabel.Location = new System.Drawing.Point(656, 191);
            this.ShelfTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ShelfTmpLabel.Name = "ShelfTmpLabel";
            this.ShelfTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.ShelfTmpLabel.TabIndex = 159;
            this.ShelfTmpLabel.Text = "status";
            // 
            // WardrobeTmpLabel
            // 
            this.WardrobeTmpLabel.AutoSize = true;
            this.WardrobeTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeTmpLabel.Location = new System.Drawing.Point(656, 259);
            this.WardrobeTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WardrobeTmpLabel.Name = "WardrobeTmpLabel";
            this.WardrobeTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.WardrobeTmpLabel.TabIndex = 158;
            this.WardrobeTmpLabel.Text = "status";
            // 
            // TableTmpLabel
            // 
            this.TableTmpLabel.AutoSize = true;
            this.TableTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableTmpLabel.Location = new System.Drawing.Point(656, 123);
            this.TableTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TableTmpLabel.Name = "TableTmpLabel";
            this.TableTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.TableTmpLabel.TabIndex = 160;
            this.TableTmpLabel.Text = "status";
            // 
            // ChairSNlabel
            // 
            this.ChairSNlabel.AutoSize = true;
            this.ChairSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChairSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ChairSNlabel.Location = new System.Drawing.Point(324, 56);
            this.ChairSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ChairSNlabel.Name = "ChairSNlabel";
            this.ChairSNlabel.Size = new System.Drawing.Size(176, 36);
            this.ChairSNlabel.TabIndex = 171;
            this.ChairSNlabel.Text = "serialNumber";
            // 
            // tableLabel
            // 
            this.tableLabel.AutoSize = true;
            this.tableLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tableLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLabel.Location = new System.Drawing.Point(31, 123);
            this.tableLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tableLabel.Name = "tableLabel";
            this.tableLabel.Size = new System.Drawing.Size(75, 36);
            this.tableLabel.TabIndex = 152;
            this.tableLabel.Text = "Стол";
            // 
            // TableSNLabel
            // 
            this.TableSNLabel.AutoSize = true;
            this.TableSNLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TableSNLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TableSNLabel.Location = new System.Drawing.Point(324, 123);
            this.TableSNLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TableSNLabel.Name = "TableSNLabel";
            this.TableSNLabel.Size = new System.Drawing.Size(176, 36);
            this.TableSNLabel.TabIndex = 172;
            this.TableSNLabel.Text = "serialNumber";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(295, 63);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 260);
            this.panel5.TabIndex = 167;
            // 
            // WardrobeSNlabel
            // 
            this.WardrobeSNlabel.AutoSize = true;
            this.WardrobeSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WardrobeSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.WardrobeSNlabel.Location = new System.Drawing.Point(324, 259);
            this.WardrobeSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WardrobeSNlabel.Name = "WardrobeSNlabel";
            this.WardrobeSNlabel.Size = new System.Drawing.Size(176, 36);
            this.WardrobeSNlabel.TabIndex = 174;
            this.WardrobeSNlabel.Text = "serialNumber";
            // 
            // wardrobeLabel
            // 
            this.wardrobeLabel.AutoSize = true;
            this.wardrobeLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.wardrobeLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.wardrobeLabel.Location = new System.Drawing.Point(31, 259);
            this.wardrobeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.wardrobeLabel.Name = "wardrobeLabel";
            this.wardrobeLabel.Size = new System.Drawing.Size(90, 36);
            this.wardrobeLabel.TabIndex = 155;
            this.wardrobeLabel.Text = "Шкаф";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(577, 59);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 260);
            this.panel4.TabIndex = 169;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(104, 11);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 26);
            this.label9.TabIndex = 176;
            this.label9.Text = "Название";
            // 
            // chairLabel
            // 
            this.chairLabel.AutoSize = true;
            this.chairLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chairLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chairLabel.Location = new System.Drawing.Point(31, 56);
            this.chairLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.chairLabel.Name = "chairLabel";
            this.chairLabel.Size = new System.Drawing.Size(75, 36);
            this.chairLabel.TabIndex = 153;
            this.chairLabel.Text = "Стул";
            // 
            // LinenBox
            // 
            this.LinenBox.Controls.Add(this.Label1);
            this.LinenBox.Controls.Add(this.NameLabel);
            this.LinenBox.Controls.Add(this.bedspreadSNlabel);
            this.LinenBox.Controls.Add(this.Label2);
            this.LinenBox.Controls.Add(this.pillowcaseTmpLabel);
            this.LinenBox.Controls.Add(this.duvetTmpLabel);
            this.LinenBox.Controls.Add(this.label7);
            this.LinenBox.Controls.Add(this.duvetSNlabel);
            this.LinenBox.Controls.Add(this.towelSNlabel);
            this.LinenBox.Controls.Add(this.Label3);
            this.LinenBox.Controls.Add(this.bedsheetTmpLabel);
            this.LinenBox.Controls.Add(this.bedspreadTmpLabel);
            this.LinenBox.Controls.Add(this.label6);
            this.LinenBox.Controls.Add(this.pillowcaseSNLabel);
            this.LinenBox.Controls.Add(this.Label4);
            this.LinenBox.Controls.Add(this.panel2);
            this.LinenBox.Controls.Add(this.panelPassword);
            this.LinenBox.Controls.Add(this.towelTmpLabel);
            this.LinenBox.Controls.Add(this.bedsheetSNlabel);
            this.LinenBox.Controls.Add(this.Label5);
            this.LinenBox.Controls.Add(this.panel3);
            this.LinenBox.Location = new System.Drawing.Point(218, 187);
            this.LinenBox.Name = "LinenBox";
            this.LinenBox.Size = new System.Drawing.Size(885, 374);
            this.LinenBox.TabIndex = 182;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label1.Location = new System.Drawing.Point(22, 54);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(141, 36);
            this.Label1.TabIndex = 153;
            this.Label1.Text = "Простыня";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NameLabel.Location = new System.Drawing.Point(95, 9);
            this.NameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(96, 26);
            this.NameLabel.TabIndex = 176;
            this.NameLabel.Text = "Название";
            // 
            // bedspreadSNlabel
            // 
            this.bedspreadSNlabel.AutoSize = true;
            this.bedspreadSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedspreadSNlabel.Location = new System.Drawing.Point(315, 257);
            this.bedspreadSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bedspreadSNlabel.Name = "bedspreadSNlabel";
            this.bedspreadSNlabel.Size = new System.Drawing.Size(176, 36);
            this.bedspreadSNlabel.TabIndex = 174;
            this.bedspreadSNlabel.Text = "serialNumber";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label2.Location = new System.Drawing.Point(22, 121);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(147, 36);
            this.Label2.TabIndex = 152;
            this.Label2.Text = "Наволочка";
            // 
            // pillowcaseTmpLabel
            // 
            this.pillowcaseTmpLabel.AutoSize = true;
            this.pillowcaseTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pillowcaseTmpLabel.Location = new System.Drawing.Point(647, 121);
            this.pillowcaseTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pillowcaseTmpLabel.Name = "pillowcaseTmpLabel";
            this.pillowcaseTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.pillowcaseTmpLabel.TabIndex = 160;
            this.pillowcaseTmpLabel.Text = "status";
            // 
            // duvetTmpLabel
            // 
            this.duvetTmpLabel.AutoSize = true;
            this.duvetTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duvetTmpLabel.Location = new System.Drawing.Point(647, 189);
            this.duvetTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.duvetTmpLabel.Name = "duvetTmpLabel";
            this.duvetTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.duvetTmpLabel.TabIndex = 159;
            this.duvetTmpLabel.Text = "status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(622, 9);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 26);
            this.label7.TabIndex = 178;
            this.label7.Text = "Статус предмета";
            // 
            // duvetSNlabel
            // 
            this.duvetSNlabel.AutoSize = true;
            this.duvetSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.duvetSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duvetSNlabel.Location = new System.Drawing.Point(315, 189);
            this.duvetSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.duvetSNlabel.Name = "duvetSNlabel";
            this.duvetSNlabel.Size = new System.Drawing.Size(176, 36);
            this.duvetSNlabel.TabIndex = 173;
            this.duvetSNlabel.Text = "serialNumber";
            // 
            // towelSNlabel
            // 
            this.towelSNlabel.AutoSize = true;
            this.towelSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.towelSNlabel.Location = new System.Drawing.Point(315, 325);
            this.towelSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.towelSNlabel.Name = "towelSNlabel";
            this.towelSNlabel.Size = new System.Drawing.Size(176, 36);
            this.towelSNlabel.TabIndex = 175;
            this.towelSNlabel.Text = "serialNumber";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label3.Location = new System.Drawing.Point(22, 189);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(197, 36);
            this.Label3.TabIndex = 154;
            this.Label3.Text = "Пододеяльник";
            // 
            // bedsheetTmpLabel
            // 
            this.bedsheetTmpLabel.AutoSize = true;
            this.bedsheetTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedsheetTmpLabel.Location = new System.Drawing.Point(647, 54);
            this.bedsheetTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bedsheetTmpLabel.Name = "bedsheetTmpLabel";
            this.bedsheetTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.bedsheetTmpLabel.TabIndex = 161;
            this.bedsheetTmpLabel.Text = "status";
            // 
            // bedspreadTmpLabel
            // 
            this.bedspreadTmpLabel.AutoSize = true;
            this.bedspreadTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedspreadTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedspreadTmpLabel.Location = new System.Drawing.Point(647, 257);
            this.bedspreadTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bedspreadTmpLabel.Name = "bedspreadTmpLabel";
            this.bedspreadTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.bedspreadTmpLabel.TabIndex = 158;
            this.bedspreadTmpLabel.Text = "status";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(315, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 26);
            this.label6.TabIndex = 177;
            this.label6.Text = "Серийный номер";
            // 
            // pillowcaseSNLabel
            // 
            this.pillowcaseSNLabel.AutoSize = true;
            this.pillowcaseSNLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pillowcaseSNLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pillowcaseSNLabel.Location = new System.Drawing.Point(315, 121);
            this.pillowcaseSNLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pillowcaseSNLabel.Name = "pillowcaseSNLabel";
            this.pillowcaseSNLabel.Size = new System.Drawing.Size(176, 36);
            this.pillowcaseSNLabel.TabIndex = 172;
            this.pillowcaseSNLabel.Text = "serialNumber";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label4.Location = new System.Drawing.Point(22, 257);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(155, 36);
            this.Label4.TabIndex = 155;
            this.Label4.Text = "Покрывало";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(568, 57);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 308);
            this.panel2.TabIndex = 169;
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(286, 61);
            this.panelPassword.Margin = new System.Windows.Forms.Padding(4);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(1, 308);
            this.panelPassword.TabIndex = 167;
            // 
            // towelTmpLabel
            // 
            this.towelTmpLabel.AutoSize = true;
            this.towelTmpLabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.towelTmpLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.towelTmpLabel.Location = new System.Drawing.Point(647, 325);
            this.towelTmpLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.towelTmpLabel.Name = "towelTmpLabel";
            this.towelTmpLabel.Size = new System.Drawing.Size(85, 36);
            this.towelTmpLabel.TabIndex = 157;
            this.towelTmpLabel.Text = "status";
            // 
            // bedsheetSNlabel
            // 
            this.bedsheetSNlabel.AutoSize = true;
            this.bedsheetSNlabel.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bedsheetSNlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bedsheetSNlabel.Location = new System.Drawing.Point(315, 54);
            this.bedsheetSNlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bedsheetSNlabel.Name = "bedsheetSNlabel";
            this.bedsheetSNlabel.Size = new System.Drawing.Size(176, 36);
            this.bedsheetSNlabel.TabIndex = 171;
            this.bedsheetSNlabel.Text = "serialNumber";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label5.Location = new System.Drawing.Point(22, 325);
            this.Label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(149, 36);
            this.Label5.TabIndex = 156;
            this.Label5.Text = "Полотенце";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(25, 49);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(850, 1);
            this.panel3.TabIndex = 170;
            // 
            // ItemBox
            // 
            this.ItemBox.Controls.Add(this.chairLabel);
            this.ItemBox.Controls.Add(this.label9);
            this.ItemBox.Controls.Add(this.panel4);
            this.ItemBox.Controls.Add(this.wardrobeLabel);
            this.ItemBox.Controls.Add(this.WardrobeSNlabel);
            this.ItemBox.Controls.Add(this.panel5);
            this.ItemBox.Controls.Add(this.TableSNLabel);
            this.ItemBox.Controls.Add(this.tableLabel);
            this.ItemBox.Controls.Add(this.ChairSNlabel);
            this.ItemBox.Controls.Add(this.TableTmpLabel);
            this.ItemBox.Controls.Add(this.WardrobeTmpLabel);
            this.ItemBox.Controls.Add(this.ShelfTmpLabel);
            this.ItemBox.Controls.Add(this.ChairTmpLabel);
            this.ItemBox.Controls.Add(this.panel6);
            this.ItemBox.Controls.Add(this.label14);
            this.ItemBox.Controls.Add(this.shelfLabel);
            this.ItemBox.Controls.Add(this.label20);
            this.ItemBox.Controls.Add(this.ShelfSNlabel);
            this.ItemBox.Location = new System.Drawing.Point(210, 186);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(885, 374);
            this.ItemBox.TabIndex = 184;
            // 
            // MyItemsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1302, 703);
            this.Controls.Add(this.ShowItemBtn);
            this.Controls.Add(this.ShowLinenBtn);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.LinenBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MyItemsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyItemsForm";
            this.Load += new System.EventHandler(this.MyItemsForm_Load);
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.LinenBox.ResumeLayout(false);
            this.LinenBox.PerformLayout();
            this.ItemBox.ResumeLayout(false);
            this.ItemBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Button ShowLinenBtn;
        private System.Windows.Forms.Button ShowItemBtn;
        private System.Windows.Forms.Label ShelfSNlabel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label shelfLabel;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label ChairTmpLabel;
        private System.Windows.Forms.Label ShelfTmpLabel;
        private System.Windows.Forms.Label WardrobeTmpLabel;
        private System.Windows.Forms.Label TableTmpLabel;
        private System.Windows.Forms.Label ChairSNlabel;
        private System.Windows.Forms.Label tableLabel;
        private System.Windows.Forms.Label TableSNLabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label WardrobeSNlabel;
        private System.Windows.Forms.Label wardrobeLabel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label chairLabel;
        private System.Windows.Forms.Panel LinenBox;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label bedspreadSNlabel;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Label pillowcaseTmpLabel;
        private System.Windows.Forms.Label duvetTmpLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label duvetSNlabel;
        private System.Windows.Forms.Label towelSNlabel;
        private System.Windows.Forms.Label Label3;
        private System.Windows.Forms.Label bedsheetTmpLabel;
        private System.Windows.Forms.Label bedspreadTmpLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label pillowcaseSNLabel;
        private System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.Label towelTmpLabel;
        private System.Windows.Forms.Label bedsheetSNlabel;
        private System.Windows.Forms.Label Label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel ItemBox;
    }
}