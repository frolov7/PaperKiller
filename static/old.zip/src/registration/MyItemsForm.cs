﻿using AccessToDB;
using DataStructures;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace registration
{
    public partial class MyItemsForm : Form
    {
        Student currentStudent;

        Linen currentLinen = null;
        Items currentItems = null;

        Chair currentChair = null;
        Table currentTable = null;
        Shelf currentShelf = null;
        Wardrobe currentWardrobe = null;

        Bedsheet currentBedsheet = null;
        Pillowcase currentPillowcase = null;
        Duvet currentDuvet = null;
        Bedspread currentBedspread = null;
        Towel currentTowel = null;

        Connector connectDB = new Connector();

        public MyItemsForm(Student currentStudent)
        {
            InitializeComponent();
            this.currentStudent = currentStudent;

            currentLinen = GetInfo.GetLinenByID(connectDB, currentStudent.userID);
            currentItems = GetInfo.GetItemsByID(connectDB, currentStudent.userID);

            currentChair = GetInfo.GetChairByID(connectDB, currentStudent.userID);
            currentTable = GetInfo.GetTableByID(connectDB, currentStudent.userID);
            currentShelf = GetInfo.GetShelfByID(connectDB, currentStudent.userID);
            currentWardrobe = GetInfo.GetWardrobeByID(connectDB, currentStudent.userID);

            currentBedsheet = GetInfo.GetBedsheetByID(connectDB, currentLinen.linenID);
            currentPillowcase = GetInfo.GetPillowcaseByID(connectDB, currentLinen.linenID);
            currentDuvet = GetInfo.GetDuvetByID(connectDB, currentLinen.linenID);
            currentBedspread = GetInfo.GetBedspreadByID(connectDB, currentLinen.linenID);
            currentTowel = GetInfo.GetTowelByID(connectDB, currentLinen.linenID);
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            UserMainMenuForm userForm = new UserMainMenuForm(currentStudent);
            userForm.ShowDialog(); // открыть окно
        }

        private void MyItemsForm_Load(object sender, EventArgs e)
        {
            LinenBox.Visible = false;
            ItemBox.Visible = false;

            if (currentLinen.bedsheetID != 0)
            {
                bedsheetTmpLabel.Text = "В наличии";
                bedsheetSNlabel.Text = currentBedsheet.serialNumber.ToString();
            }
            else
            {
                bedsheetTmpLabel.Text = "Пусто";
                bedsheetSNlabel.Text = "Пусто";
            }

            if (currentLinen.pillowcaseID != 0)
            {
                pillowcaseTmpLabel.Text = "В наличии";
                pillowcaseSNLabel.Text = currentPillowcase.serialNumber.ToString();
            }
            else
            {
                pillowcaseTmpLabel.Text = "Пусто";
                pillowcaseSNLabel.Text = "Пусто";
            }

            if (currentLinen.duvetID != 0)
            {
                duvetTmpLabel.Text = "В наличии";
                duvetSNlabel.Text = currentDuvet.serialNumber.ToString();
            }
            else
            {
                duvetTmpLabel.Text = "Пусто";
                duvetSNlabel.Text = "Пусто";
            }

            if (currentLinen.bedspreadID != 0)
            {
                bedspreadTmpLabel.Text = "В наличии";
                bedspreadSNlabel.Text = currentBedspread.serialNumber.ToString();
            }
            else
            {
                bedspreadTmpLabel.Text = "Пусто";
                bedspreadSNlabel.Text = "Пусто";
            }

            if (currentLinen.towelID != 0)
            {
                towelTmpLabel.Text = "В наличии";
                towelSNlabel.Text = currentTowel.serialNumber.ToString();
            }
            else
            {
                towelTmpLabel.Text = "Пусто";
                towelSNlabel.Text = "Пусто";
            }

            if (currentItems.chairID != 0)
            {
                ChairTmpLabel.Text = "В наличии";
                ChairSNlabel.Text = currentChair.serialNumber.ToString();
            }
            else
            {
                ChairTmpLabel.Text = "Пусто";
                ChairSNlabel.Text = "Пусто";
            }

            if (currentItems.tableID != 0)
            {
                TableTmpLabel.Text = "В наличии";
                TableSNLabel.Text = currentTable.serialNumber.ToString();
            }
            else
            {
                TableTmpLabel.Text = "Пусто";
                TableSNLabel.Text = "Пусто";
            }

            if (currentItems.shelfID != 0)
            {
                ShelfTmpLabel.Text = "В наличии";
                ShelfSNlabel.Text = currentShelf.serialNumber.ToString();
            }
            else
            {
                ShelfTmpLabel.Text = "Пусто";
                ShelfSNlabel.Text = "Пусто";
            }

            if (currentItems.wardrobeID != 0)
            {
                WardrobeTmpLabel.Text = "В наличии";
                WardrobeSNlabel.Text = currentWardrobe.serialNumber.ToString();
            }
            else
            {
                WardrobeTmpLabel.Text = "Пусто";
                WardrobeSNlabel.Text = "Пусто";
            }
        }

        private void ShowLinenBtn_Click(object sender, EventArgs e)
        {
            ItemBox.Visible = false;
            LinenBox.Visible = true;
        }

        private void ShowItemBtn_Click_1(object sender, EventArgs e)
        {
            LinenBox.Visible = false;
            ItemBox.Visible = true;
        }
    }
}
