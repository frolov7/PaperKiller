﻿namespace registration
{
    partial class ForgetPassForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headingPanel = new System.Windows.Forms.Panel();
            this.headingLabel = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.checkPassImg = new System.Windows.Forms.PictureBox();
            this.panelPasswordRepeat = new System.Windows.Forms.Panel();
            this.passwordRepeatField = new System.Windows.Forms.TextBox();
            this.passwordRepeatImg = new System.Windows.Forms.PictureBox();
            this.panelEmail = new System.Windows.Forms.Panel();
            this.passwordField = new System.Windows.Forms.TextBox();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.passwordImg = new System.Windows.Forms.PictureBox();
            this.studentIDField = new System.Windows.Forms.TextBox();
            this.studentIDImg = new System.Windows.Forms.PictureBox();
            this.panelLogin = new System.Windows.Forms.Panel();
            this.loginField = new System.Windows.Forms.TextBox();
            this.loginImg = new System.Windows.Forms.PictureBox();
            this.closeLabel = new System.Windows.Forms.Label();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.changePassBtn = new System.Windows.Forms.Button();
            this.headingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkPassImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordRepeatImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentIDImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).BeginInit();
            this.SuspendLayout();
            // 
            // headingPanel
            // 
            this.headingPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.headingPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.headingPanel.Controls.Add(this.headingLabel);
            this.headingPanel.Location = new System.Drawing.Point(317, 48);
            this.headingPanel.Name = "headingPanel";
            this.headingPanel.Size = new System.Drawing.Size(369, 69);
            this.headingPanel.TabIndex = 77;
            // 
            // headingLabel
            // 
            this.headingLabel.AutoSize = true;
            this.headingLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.headingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.headingLabel.Location = new System.Drawing.Point(14, 14);
            this.headingLabel.Name = "headingLabel";
            this.headingLabel.Size = new System.Drawing.Size(297, 40);
            this.headingLabel.TabIndex = 30;
            this.headingLabel.Text = "Забыли пароль";
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(33, 63);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(239, 40);
            this.logoLabel.TabIndex = 76;
            this.logoLabel.Text = "PaperKiller";
            // 
            // checkPassImg
            // 
            this.checkPassImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.checkPassImg.Location = new System.Drawing.Point(662, 221);
            this.checkPassImg.Name = "checkPassImg";
            this.checkPassImg.Size = new System.Drawing.Size(18, 18);
            this.checkPassImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.checkPassImg.TabIndex = 93;
            this.checkPassImg.TabStop = false;
            // 
            // panelPasswordRepeat
            // 
            this.panelPasswordRepeat.BackColor = System.Drawing.Color.White;
            this.panelPasswordRepeat.Location = new System.Drawing.Point(399, 246);
            this.panelPasswordRepeat.Name = "panelPasswordRepeat";
            this.panelPasswordRepeat.Size = new System.Drawing.Size(250, 1);
            this.panelPasswordRepeat.TabIndex = 92;
            // 
            // passwordRepeatField
            // 
            this.passwordRepeatField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordRepeatField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordRepeatField.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passwordRepeatField.ForeColor = System.Drawing.Color.White;
            this.passwordRepeatField.HideSelection = false;
            this.passwordRepeatField.Location = new System.Drawing.Point(447, 217);
            this.passwordRepeatField.Name = "passwordRepeatField";
            this.passwordRepeatField.Size = new System.Drawing.Size(200, 22);
            this.passwordRepeatField.TabIndex = 91;
            this.passwordRepeatField.TabStop = false;
            this.passwordRepeatField.Click += new System.EventHandler(this.passwordRepeatField_Click);
            this.passwordRepeatField.Enter += new System.EventHandler(this.passwordRepeatField_Enter);
            this.passwordRepeatField.Leave += new System.EventHandler(this.passwordRepeatField_Leave);
            // 
            // passwordRepeatImg
            // 
            this.passwordRepeatImg.Image = global::registration.Properties.Resources.secure_icon2;
            this.passwordRepeatImg.Location = new System.Drawing.Point(409, 207);
            this.passwordRepeatImg.Name = "passwordRepeatImg";
            this.passwordRepeatImg.Size = new System.Drawing.Size(32, 32);
            this.passwordRepeatImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordRepeatImg.TabIndex = 90;
            this.passwordRepeatImg.TabStop = false;
            // 
            // panelEmail
            // 
            this.panelEmail.BackColor = System.Drawing.Color.White;
            this.panelEmail.Location = new System.Drawing.Point(399, 180);
            this.panelEmail.Name = "panelEmail";
            this.panelEmail.Size = new System.Drawing.Size(250, 1);
            this.panelEmail.TabIndex = 89;
            // 
            // passwordField
            // 
            this.passwordField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.passwordField.ForeColor = System.Drawing.Color.White;
            this.passwordField.HideSelection = false;
            this.passwordField.Location = new System.Drawing.Point(73, 217);
            this.passwordField.Name = "passwordField";
            this.passwordField.Size = new System.Drawing.Size(200, 22);
            this.passwordField.TabIndex = 88;
            this.passwordField.TabStop = false;
            this.passwordField.Click += new System.EventHandler(this.passwordField_Click);
            this.passwordField.Enter += new System.EventHandler(this.passwordField_Enter);
            this.passwordField.Leave += new System.EventHandler(this.passwordField_Leave);
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(25, 245);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(250, 1);
            this.panelPassword.TabIndex = 86;
            // 
            // passwordImg
            // 
            this.passwordImg.Image = global::registration.Properties.Resources.secure_icon;
            this.passwordImg.Location = new System.Drawing.Point(35, 207);
            this.passwordImg.Name = "passwordImg";
            this.passwordImg.Size = new System.Drawing.Size(32, 32);
            this.passwordImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordImg.TabIndex = 87;
            this.passwordImg.TabStop = false;
            // 
            // studentIDField
            // 
            this.studentIDField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.studentIDField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.studentIDField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.studentIDField.ForeColor = System.Drawing.Color.White;
            this.studentIDField.HideSelection = false;
            this.studentIDField.Location = new System.Drawing.Point(447, 152);
            this.studentIDField.Name = "studentIDField";
            this.studentIDField.Size = new System.Drawing.Size(200, 22);
            this.studentIDField.TabIndex = 85;
            this.studentIDField.TabStop = false;
            this.studentIDField.Click += new System.EventHandler(this.studentIDField_Click);
            this.studentIDField.Enter += new System.EventHandler(this.studentIDField_Enter);
            this.studentIDField.Leave += new System.EventHandler(this.studentIDField_Leave);
            // 
            // studentIDImg
            // 
            this.studentIDImg.Image = global::registration.Properties.Resources.learning;
            this.studentIDImg.Location = new System.Drawing.Point(409, 142);
            this.studentIDImg.Name = "studentIDImg";
            this.studentIDImg.Size = new System.Drawing.Size(32, 32);
            this.studentIDImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.studentIDImg.TabIndex = 84;
            this.studentIDImg.TabStop = false;
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.White;
            this.panelLogin.Location = new System.Drawing.Point(25, 180);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(250, 1);
            this.panelLogin.TabIndex = 80;
            // 
            // loginField
            // 
            this.loginField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.loginField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.loginField.ForeColor = System.Drawing.Color.White;
            this.loginField.HideSelection = false;
            this.loginField.Location = new System.Drawing.Point(73, 152);
            this.loginField.Name = "loginField";
            this.loginField.Size = new System.Drawing.Size(200, 22);
            this.loginField.TabIndex = 79;
            this.loginField.TabStop = false;
            this.loginField.Click += new System.EventHandler(this.loginField_Click);
            this.loginField.Enter += new System.EventHandler(this.loginField_Enter);
            this.loginField.Leave += new System.EventHandler(this.loginField_Leave);
            // 
            // loginImg
            // 
            this.loginImg.BackgroundImage = global::registration.Properties.Resources.login_icon2;
            this.loginImg.Image = global::registration.Properties.Resources.login_icon;
            this.loginImg.Location = new System.Drawing.Point(35, 142);
            this.loginImg.Name = "loginImg";
            this.loginImg.Size = new System.Drawing.Size(32, 32);
            this.loginImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginImg.TabIndex = 78;
            this.loginImg.TabStop = false;
            // 
            // closeLabel
            // 
            this.closeLabel.AutoSize = true;
            this.closeLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeLabel.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.closeLabel.Location = new System.Drawing.Point(659, -1);
            this.closeLabel.Name = "closeLabel";
            this.closeLabel.Size = new System.Drawing.Size(27, 36);
            this.closeLabel.TabIndex = 94;
            this.closeLabel.Text = "X";
            this.closeLabel.Click += new System.EventHandler(this.closeLabel_Click);
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(25, 311);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 38);
            this.goBackBtn.TabIndex = 95;
            this.goBackBtn.Text = "Вернуться назад";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // changePassBtn
            // 
            this.changePassBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.changePassBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.changePassBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changePassBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.changePassBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.changePassBtn.Location = new System.Drawing.Point(399, 311);
            this.changePassBtn.Name = "changePassBtn";
            this.changePassBtn.Size = new System.Drawing.Size(250, 38);
            this.changePassBtn.TabIndex = 96;
            this.changePassBtn.Text = "Сменить пароль";
            this.changePassBtn.UseVisualStyleBackColor = false;
            this.changePassBtn.Click += new System.EventHandler(this.changePassBtn_Click);
            // 
            // ForgetPassForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(687, 361);
            this.Controls.Add(this.changePassBtn);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.closeLabel);
            this.Controls.Add(this.checkPassImg);
            this.Controls.Add(this.panelPasswordRepeat);
            this.Controls.Add(this.passwordRepeatField);
            this.Controls.Add(this.passwordRepeatImg);
            this.Controls.Add(this.panelEmail);
            this.Controls.Add(this.passwordField);
            this.Controls.Add(this.panelPassword);
            this.Controls.Add(this.passwordImg);
            this.Controls.Add(this.studentIDField);
            this.Controls.Add(this.studentIDImg);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.loginField);
            this.Controls.Add(this.loginImg);
            this.Controls.Add(this.headingPanel);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ForgetPassForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ForgetPassFrom";
            this.Click += new System.EventHandler(this.ForgetPassForm_Click);
            this.headingPanel.ResumeLayout(false);
            this.headingPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkPassImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordRepeatImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentIDImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel headingPanel;
        private System.Windows.Forms.Label headingLabel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.PictureBox checkPassImg;
        private System.Windows.Forms.Panel panelPasswordRepeat;
        private System.Windows.Forms.TextBox passwordRepeatField;
        private System.Windows.Forms.PictureBox passwordRepeatImg;
        private System.Windows.Forms.Panel panelEmail;
        private System.Windows.Forms.TextBox passwordField;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.PictureBox passwordImg;
        private System.Windows.Forms.TextBox studentIDField;
        private System.Windows.Forms.PictureBox studentIDImg;
        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.TextBox loginField;
        private System.Windows.Forms.PictureBox loginImg;
        private System.Windows.Forms.Label closeLabel;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Button changePassBtn;
    }
}