﻿namespace registration
{
    partial class ChangeDataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.closeBtn = new System.Windows.Forms.Label();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkPassImg = new System.Windows.Forms.PictureBox();
            this.panelPasswordRepeat = new System.Windows.Forms.Panel();
            this.passwordRepeatField = new System.Windows.Forms.TextBox();
            this.passwordRepeatImg = new System.Windows.Forms.PictureBox();
            this.passwordField = new System.Windows.Forms.TextBox();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.passwordImg = new System.Windows.Forms.PictureBox();
            this.panelSurname = new System.Windows.Forms.Panel();
            this.surnameField = new System.Windows.Forms.TextBox();
            this.panelPhone = new System.Windows.Forms.Panel();
            this.surnameImg = new System.Windows.Forms.PictureBox();
            this.phoneField = new System.Windows.Forms.TextBox();
            this.panelLogin = new System.Windows.Forms.Panel();
            this.phoneImg = new System.Windows.Forms.PictureBox();
            this.loginField = new System.Windows.Forms.TextBox();
            this.panelName = new System.Windows.Forms.Panel();
            this.loginImg = new System.Windows.Forms.PictureBox();
            this.nameField = new System.Windows.Forms.TextBox();
            this.nameImg = new System.Windows.Forms.PictureBox();
            this.goBackBtn = new System.Windows.Forms.Button();
            this.registerBtn = new System.Windows.Forms.Button();
            this.mainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkPassImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordRepeatImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.surnameImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameImg)).BeginInit();
            this.SuspendLayout();
            // 
            // closeBtn
            // 
            this.closeBtn.AutoSize = true;
            this.closeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Font = new System.Drawing.Font("Dubai", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.closeBtn.Location = new System.Drawing.Point(672, -1);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(27, 36);
            this.closeBtn.TabIndex = 43;
            this.closeBtn.Text = "X";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.registrationLabel);
            this.mainPanel.Location = new System.Drawing.Point(300, 55);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(399, 53);
            this.mainPanel.TabIndex = 42;
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Font = new System.Drawing.Font("DejaVu Sans Condensed", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.registrationLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registrationLabel.Location = new System.Drawing.Point(45, 8);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(285, 34);
            this.registrationLabel.TabIndex = 30;
            this.registrationLabel.Text = "Изменить данные";
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.logoLabel.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.logoLabel.Location = new System.Drawing.Point(24, 64);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(239, 40);
            this.logoLabel.TabIndex = 41;
            this.logoLabel.Text = "PaperKiller";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FloralWhite;
            this.label1.Location = new System.Drawing.Point(72, 335);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 16);
            this.label1.TabIndex = 67;
            this.label1.Text = "Формат \"+71234567890\"";
            // 
            // checkPassImg
            // 
            this.checkPassImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.checkPassImg.Location = new System.Drawing.Point(661, 307);
            this.checkPassImg.Name = "checkPassImg";
            this.checkPassImg.Size = new System.Drawing.Size(18, 18);
            this.checkPassImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.checkPassImg.TabIndex = 66;
            this.checkPassImg.TabStop = false;
            // 
            // panelPasswordRepeat
            // 
            this.panelPasswordRepeat.BackColor = System.Drawing.Color.White;
            this.panelPasswordRepeat.Location = new System.Drawing.Point(398, 332);
            this.panelPasswordRepeat.Name = "panelPasswordRepeat";
            this.panelPasswordRepeat.Size = new System.Drawing.Size(250, 1);
            this.panelPasswordRepeat.TabIndex = 65;
            // 
            // passwordRepeatField
            // 
            this.passwordRepeatField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordRepeatField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordRepeatField.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passwordRepeatField.ForeColor = System.Drawing.Color.White;
            this.passwordRepeatField.HideSelection = false;
            this.passwordRepeatField.Location = new System.Drawing.Point(446, 303);
            this.passwordRepeatField.Name = "passwordRepeatField";
            this.passwordRepeatField.Size = new System.Drawing.Size(200, 22);
            this.passwordRepeatField.TabIndex = 64;
            this.passwordRepeatField.TabStop = false;
            // 
            // passwordRepeatImg
            // 
            this.passwordRepeatImg.Image = global::registration.Properties.Resources.secure_icon2;
            this.passwordRepeatImg.Location = new System.Drawing.Point(408, 293);
            this.passwordRepeatImg.Name = "passwordRepeatImg";
            this.passwordRepeatImg.Size = new System.Drawing.Size(32, 32);
            this.passwordRepeatImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordRepeatImg.TabIndex = 63;
            this.passwordRepeatImg.TabStop = false;
            // 
            // passwordField
            // 
            this.passwordField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.passwordField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.passwordField.ForeColor = System.Drawing.Color.White;
            this.passwordField.HideSelection = false;
            this.passwordField.Location = new System.Drawing.Point(446, 233);
            this.passwordField.Name = "passwordField";
            this.passwordField.Size = new System.Drawing.Size(200, 22);
            this.passwordField.TabIndex = 61;
            this.passwordField.TabStop = false;
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.White;
            this.panelPassword.Location = new System.Drawing.Point(398, 261);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(250, 1);
            this.panelPassword.TabIndex = 59;
            // 
            // passwordImg
            // 
            this.passwordImg.Image = global::registration.Properties.Resources.secure_icon;
            this.passwordImg.Location = new System.Drawing.Point(408, 223);
            this.passwordImg.Name = "passwordImg";
            this.passwordImg.Size = new System.Drawing.Size(32, 32);
            this.passwordImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passwordImg.TabIndex = 60;
            this.passwordImg.TabStop = false;
            // 
            // panelSurname
            // 
            this.panelSurname.BackColor = System.Drawing.Color.White;
            this.panelSurname.Location = new System.Drawing.Point(398, 191);
            this.panelSurname.Name = "panelSurname";
            this.panelSurname.Size = new System.Drawing.Size(250, 1);
            this.panelSurname.TabIndex = 56;
            // 
            // surnameField
            // 
            this.surnameField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.surnameField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.surnameField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.surnameField.ForeColor = System.Drawing.Color.White;
            this.surnameField.HideSelection = false;
            this.surnameField.Location = new System.Drawing.Point(446, 163);
            this.surnameField.Name = "surnameField";
            this.surnameField.Size = new System.Drawing.Size(200, 22);
            this.surnameField.TabIndex = 55;
            this.surnameField.TabStop = false;
            // 
            // panelPhone
            // 
            this.panelPhone.BackColor = System.Drawing.Color.White;
            this.panelPhone.Location = new System.Drawing.Point(15, 331);
            this.panelPhone.Name = "panelPhone";
            this.panelPhone.Size = new System.Drawing.Size(250, 1);
            this.panelPhone.TabIndex = 53;
            // 
            // surnameImg
            // 
            this.surnameImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female2;
            this.surnameImg.Image = global::registration.Properties.Resources.user_icon2;
            this.surnameImg.Location = new System.Drawing.Point(408, 153);
            this.surnameImg.Name = "surnameImg";
            this.surnameImg.Size = new System.Drawing.Size(32, 32);
            this.surnameImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.surnameImg.TabIndex = 54;
            this.surnameImg.TabStop = false;
            // 
            // phoneField
            // 
            this.phoneField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.phoneField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phoneField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.phoneField.ForeColor = System.Drawing.Color.White;
            this.phoneField.HideSelection = false;
            this.phoneField.Location = new System.Drawing.Point(63, 303);
            this.phoneField.Name = "phoneField";
            this.phoneField.Size = new System.Drawing.Size(200, 22);
            this.phoneField.TabIndex = 52;
            this.phoneField.TabStop = false;
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.White;
            this.panelLogin.Location = new System.Drawing.Point(15, 261);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(250, 1);
            this.panelLogin.TabIndex = 50;
            // 
            // phoneImg
            // 
            this.phoneImg.Image = global::registration.Properties.Resources.phone_icon;
            this.phoneImg.Location = new System.Drawing.Point(25, 293);
            this.phoneImg.Name = "phoneImg";
            this.phoneImg.Size = new System.Drawing.Size(32, 32);
            this.phoneImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.phoneImg.TabIndex = 51;
            this.phoneImg.TabStop = false;
            // 
            // loginField
            // 
            this.loginField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.loginField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.loginField.ForeColor = System.Drawing.Color.White;
            this.loginField.HideSelection = false;
            this.loginField.Location = new System.Drawing.Point(63, 233);
            this.loginField.Name = "loginField";
            this.loginField.Size = new System.Drawing.Size(200, 22);
            this.loginField.TabIndex = 49;
            this.loginField.TabStop = false;
            // 
            // panelName
            // 
            this.panelName.BackColor = System.Drawing.Color.White;
            this.panelName.Location = new System.Drawing.Point(15, 191);
            this.panelName.Name = "panelName";
            this.panelName.Size = new System.Drawing.Size(250, 1);
            this.panelName.TabIndex = 47;
            // 
            // loginImg
            // 
            this.loginImg.BackgroundImage = global::registration.Properties.Resources.login_icon2;
            this.loginImg.Image = global::registration.Properties.Resources.login_icon;
            this.loginImg.Location = new System.Drawing.Point(25, 223);
            this.loginImg.Name = "loginImg";
            this.loginImg.Size = new System.Drawing.Size(32, 32);
            this.loginImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginImg.TabIndex = 48;
            this.loginImg.TabStop = false;
            // 
            // nameField
            // 
            this.nameField.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nameField.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nameField.Font = new System.Drawing.Font("Arial", 14.25F);
            this.nameField.ForeColor = System.Drawing.Color.White;
            this.nameField.HideSelection = false;
            this.nameField.Location = new System.Drawing.Point(63, 163);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(200, 22);
            this.nameField.TabIndex = 46;
            this.nameField.TabStop = false;
            // 
            // nameImg
            // 
            this.nameImg.BackgroundImage = global::registration.Properties.Resources.user_icon_female;
            this.nameImg.Image = global::registration.Properties.Resources.user_icon;
            this.nameImg.Location = new System.Drawing.Point(25, 153);
            this.nameImg.Name = "nameImg";
            this.nameImg.Size = new System.Drawing.Size(32, 32);
            this.nameImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nameImg.TabIndex = 45;
            this.nameImg.TabStop = false;
            // 
            // goBackBtn
            // 
            this.goBackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.goBackBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.goBackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.goBackBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.goBackBtn.ForeColor = System.Drawing.Color.White;
            this.goBackBtn.Location = new System.Drawing.Point(12, 370);
            this.goBackBtn.Name = "goBackBtn";
            this.goBackBtn.Size = new System.Drawing.Size(250, 40);
            this.goBackBtn.TabIndex = 69;
            this.goBackBtn.Text = "Вернуться назад";
            this.goBackBtn.UseVisualStyleBackColor = false;
            this.goBackBtn.Click += new System.EventHandler(this.goBackBtn_Click);
            // 
            // registerBtn
            // 
            this.registerBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.registerBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.registerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.registerBtn.Font = new System.Drawing.Font("Imprint MT Shadow", 18F);
            this.registerBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.registerBtn.Location = new System.Drawing.Point(433, 370);
            this.registerBtn.Name = "registerBtn";
            this.registerBtn.Size = new System.Drawing.Size(250, 40);
            this.registerBtn.TabIndex = 68;
            this.registerBtn.Text = "Принять";
            this.registerBtn.UseVisualStyleBackColor = false;
            this.registerBtn.Click += new System.EventHandler(this.registerBtn_Click);
            // 
            // ChangeDataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(695, 423);
            this.Controls.Add(this.goBackBtn);
            this.Controls.Add(this.registerBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkPassImg);
            this.Controls.Add(this.panelPasswordRepeat);
            this.Controls.Add(this.passwordRepeatField);
            this.Controls.Add(this.passwordRepeatImg);
            this.Controls.Add(this.passwordField);
            this.Controls.Add(this.panelPassword);
            this.Controls.Add(this.passwordImg);
            this.Controls.Add(this.panelSurname);
            this.Controls.Add(this.surnameField);
            this.Controls.Add(this.panelPhone);
            this.Controls.Add(this.surnameImg);
            this.Controls.Add(this.phoneField);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.phoneImg);
            this.Controls.Add(this.loginField);
            this.Controls.Add(this.panelName);
            this.Controls.Add(this.loginImg);
            this.Controls.Add(this.nameField);
            this.Controls.Add(this.nameImg);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.logoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChangeDataForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangeDataForm";
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkPassImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordRepeatImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.surnameImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label closeBtn;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox checkPassImg;
        private System.Windows.Forms.Panel panelPasswordRepeat;
        private System.Windows.Forms.TextBox passwordRepeatField;
        private System.Windows.Forms.PictureBox passwordRepeatImg;
        private System.Windows.Forms.TextBox passwordField;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.PictureBox passwordImg;
        private System.Windows.Forms.Panel panelSurname;
        private System.Windows.Forms.TextBox surnameField;
        private System.Windows.Forms.Panel panelPhone;
        private System.Windows.Forms.PictureBox surnameImg;
        private System.Windows.Forms.TextBox phoneField;
        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.PictureBox phoneImg;
        private System.Windows.Forms.TextBox loginField;
        private System.Windows.Forms.Panel panelName;
        private System.Windows.Forms.PictureBox loginImg;
        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.PictureBox nameImg;
        private System.Windows.Forms.Button goBackBtn;
        private System.Windows.Forms.Button registerBtn;
    }
}