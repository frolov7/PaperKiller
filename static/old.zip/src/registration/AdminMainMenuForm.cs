﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccessToDB;
using DataStructures;


using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace registration
{
    public partial class AdminMainMenuForm : Form
    {
        Connector connectDB = new Connector();
        Student currentStudent;
        string status;

        public AdminMainMenuForm(Student currentStudent, string status)
        {
            InitializeComponent();

            this.currentStudent = currentStudent;
            this.status = status;

            userLabelTmp.Text = "Admin";
            loginLabelTmp.Text = "Admin";
            statusLabelTmp.Text = status;
        }

        private void AdminMainMenuForm_Load(object sender, EventArgs e)
        {
            if (status == "Commandant")
            {
                AllItemsBtn.Enabled = false;
                AddItemBtn.Enabled = false;
                GiveItemBtn.Enabled = false;
                ChangeItemBtn.Enabled = false;
                TakeItemBtn.Enabled = false;
            }
            else
                AllStudentBtn.Enabled = false;

        }

        private void goBackBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // закрыть активное окно
            AuthorizationForm authorization = new AuthorizationForm();
            authorization.ShowDialog(); // открыть окно
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AllStudentBtn_Click(object sender, EventArgs e)
        {
            //this.Hide(); // закрыть активное окно
            ShowStudentsForm studentsForm = new ShowStudentsForm(currentStudent);
            studentsForm.ShowDialog(); // открыть окно
        }

        private void AllItemsBtn_Click(object sender, EventArgs e)
        {
            //this.Hide(); // закрыть активное окно
            ShowItemsForm showItemsForm = new ShowItemsForm(currentStudent);
            showItemsForm.ShowDialog(); // открыть окно
        }

        private void AddItemBtn_Click(object sender, EventArgs e)
        {
            AddItemsForm addItemsForm = new AddItemsForm();
            addItemsForm.ShowDialog(); // открыть окно
        }

        private void GiveItemBtn_Click(object sender, EventArgs e)
        {
            GiveItemForm giveItemForm = new GiveItemForm();
            giveItemForm.ShowDialog(); // открыть окно
        }

        private void ChangeItemBtn_Click(object sender, EventArgs e)
        {
            ChangeItemForm changeItemForm = new ChangeItemForm();
            changeItemForm.ShowDialog(); // открыть окно
        }

        private void TakeItemBtn_Click(object sender, EventArgs e)
        {
            TakeItemForm takeItemForm = new TakeItemForm();
            takeItemForm.ShowDialog(); // открыть окно
        }

        private void ReportBtn_Click(object sender, EventArgs e)
        {
            ReportForm reportform = new ReportForm();
            reportform.ShowDialog(); // открыть окно
        }
    }
}
