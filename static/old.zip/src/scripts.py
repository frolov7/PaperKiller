from random import randint

def create_items_data(table_name):
    file = open("data.txt", "w", encoding='utf-8')
    status = ["У студента", "На складе"]
    for i in range(20):
        values = randint(100000, 999999)
        file.write("insert into " + table_name + " (serialNumber, isGiven, chair_id, tables_id, shelf_id, wardrobe_id, linen_id) values ('" + str(values) + "', '" + str(status[randint(0, len(status) - 1)]) +"', " + str(i + 1) + "," + str(i + 1) + "," + str(i + 1) + "," + str(i + 1) + "," + str(i + 1) + ")\n")

    file.write("\n\n")
    file.close()

def create_linen_data(table_name):
    file = open("data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    for i in range(20):
        values = randint(100000, 999999)
        file.write("insert into " + table_name + " (serialNumber, isGiven, bedsheet_id, pillowcase_id, duvet_id, bedspread_id, towel_id) values ('" + str(values) + "', '" + str(status[randint(0, len(status) - 1)]) +"', " + str(i + 1) + "," + str(i + 1) + "," + str(i + 1) + "," + str(i + 1) + "," + str(i + 1) + ")\n")

    file.write("\n\n")
    file.close()

def create_data(table_name):
    file = open("data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    for i in range(20):
        values = randint(100000, 999999)
        file.write("insert into " + table_name + " (serialNumber, isGiven) values ('" + str(values) + "', '" + str(status[randint(0, len(status) - 1)]) +"')\n")

    file.write("\n\n")
    file.close()


create_items_data("items")

create_linen_data("linen")
create_data("chair")
create_data("tables")
create_data("wardrobe")
create_data("shelf")

create_data("bedsheet")
create_data("pillowcase")
create_data("duvet")
create_data("bedspread")
create_data("towel")
