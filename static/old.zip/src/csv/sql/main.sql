﻿DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users; 

DROP TABLE IF EXISTS items; 
DROP TABLE IF EXISTS linen; 

DROP TABLE IF EXISTS wardrobe; 
DROP TABLE IF EXISTS tables; 
DROP TABLE IF EXISTS chair; 
DROP TABLE IF EXISTS shelf;

DROP TABLE IF EXISTS bedsheet; -- простыня
DROP TABLE IF EXISTS pillowcase; -- наволочка
DROP TABLE IF EXISTS duvet; -- пододеяльник
DROP TABLE IF EXISTS bedspread; -- покрывало
DROP TABLE IF EXISTS towel; -- полотенце

DROP TABLE IF EXISTS report;

-- users  data   linen   items   students
CREATE TABLE users (
	id int IDENTITY(1,1) NOT NULL,
	login varchar(20) NOT NULL,
	password varchar(20) NOT NULL, 
	userType varchar(5) NOT null, -- Студент/Комендант/Завхоз
	PRIMARY KEY (id)
);

CREATE TABLE bedsheet (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE pillowcase (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE duvet (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE bedspread (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE towel (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE linen (
	id int IDENTITY(1,1) NOT NULL,
	bedsheet_id int,
	pillowcase_id int,
	duvet_id int,
	bedspread_id int,
	towel_id int,
	PRIMARY KEY (id),
	FOREIGN KEY (bedsheet_id) REFERENCES bedsheet(id),
	FOREIGN KEY (pillowcase_id) REFERENCES pillowcase(id),
	FOREIGN KEY (duvet_id) REFERENCES duvet(id),
	FOREIGN KEY (bedspread_id) REFERENCES bedspread(id),
	FOREIGN KEY (towel_id) REFERENCES towel(id)
);

CREATE TABLE wardrobe (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE tables (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE chair (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE shelf (
	id int IDENTITY(1,1) NOT NULL,
	serialNumber varchar(20),
	isGiven varchar(15),
	PRIMARY KEY (id)
);

CREATE TABLE items (
	id int IDENTITY(1,1) NOT NULL,
	chair_id int,
	tables_id int,
	shelf_id int,
	wardrobe_id int,
	linen_id int,
	PRIMARY KEY (id),
	FOREIGN KEY (chair_id) REFERENCES chair(id),
	FOREIGN KEY (tables_id) REFERENCES tables(id),
	FOREIGN KEY (shelf_id) REFERENCES shelf(id),
	FOREIGN KEY (wardrobe_id) REFERENCES wardrobe(id),
	FOREIGN KEY (linen_id) REFERENCES linen(id)
);

CREATE TABLE students (
	id int IDENTITY(1,1) NOT NULL,
	name varchar(20) NOT NULL, 
	surname varchar(20) NOT NULL,
	phoneNumber varchar(12) not null,
	checkInDate varchar(12), 
	studak varchar(20) NOT NULL, 
	gender varchar(5) NOT NULL,
	roomNumber varchar(20),
	linen_id int,
	items_id int,
	PRIMARY KEY (id),
	FOREIGN KEY (linen_id) REFERENCES linen(id),
	FOREIGN KEY (items_id) REFERENCES items(id),
	FOREIGN KEY (id) REFERENCES users(id)
);

CREATE TABLE report (
	id int IDENTITY(1,1) NOT NULL, -- ����������� ����
	name varchar(20) NOT NULL,
	surname varchar(20) NOT NULL,
	DateChange varchar(12),
	roomNumber varchar(20),
	itemType varchar(20),
	PRIMARY KEY (id),
	FOREIGN KEY (id) REFERENCES students(id)
);

select * from report
select * from students
select * from users;
select * from linen
select * from chair
select * from items
select * from wardrobe
select * from tables
select * from shelf
select * from bedsheet
select * from pillowcase
select * from duvet
select * from bedspread
select * from towel

INSERT INTO report (name, surname, DateChange, roomNumber, itemType) VALUES ('Женя', 'Фролов', '2023-11-02', '726', 'Chair');
INSERT INTO report (name, surname, DateChange, roomNumber, itemType) VALUES ('Гена', 'Иванов', '2023-11-03', '222', 'Shelf');
INSERT INTO report (name, surname, DateChange, roomNumber, itemType) VALUES ('Гена', 'Иванов', '2023-11-03', '222', 'Duvet');

insert into users (login, password, userType) values ('1', '1', 'S')
insert into users (login, password, userType) values ('2', '2', 'S')
insert into users (login, password, userType) values ('3', '3', 'S')

insert into chair (serialNumber, isGiven) values ('1', 'У студента')
insert into chair (serialNumber, isGiven) values ('2', 'На складе')
insert into chair (serialNumber, isGiven) values ('3', 'На складе')

insert into tables (serialNumber, isGiven) values ('1', 'У студента')
insert into tables (serialNumber, isGiven) values ('2', 'На складе')
insert into tables (serialNumber, isGiven) values ('3', 'На складе')

insert into shelf (serialNumber, isGiven) values ('1', 'У студента')
insert into shelf (serialNumber, isGiven) values ('2', 'На складе')
insert into shelf (serialNumber, isGiven) values ('3', 'На складе')

insert into wardrobe (serialNumber, isGiven) values ('1', 'У студента')
insert into wardrobe (serialNumber, isGiven) values ('2', 'На складе')
insert into wardrobe (serialNumber, isGiven) values ('3', 'На складе')

insert into pillowcase(serialNumber, isGiven) values ('1', 'У студента')
insert into pillowcase(serialNumber, isGiven) values ('2', 'На складе')
insert into pillowcase(serialNumber, isGiven) values ('3', 'На складе')

insert into bedsheet(serialNumber, isGiven) values ('1', 'У студента')
insert into bedsheet(serialNumber, isGiven) values ('2', 'На складе')
insert into bedsheet(serialNumber, isGiven) values ('3', 'На складе')

insert into bedspread(serialNumber, isGiven) values ('1', 'У студента')
insert into bedspread(serialNumber, isGiven) values ('2', 'На складе')
insert into bedspread(serialNumber, isGiven) values ('3', 'На складе')

insert into duvet (serialNumber, isGiven) values ('1', 'У студента')
insert into duvet (serialNumber, isGiven) values ('2', 'На складе')
insert into duvet (serialNumber, isGiven) values ('3', 'На складе')

insert into towel (serialNumber, isGiven) values ('1', 'У студента')
insert into towel (serialNumber, isGiven) values ('2', 'На складе')
insert into towel (serialNumber, isGiven) values ('3', 'На складе')

insert into linen (bedsheet_id, pillowcase_id, duvet_id, bedspread_id, towel_id) values (1,1,1,1,1)
insert into items (chair_id, tables_id, shelf_id, wardrobe_id, linen_id) values (1,1,1,1,1)

insert into linen (bedsheet_id, pillowcase_id, duvet_id, bedspread_id, towel_id) values (2,2,2,2,2)
insert into items (chair_id, tables_id, shelf_id, wardrobe_id, linen_id) values (2,2,2,2,2)

insert into linen (bedsheet_id, pillowcase_id, duvet_id, bedspread_id, towel_id) values (3,3,3,3,3)
insert into items (chair_id, tables_id, shelf_id, wardrobe_id, linen_id) values (3,3,3,3,3)

insert into students (name, surname, phoneNumber, checkInDate, studak, gender, roomNumber, linen_id, items_id) values ('Женя', 'Фролов', '+75359439424', '2022-04-13', '19u962', 'М', '726', 1, 1)
insert into students (name, surname, phoneNumber, checkInDate, studak, gender, roomNumber, linen_id, items_id) values ('Гена', 'Иванов', '+75359222224', '2021-02-18', '18u943', 'М', '222', 2, 2)
insert into students (name, surname, phoneNumber, checkInDate, studak, gender, roomNumber, linen_id, items_id) values ('Светлана', 'Иванова', '+75359111124', '2022-05-11', '18u533', 'F', '125', 3, 3)

update users set login = '1', password = '1', userType = 'S' where id = 1
update users set login = '2', password = '2', userType = 'S' where id = 2
update users set login = '3', password = '3', userType = 'S' where id = 3

update students set name = 'Женя', surname = 'Фролов', phoneNumber = '+75359439424', checkInDate = '2022-04-13', studak = '19u962', gender = 'M', roomNumber = '726', linen_id = 1, items_id = 1 where id = 1
update students set name = 'Василий', surname = 'Громов', phoneNumber = '+73762718376', checkInDate = '2021-02-15', studak = '19u345', gender = 'M', roomNumber = '214', linen_id = 2, items_id = 2 where id = 2
update students set name = 'Светлана', surname = 'Суворова', phoneNumber = '+73768888376', checkInDate = '2022-04-11', studak = '19u512', gender = 'F', roomNumber = '121', linen_id = 3, items_id = 3 where id = 3

update chair set isGiven = 'У студента' where id = 1;
update chair set isGiven = 'На складе' where id = 2;
update chair set isGiven = 'На складе' where id = 3;

update tables set isGiven = 'У студента' where id = 1;
update tables set isGiven = 'На складе' where id = 2;
update tables set isGiven = 'На складе' where id = 3;

update shelf set isGiven = 'У студента' where id = 1;
update shelf set isGiven = 'На складе' where id = 2;
update shelf set isGiven = 'На складе' where id = 3;

update wardrobe set isGiven = 'У студента' where id = 1;
update wardrobe set isGiven = 'На складе' where id = 2;
update wardrobe set isGiven = 'На складе' where id = 3;

update bedsheet set isGiven = 'У студента' where id = 1;
update bedsheet set isGiven = 'На складе' where id = 2;
update bedsheet set isGiven = 'На складе' where id = 3;

update pillowcase set isGiven = 'У студента' where id = 1;
update pillowcase set isGiven = 'На складе' where id = 2;
update pillowcase set isGiven = 'На складе' where id = 3;

update duvet set isGiven = 'У студента' where id = 1;
update duvet set isGiven = 'На складе' where id = 2;
update duvet set isGiven = 'На складе' where id = 3;

update bedspread set isGiven = 'У студента' where id = 1;
update bedspread set isGiven = 'На складе' where id = 2;
update bedspread set isGiven = 'На складе' where id = 3;

update towel set isGiven = 'У студента' where id = 1;
update towel set isGiven = 'На складе' where id = 2;
update towel set isGiven = 'На складе' where id = 3;

update items set chair_id = '1', tables_id = '1', shelf_id = '1', wardrobe_id = '1' where id = 1
update linen set bedsheet_id = '1', pillowcase_id = '1', bedspread_id = '1', duvet_id = '1', towel_id = '1' where id = 1

update items set chair_id = '2', tables_id = '2', shelf_id = '2', wardrobe_id = '2' where id = 2
update linen set bedsheet_id = '2', pillowcase_id = '2', bedspread_id = '2', duvet_id = '2', towel_id = '2' where id = 2

update items set chair_id = '3', tables_id = '3', shelf_id = '3', wardrobe_id = '3' where id = 3
update linen set bedsheet_id = '3', pillowcase_id = '3', bedspread_id = '3', duvet_id = '3', towel_id = '3' where id = 3

