CREATE TABLE Bedsheet (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Pillowcase (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Duvet (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Bedspread (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Towel (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);
CREATE TABLE Linen (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255) NOT NULL,
    isGiven VARCHAR(255),
    bedsheet_id INT,
    pillowcase_id INT,
    duvet_id INT,
    bedspread_id INT,
    towel_id INT,
    FOREIGN KEY (bedsheet_id) REFERENCES Bedsheet(ID),
    FOREIGN KEY (pillowcase_id) REFERENCES Pillowcase(ID),
    FOREIGN KEY (duvet_id) REFERENCES Duvet(ID),
    FOREIGN KEY (bedspread_id) REFERENCES Bedspread(ID),
    FOREIGN KEY (towel_id) REFERENCES Towel(ID)
);


CREATE TABLE Chair (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Tables (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Shelf (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Wardrobe  (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255)
);

CREATE TABLE Items (
    ID INT PRIMARY KEY NOT NULL,
    serialNumber VARCHAR(255),
    isGiven VARCHAR(255),
    chair_id INT,
    tables_id INT,
    shelf_id INT,
    wardrobe_id INT,
    linen_id INT,
    FOREIGN KEY (chair_id) REFERENCES Chair(ID),
    FOREIGN KEY (tables_id) REFERENCES Tables(ID),
    FOREIGN KEY (shelf_id) REFERENCES Shelf(ID),
    FOREIGN KEY (wardrobe_id) REFERENCES Wardrobe(ID),
    FOREIGN KEY (linen_id) REFERENCES Linen(ID)
);

CREATE TABLE Users (
    ID INT PRIMARY KEY NOT NULL,
    login VARCHAR(255),
    password VARCHAR(255),
    userType VARCHAR(255)
);

CREATE TABLE Students (
    ID INT PRIMARY KEY NOT NULL,
    name VARCHAR(255),
    surname VARCHAR(255),
    phoneNumber VARCHAR(15),
    checkInDate DATE,
    studak VARCHAR(10),
    gender VARCHAR(15),
    roomNumber VARCHAR(15),
    linen_id INT,
    items_id INT,
    FOREIGN KEY (linen_id) REFERENCES Linen(ID),
    FOREIGN KEY (items_id) REFERENCES Items(ID)
);

CREATE TABLE Report (
    ID INT PRIMARY KEY NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    room INT NOT NULL,
    itemType VARCHAR(255) NOT NULL,
    student_id INT,
    FOREIGN KEY (student_id) REFERENCES Students(ID)
);


