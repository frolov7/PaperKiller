#!/usr/bin/env python3

import random

approved_list = []

def random_first_name(gender):
    male_values = ["Владимир", "Сергей", "Евгений", "Григорий", "Алексей", "Иван", "Платон", "Семен", "Мирон", "Савелий", "Олег", "Даниэль", "Николай", "Руслан", "Юрий", "Ярослав", "Артур", "Степан", "Илья", "Вячеслав", "Василий", "Федор", "Ян", "Анатолий"]
    female_values = ["Полина", "Клава", "Ксения", "Людмила", "Нина", "Галина", "Арина", "Анна", "Мария", "Алиса ", "Ева", "Надежда ", "Татьяна", "Ольга", "Елена", "Лаура", "Злата", "Милана", "Глория", "Алла", "Алина", "Римма", "Рината", "Роза"]
    
    if (gender == "М"):
        return male_values[random.randint(0, len(male_values)-1)]
    else:
        return female_values[random.randint(0, len(female_values)-1)]

def random_last_name(gender):
    male_values = ["Максименко", "Павлов", "Клюев", "Ришатов", "Дунаев", "Седько", "Иванов", "Смирнов", "Кузнецов", "Попов", "Васильев", "Петров", "Павлов", "Соколов", "Михайлов", "Лебедев", "Семенов", "Егоров", "Николаев", "Степанов", "Орлов", "Козлов"]
    female_values = ["Волошина", "Миклуш", "Суворина", "Пешкина", "Логвина", "Фукина", "Петрова", "Смирнова", "Романова", "Попова", "Волкова", "Кузнецова", "Волошина", "Новикова", "Захарова", "Березина", "Бирюкова", "Ильина", "Васильева", "Долгова", "Вдовина", "Казакова", "Калачева", "Виноградова"]
    
    if (gender == "М"):
        return male_values[random.randint(0, len(male_values)-1)]
    else:
        return female_values[random.randint(0, len(female_values)-1)]

def random_phone():
    return str('+7' + str(random.randint(1000000000, 9999999999)))

def random_date():
    day = str(random.randint(1, 28))
    month = str(random.randint(1, 12))
    if (int(day) <= 9):
        day = "0"+str(day)
    if (int(month) <= 9):
        month = "0"+str(month)
    return str(random.randint(2018, 2022)) + '-' + month + '-' + day

def random_studak():
    letters = ['q', 'w', 'e', 'r', 't', 'y', 'u', 'a', 's', 'd', 'f', 'g', 'h', 'z', 'x', 'c', 'v', 'b', 'n', 'm']
    return str(str(random.randint(18, 22)) + letters[random.randint(0, len(letters)-1)] + str(random.randint(100, 999)))

def random_gender():
    genders = ["М", "Ж"]
    return genders[random.randint(0, len(genders)-1)]

def random_room():
    room = [1, 2]
    if (room[random.randint(0, 1)] == 1):
        return "Не назначена"
    else:
        return str(str(random.randint(100, 999)))

rooms = []

students_index = 1
students_count = 800
f = open('./csv/students_data.txt', 'w', encoding='utf-8')

while (students_index <= students_count):
    gender = random_gender()
    room = random_room()
    f.write("insert into students (name, surname, phoneNumber, checkInDate, studak, gender, roomNumber, linen_id, items_id) values ('" + random_first_name(gender) + "', '" + random_last_name(gender) + "', '" + random_phone() + "', '" + random_date() + "', '" + random_studak() + "', '" + gender + "', '" + room + "'," + str(students_index) + "," + str(students_index) + ")\n")
    rooms.append(room)
    students_index += 1
f.close()
print("-> students_data.txt generated")

#!------------------------------------------------------

def random_login():
    login = ''
    for x in range(5):
        login = login + random.choice(list('abcdefghigklmnopqrstuvyxwz'))
    return login

def random_password():
    password = ''
    for x in range(6):
        password = password + random.choice(list('abcdefghigklmnopqrstuvyxwz1234567890'))
    return password

def random_usertype(room_index):
    if (rooms[room_index] == "Выселен"):
        userType = "O";
    elif (rooms[room_index] == 'Не назначена'):
        userType = "S";
    else:
        userType = "S"
    return userType

users_index = 1
users_count = 800
room_index = 0
f = open('./csv/users_data.txt', 'w', encoding='utf-8')

while (users_index <= users_count):
    f.write("insert into users (login, password, userType) values ('" + random_login() + "', '" + random_password() + "', '" + random_usertype(room_index) + "')\n")
    users_index += 1
    room_index += 1
f.close()
print("-> users_data.txt generated")


#!----------------------------------------
def create_items_data(table_name):
    items_index = 1
    items_count = 1000
    f = open("./csv/items.txt", "w", encoding='utf-8')
    while (items_index <= items_count):
        values = random.randint(100000, 999999)
        f.write("insert into " + table_name + " (chair_id, tables_id, shelf_id, wardrobe_id, linen_id) values (" + str(items_index) + "," + str(items_index) + "," + str(items_index) + "," + str(items_index) + "," + str(items_index) + ")\n")
        items_index += 1
    f.write("\n\n")
    f.close()

def create_linen_data(table_name):
    linen_index = 1
    linen_count = 1000
    f = open("./csv/linen.txt", "a", encoding='utf-8')
    while (linen_index <= linen_count):
        values = random.randint(100000, 999999)
        f.write("insert into " + table_name + " (bedsheet_id, pillowcase_id, duvet_id, bedspread_id, towel_id) values (" + str(linen_index) + "," + str(linen_index) + "," + str(linen_index) + "," + str(linen_index) + "," + str(linen_index) + ")\n")
        linen_index += 1
    f.write("\n\n")
    f.close()


def create_chair():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into chair (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_tables():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into tables (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_wardrobe():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into wardrobe (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_shelf():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into shelf (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_bedsheet():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into bedsheet (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_pillowcase():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into pillowcase (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_duvet():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into duvet (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_towel():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into towel (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

def create_bedspread():
    data_index = 1
    data_count = 1000
    f = open("./csv/data.txt", "a", encoding='utf-8')
    status = ["У студента", "На складе"]
    while (data_index <= data_count):
        values = random.randint(100000, 999999)
        isGiven = status[random.randint(0, len(status) - 1)]
        f.write("insert into bedspread (serialNumber, isGiven) values ('" + str(values) + "', '" + isGiven +"')\n")
        data_index += 1
    f.write("\n\n")
    f.close()
    print("-> data.txt generated")

create_items_data("items")
create_linen_data("linen")

create_chair()
create_tables()
create_wardrobe()
create_shelf()

create_bedsheet()
create_pillowcase()
create_duvet()
create_bedspread()
create_towel()